// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 sqljet/src/Sql.g 2009-08-26 20:05:01

  package org.tmatesoft.sqljet.core.internal.lang;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

@SuppressWarnings({"unused", "unchecked"})
public class SqlParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ALIAS", "BIND", "BIND_NAME", "BLOB_LITERAL", "COLUMN_CONSTRAINT", "COLUMN_EXPRESSION", "COLUMNS", "CONSTRAINTS", "CREATE_INDEX", "CREATE_TABLE", "DROP_INDEX", "DROP_TABLE", "FLOAT_LITERAL", "FUNCTION_LITERAL", "FUNCTION_EXPRESSION", "ID_LITERAL", "IN_VALUES", "IN_TABLE", "INTEGER_LITERAL", "IS_NULL", "NOT_NULL", "OPTIONS", "ORDERING", "SELECT_CORE", "STRING_LITERAL", "TABLE_CONSTRAINT", "TYPE", "TYPE_PARAMS", "EXPLAIN", "QUERY", "PLAN", "SEMI", "DOT", "INDEXED", "BY", "NOT", "OR", "AND", "ESCAPE", "IN", "LPAREN", "COMMA", "RPAREN", "ISNULL", "NOTNULL", "IS", "NULL", "BETWEEN", "EQUALS", "EQUALS2", "NOT_EQUALS", "NOT_EQUALS2", "LIKE", "GLOB", "REGEXP", "MATCH", "LESS", "LESS_OR_EQ", "GREATER", "GREATER_OR_EQ", "SHIFT_LEFT", "SHIFT_RIGHT", "AMPERSAND", "PIPE", "PLUS", "MINUS", "ASTERISK", "SLASH", "PERCENT", "DOUBLE_PIPE", "TILDA", "COLLATE", "ID", "DISTINCT", "CAST", "AS", "CASE", "ELSE", "END", "WHEN", "THEN", "INTEGER", "FLOAT", "STRING", "BLOB", "CURRENT_TIME", "CURRENT_DATE", "CURRENT_TIMESTAMP", "QUESTION", "COLON", "AT", "RAISE", "IGNORE", "ROLLBACK", "ABORT", "FAIL", "PRAGMA", "ATTACH", "DATABASE", "DETACH", "ANALYZE", "REINDEX", "VACUUM", "REPLACE", "ASC", "DESC", "ORDER", "LIMIT", "OFFSET", "UNION", "ALL", "INTERSECT", "EXCEPT", "SELECT", "FROM", "WHERE", "GROUP", "HAVING", "NATURAL", "LEFT", "OUTER", "INNER", "CROSS", "JOIN", "ON", "USING", "INSERT", "INTO", "VALUES", "DEFAULT", "UPDATE", "SET", "DELETE", "BEGIN", "DEFERRED", "IMMEDIATE", "EXCLUSIVE", "TRANSACTION", "COMMIT", "TO", "SAVEPOINT", "RELEASE", "CONFLICT", "CREATE", "VIRTUAL", "TABLE", "TEMPORARY", "IF", "EXISTS", "CONSTRAINT", "PRIMARY", "KEY", "AUTOINCREMENT", "UNIQUE", "CHECK", "FOREIGN", "REFERENCES", "CASCADE", "RESTRICT", "DEFERRABLE", "INITIALLY", "DROP", "ALTER", "RENAME", "ADD", "COLUMN", "VIEW", "INDEX", "TRIGGER", "BEFORE", "AFTER", "INSTEAD", "OF", "FOR", "EACH", "ROW", "DOLLAR", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "ID_START", "ESCAPE_SEQ", "FLOAT_EXP", "COMMENT", "LINE_COMMENT", "WS"
    };
    public static final int EXISTS=152;
    public static final int INDEX=171;
    public static final int CURRENT_TIMESTAMP=91;
    public static final int MINUS=69;
    public static final int END=82;
    public static final int ATTACH=101;
    public static final int INTO=131;
    public static final int ABORT=98;
    public static final int V=202;
    public static final int SAVEPOINT=144;
    public static final int NATURAL=122;
    public static final int RENAME=167;
    public static final int REGEXP=58;
    public static final int VIEW=170;
    public static final int ALIAS=4;
    public static final int U=201;
    public static final int ON=128;
    public static final int DOT=36;
    public static final int CONSTRAINT=153;
    public static final int NOT_EQUALS=54;
    public static final int ORDER=110;
    public static final int COLLATE=75;
    public static final int R=198;
    public static final int Q=197;
    public static final int STRING_LITERAL=28;
    public static final int SELECT=117;
    public static final int RPAREN=46;
    public static final int DESC=109;
    public static final int ID_START=207;
    public static final int CONFLICT=146;
    public static final int UNION=113;
    public static final int PRIMARY=154;
    public static final int W=203;
    public static final int WHEN=83;
    public static final int FLOAT_LITERAL=16;
    public static final int WS=212;
    public static final int STRING=87;
    public static final int NOTNULL=48;
    public static final int EXCLUSIVE=140;
    public static final int UPDATE=134;
    public static final int FUNCTION_EXPRESSION=18;
    public static final int X=204;
    public static final int SEMI=35;
    public static final int EQUALS=52;
    public static final int PLAN=34;
    public static final int ALTER=166;
    public static final int ELSE=81;
    public static final int COLUMN_EXPRESSION=9;
    public static final int FLOAT_EXP=209;
    public static final int ESCAPE_SEQ=208;
    public static final int NULL=50;
    public static final int ASTERISK=70;
    public static final int COLON=93;
    public static final int HAVING=121;
    public static final int SET=135;
    public static final int J=190;
    public static final int ADD=168;
    public static final int TILDA=74;
    public static final int UNIQUE=157;
    public static final int SHIFT_LEFT=64;
    public static final int TYPE=30;
    public static final int INDEXED=37;
    public static final int O=195;
    public static final int PERCENT=72;
    public static final int DATABASE=102;
    public static final int EXPLAIN=32;
    public static final int P=196;
    public static final int FLOAT=86;
    public static final int VALUES=132;
    public static final int RESTRICT=162;
    public static final int CAST=78;
    public static final int EXCEPT=116;
    public static final int QUESTION=92;
    public static final int OR=40;
    public static final int AFTER=174;
    public static final int S=199;
    public static final int DOUBLE_PIPE=73;
    public static final int INTEGER=85;
    public static final int LESS=60;
    public static final int BY=38;
    public static final int RELEASE=145;
    public static final int IS_NULL=23;
    public static final int IGNORE=96;
    public static final int ESCAPE=42;
    public static final int M=193;
    public static final int LPAREN=44;
    public static final int T=200;
    public static final int JOIN=127;
    public static final int CURRENT_DATE=90;
    public static final int GREATER_OR_EQ=63;
    public static final int ID=76;
    public static final int FROM=118;
    public static final int DELETE=136;
    public static final int FAIL=99;
    public static final int DEFERRABLE=163;
    public static final int CURRENT_TIME=89;
    public static final int COMMENT=210;
    public static final int MATCH=59;
    public static final int LIKE=56;
    public static final int COMMIT=142;
    public static final int N=194;
    public static final int IN=43;
    public static final int REINDEX=105;
    public static final int DROP=165;
    public static final int DETACH=103;
    public static final int DROP_INDEX=14;
    public static final int IF=151;
    public static final int FOR=177;
    public static final int DEFAULT=133;
    public static final int VIRTUAL=148;
    public static final int BEFORE=173;
    public static final int BLOB_LITERAL=7;
    public static final int IN_VALUES=20;
    public static final int NOT=39;
    public static final int LIMIT=111;
    public static final int DROP_TABLE=15;
    public static final int COMMA=45;
    public static final int AS=79;
    public static final int THEN=84;
    public static final int FOREIGN=159;
    public static final int PIPE=67;
    public static final int D=184;
    public static final int AND=41;
    public static final int TO=143;
    public static final int ROLLBACK=97;
    public static final int TRIGGER=172;
    public static final int CONSTRAINTS=11;
    public static final int BETWEEN=51;
    public static final int PLUS=68;
    public static final int AMPERSAND=66;
    public static final int CREATE_TABLE=13;
    public static final int INTEGER_LITERAL=22;
    public static final int AT=94;
    public static final int INTERSECT=115;
    public static final int DISTINCT=77;
    public static final int CASCADE=161;
    public static final int LESS_OR_EQ=61;
    public static final int OF=176;
    public static final int DOLLAR=180;
    public static final int A=181;
    public static final int ANALYZE=104;
    public static final int LINE_COMMENT=211;
    public static final int NOT_NULL=24;
    public static final int CASE=80;
    public static final int DEFERRED=138;
    public static final int TABLE=149;
    public static final int C=183;
    public static final int COLUMNS=10;
    public static final int KEY=155;
    public static final int CHECK=158;
    public static final int REFERENCES=160;
    public static final int L=192;
    public static final int AUTOINCREMENT=156;
    public static final int ALL=114;
    public static final int COLUMN=169;
    public static final int INSERT=130;
    public static final int EACH=178;
    public static final int WHERE=119;
    public static final int CREATE=147;
    public static final int PRAGMA=100;
    public static final int USING=129;
    public static final int INITIALLY=164;
    public static final int I=189;
    public static final int QUERY=33;
    public static final int INNER=125;
    public static final int F=186;
    public static final int CREATE_INDEX=12;
    public static final int K=191;
    public static final int FUNCTION_LITERAL=17;
    public static final int B=182;
    public static final int GROUP=120;
    public static final int OPTIONS=25;
    public static final int GREATER=62;
    public static final int TYPE_PARAMS=31;
    public static final int NOT_EQUALS2=55;
    public static final int ORDERING=26;
    public static final int SELECT_CORE=27;
    public static final int LEFT=123;
    public static final int TEMPORARY=150;
    public static final int INSTEAD=175;
    public static final int OUTER=124;
    public static final int ID_LITERAL=19;
    public static final int BIND_NAME=6;
    public static final int VACUUM=106;
    public static final int H=188;
    public static final int SLASH=71;
    public static final int BLOB=88;
    public static final int TABLE_CONSTRAINT=29;
    public static final int IMMEDIATE=139;
    public static final int IS=49;
    public static final int G=187;
    public static final int OFFSET=112;
    public static final int REPLACE=107;
    public static final int EQUALS2=53;
    public static final int ASC=108;
    public static final int BEGIN=137;
    public static final int COLUMN_CONSTRAINT=8;
    public static final int Z=206;
    public static final int IN_TABLE=21;
    public static final int SHIFT_RIGHT=65;
    public static final int EOF=-1;
    public static final int RAISE=95;
    public static final int CROSS=126;
    public static final int ISNULL=47;
    public static final int GLOB=57;
    public static final int Y=205;
    public static final int BIND=5;
    public static final int TRANSACTION=141;
    public static final int ROW=179;
    public static final int E=185;

    // delegates
    // delegators


        public SqlParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SqlParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SqlParser.tokenNames; }
    public String getGrammarFileName() { return "sqljet/src/Sql.g"; }



    // Disable error recovery.
    protected Object recoverFromMismatchedToken(IntStream input, int ttype, BitSet follow) throws RecognitionException {
        throw new MismatchedTokenException(ttype, input);
    }

    // Delegate error reporting to caller.
    public void displayRecognitionError(String[] tokenNames, RecognitionException e) {
        String hdr = getErrorHeader(e);
        String msg = getErrorMessage(e, tokenNames);
    	throw new SqlJetParserException("[" + hdr + "] " + msg, e);
    }



    public static class sql_stmt_list_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "sql_stmt_list"
    // sqljet/src/Sql.g:85:1: sql_stmt_list : ( sql_stmt )+ ;
    public final SqlParser.sql_stmt_list_return sql_stmt_list() throws RecognitionException {
        SqlParser.sql_stmt_list_return retval = new SqlParser.sql_stmt_list_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        SqlParser.sql_stmt_return sql_stmt1 = null;



        try {
            // sqljet/src/Sql.g:85:14: ( ( sql_stmt )+ )
            // sqljet/src/Sql.g:85:16: ( sql_stmt )+
            {
            root_0 = (Object)adaptor.nil();

            // sqljet/src/Sql.g:85:16: ( sql_stmt )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                alt1 = dfa1.predict(input);
                switch (alt1) {
            	case 1 :
            	    // sqljet/src/Sql.g:85:17: sql_stmt
            	    {
            	    pushFollow(FOLLOW_sql_stmt_in_sql_stmt_list190);
            	    sql_stmt1=sql_stmt();

            	    state._fsp--;

            	    adaptor.addChild(root_0, sql_stmt1.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "sql_stmt_list"

    public static class sql_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "sql_stmt"
    // sqljet/src/Sql.g:87:1: sql_stmt : ( EXPLAIN ( QUERY PLAN )? )? sql_stmt_core SEMI ;
    public final SqlParser.sql_stmt_return sql_stmt() throws RecognitionException {
        SqlParser.sql_stmt_return retval = new SqlParser.sql_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token EXPLAIN2=null;
        Token QUERY3=null;
        Token PLAN4=null;
        Token SEMI6=null;
        SqlParser.sql_stmt_core_return sql_stmt_core5 = null;


        Object EXPLAIN2_tree=null;
        Object QUERY3_tree=null;
        Object PLAN4_tree=null;
        Object SEMI6_tree=null;

        try {
            // sqljet/src/Sql.g:87:9: ( ( EXPLAIN ( QUERY PLAN )? )? sql_stmt_core SEMI )
            // sqljet/src/Sql.g:87:11: ( EXPLAIN ( QUERY PLAN )? )? sql_stmt_core SEMI
            {
            root_0 = (Object)adaptor.nil();

            // sqljet/src/Sql.g:87:11: ( EXPLAIN ( QUERY PLAN )? )?
            int alt3=2;
            alt3 = dfa3.predict(input);
            switch (alt3) {
                case 1 :
                    // sqljet/src/Sql.g:87:12: EXPLAIN ( QUERY PLAN )?
                    {
                    EXPLAIN2=(Token)match(input,EXPLAIN,FOLLOW_EXPLAIN_in_sql_stmt200); 
                    EXPLAIN2_tree = (Object)adaptor.create(EXPLAIN2);
                    adaptor.addChild(root_0, EXPLAIN2_tree);

                    // sqljet/src/Sql.g:87:20: ( QUERY PLAN )?
                    int alt2=2;
                    alt2 = dfa2.predict(input);
                    switch (alt2) {
                        case 1 :
                            // sqljet/src/Sql.g:87:21: QUERY PLAN
                            {
                            QUERY3=(Token)match(input,QUERY,FOLLOW_QUERY_in_sql_stmt203); 
                            QUERY3_tree = (Object)adaptor.create(QUERY3);
                            adaptor.addChild(root_0, QUERY3_tree);

                            PLAN4=(Token)match(input,PLAN,FOLLOW_PLAN_in_sql_stmt205); 
                            PLAN4_tree = (Object)adaptor.create(PLAN4);
                            adaptor.addChild(root_0, PLAN4_tree);


                            }
                            break;

                    }


                    }
                    break;

            }

            pushFollow(FOLLOW_sql_stmt_core_in_sql_stmt211);
            sql_stmt_core5=sql_stmt_core();

            state._fsp--;

            adaptor.addChild(root_0, sql_stmt_core5.getTree());
            SEMI6=(Token)match(input,SEMI,FOLLOW_SEMI_in_sql_stmt213); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "sql_stmt"

    public static class sql_stmt_core_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "sql_stmt_core"
    // sqljet/src/Sql.g:89:1: sql_stmt_core : ( pragma_stmt | attach_stmt | detach_stmt | analyze_stmt | reindex_stmt | vacuum_stmt | select_stmt | insert_stmt | update_stmt | delete_stmt | begin_stmt | commit_stmt | rollback_stmt | savepoint_stmt | release_stmt | create_virtual_table_stmt | create_table_stmt | drop_table_stmt | alter_table_stmt | create_view_stmt | drop_view_stmt | create_index_stmt | drop_index_stmt | create_trigger_stmt | drop_trigger_stmt );
    public final SqlParser.sql_stmt_core_return sql_stmt_core() throws RecognitionException {
        SqlParser.sql_stmt_core_return retval = new SqlParser.sql_stmt_core_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        SqlParser.pragma_stmt_return pragma_stmt7 = null;

        SqlParser.attach_stmt_return attach_stmt8 = null;

        SqlParser.detach_stmt_return detach_stmt9 = null;

        SqlParser.analyze_stmt_return analyze_stmt10 = null;

        SqlParser.reindex_stmt_return reindex_stmt11 = null;

        SqlParser.vacuum_stmt_return vacuum_stmt12 = null;

        SqlParser.select_stmt_return select_stmt13 = null;

        SqlParser.insert_stmt_return insert_stmt14 = null;

        SqlParser.update_stmt_return update_stmt15 = null;

        SqlParser.delete_stmt_return delete_stmt16 = null;

        SqlParser.begin_stmt_return begin_stmt17 = null;

        SqlParser.commit_stmt_return commit_stmt18 = null;

        SqlParser.rollback_stmt_return rollback_stmt19 = null;

        SqlParser.savepoint_stmt_return savepoint_stmt20 = null;

        SqlParser.release_stmt_return release_stmt21 = null;

        SqlParser.create_virtual_table_stmt_return create_virtual_table_stmt22 = null;

        SqlParser.create_table_stmt_return create_table_stmt23 = null;

        SqlParser.drop_table_stmt_return drop_table_stmt24 = null;

        SqlParser.alter_table_stmt_return alter_table_stmt25 = null;

        SqlParser.create_view_stmt_return create_view_stmt26 = null;

        SqlParser.drop_view_stmt_return drop_view_stmt27 = null;

        SqlParser.create_index_stmt_return create_index_stmt28 = null;

        SqlParser.drop_index_stmt_return drop_index_stmt29 = null;

        SqlParser.create_trigger_stmt_return create_trigger_stmt30 = null;

        SqlParser.drop_trigger_stmt_return drop_trigger_stmt31 = null;



        try {
            // sqljet/src/Sql.g:90:3: ( pragma_stmt | attach_stmt | detach_stmt | analyze_stmt | reindex_stmt | vacuum_stmt | select_stmt | insert_stmt | update_stmt | delete_stmt | begin_stmt | commit_stmt | rollback_stmt | savepoint_stmt | release_stmt | create_virtual_table_stmt | create_table_stmt | drop_table_stmt | alter_table_stmt | create_view_stmt | drop_view_stmt | create_index_stmt | drop_index_stmt | create_trigger_stmt | drop_trigger_stmt )
            int alt4=25;
            alt4 = dfa4.predict(input);
            switch (alt4) {
                case 1 :
                    // sqljet/src/Sql.g:90:5: pragma_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_pragma_stmt_in_sql_stmt_core224);
                    pragma_stmt7=pragma_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, pragma_stmt7.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:91:5: attach_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_attach_stmt_in_sql_stmt_core230);
                    attach_stmt8=attach_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, attach_stmt8.getTree());

                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:92:5: detach_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_detach_stmt_in_sql_stmt_core236);
                    detach_stmt9=detach_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, detach_stmt9.getTree());

                    }
                    break;
                case 4 :
                    // sqljet/src/Sql.g:93:5: analyze_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_analyze_stmt_in_sql_stmt_core242);
                    analyze_stmt10=analyze_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, analyze_stmt10.getTree());

                    }
                    break;
                case 5 :
                    // sqljet/src/Sql.g:94:5: reindex_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_reindex_stmt_in_sql_stmt_core248);
                    reindex_stmt11=reindex_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, reindex_stmt11.getTree());

                    }
                    break;
                case 6 :
                    // sqljet/src/Sql.g:95:5: vacuum_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_vacuum_stmt_in_sql_stmt_core254);
                    vacuum_stmt12=vacuum_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, vacuum_stmt12.getTree());

                    }
                    break;
                case 7 :
                    // sqljet/src/Sql.g:97:5: select_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_select_stmt_in_sql_stmt_core263);
                    select_stmt13=select_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, select_stmt13.getTree());

                    }
                    break;
                case 8 :
                    // sqljet/src/Sql.g:98:5: insert_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_insert_stmt_in_sql_stmt_core269);
                    insert_stmt14=insert_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, insert_stmt14.getTree());

                    }
                    break;
                case 9 :
                    // sqljet/src/Sql.g:99:5: update_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_update_stmt_in_sql_stmt_core275);
                    update_stmt15=update_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, update_stmt15.getTree());

                    }
                    break;
                case 10 :
                    // sqljet/src/Sql.g:100:5: delete_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_delete_stmt_in_sql_stmt_core281);
                    delete_stmt16=delete_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, delete_stmt16.getTree());

                    }
                    break;
                case 11 :
                    // sqljet/src/Sql.g:101:5: begin_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_begin_stmt_in_sql_stmt_core287);
                    begin_stmt17=begin_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, begin_stmt17.getTree());

                    }
                    break;
                case 12 :
                    // sqljet/src/Sql.g:102:5: commit_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_commit_stmt_in_sql_stmt_core293);
                    commit_stmt18=commit_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, commit_stmt18.getTree());

                    }
                    break;
                case 13 :
                    // sqljet/src/Sql.g:103:5: rollback_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_rollback_stmt_in_sql_stmt_core299);
                    rollback_stmt19=rollback_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, rollback_stmt19.getTree());

                    }
                    break;
                case 14 :
                    // sqljet/src/Sql.g:104:5: savepoint_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_savepoint_stmt_in_sql_stmt_core305);
                    savepoint_stmt20=savepoint_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, savepoint_stmt20.getTree());

                    }
                    break;
                case 15 :
                    // sqljet/src/Sql.g:105:5: release_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_release_stmt_in_sql_stmt_core311);
                    release_stmt21=release_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, release_stmt21.getTree());

                    }
                    break;
                case 16 :
                    // sqljet/src/Sql.g:107:5: create_virtual_table_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_create_virtual_table_stmt_in_sql_stmt_core320);
                    create_virtual_table_stmt22=create_virtual_table_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, create_virtual_table_stmt22.getTree());

                    }
                    break;
                case 17 :
                    // sqljet/src/Sql.g:108:5: create_table_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_create_table_stmt_in_sql_stmt_core326);
                    create_table_stmt23=create_table_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, create_table_stmt23.getTree());

                    }
                    break;
                case 18 :
                    // sqljet/src/Sql.g:109:5: drop_table_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_drop_table_stmt_in_sql_stmt_core332);
                    drop_table_stmt24=drop_table_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, drop_table_stmt24.getTree());

                    }
                    break;
                case 19 :
                    // sqljet/src/Sql.g:110:5: alter_table_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_alter_table_stmt_in_sql_stmt_core338);
                    alter_table_stmt25=alter_table_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, alter_table_stmt25.getTree());

                    }
                    break;
                case 20 :
                    // sqljet/src/Sql.g:111:5: create_view_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_create_view_stmt_in_sql_stmt_core344);
                    create_view_stmt26=create_view_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, create_view_stmt26.getTree());

                    }
                    break;
                case 21 :
                    // sqljet/src/Sql.g:112:5: drop_view_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_drop_view_stmt_in_sql_stmt_core350);
                    drop_view_stmt27=drop_view_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, drop_view_stmt27.getTree());

                    }
                    break;
                case 22 :
                    // sqljet/src/Sql.g:113:5: create_index_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_create_index_stmt_in_sql_stmt_core356);
                    create_index_stmt28=create_index_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, create_index_stmt28.getTree());

                    }
                    break;
                case 23 :
                    // sqljet/src/Sql.g:114:5: drop_index_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_drop_index_stmt_in_sql_stmt_core362);
                    drop_index_stmt29=drop_index_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, drop_index_stmt29.getTree());

                    }
                    break;
                case 24 :
                    // sqljet/src/Sql.g:115:5: create_trigger_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_create_trigger_stmt_in_sql_stmt_core368);
                    create_trigger_stmt30=create_trigger_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, create_trigger_stmt30.getTree());

                    }
                    break;
                case 25 :
                    // sqljet/src/Sql.g:116:5: drop_trigger_stmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_drop_trigger_stmt_in_sql_stmt_core374);
                    drop_trigger_stmt31=drop_trigger_stmt();

                    state._fsp--;

                    adaptor.addChild(root_0, drop_trigger_stmt31.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "sql_stmt_core"

    public static class qualified_table_name_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "qualified_table_name"
    // sqljet/src/Sql.g:119:1: qualified_table_name : (database_name= id DOT )? table_name= id ( INDEXED BY index_name= id | NOT INDEXED )? ;
    public final SqlParser.qualified_table_name_return qualified_table_name() throws RecognitionException {
        SqlParser.qualified_table_name_return retval = new SqlParser.qualified_table_name_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DOT32=null;
        Token INDEXED33=null;
        Token BY34=null;
        Token NOT35=null;
        Token INDEXED36=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.id_return index_name = null;


        Object DOT32_tree=null;
        Object INDEXED33_tree=null;
        Object BY34_tree=null;
        Object NOT35_tree=null;
        Object INDEXED36_tree=null;

        try {
            // sqljet/src/Sql.g:119:21: ( (database_name= id DOT )? table_name= id ( INDEXED BY index_name= id | NOT INDEXED )? )
            // sqljet/src/Sql.g:119:23: (database_name= id DOT )? table_name= id ( INDEXED BY index_name= id | NOT INDEXED )?
            {
            root_0 = (Object)adaptor.nil();

            // sqljet/src/Sql.g:119:23: (database_name= id DOT )?
            int alt5=2;
            alt5 = dfa5.predict(input);
            switch (alt5) {
                case 1 :
                    // sqljet/src/Sql.g:119:24: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_qualified_table_name387);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT32=(Token)match(input,DOT,FOLLOW_DOT_in_qualified_table_name389); 
                    DOT32_tree = (Object)adaptor.create(DOT32);
                    adaptor.addChild(root_0, DOT32_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_qualified_table_name395);
            table_name=id();

            state._fsp--;

            adaptor.addChild(root_0, table_name.getTree());
            // sqljet/src/Sql.g:119:61: ( INDEXED BY index_name= id | NOT INDEXED )?
            int alt6=3;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==INDEXED) ) {
                alt6=1;
            }
            else if ( (LA6_0==NOT) ) {
                alt6=2;
            }
            switch (alt6) {
                case 1 :
                    // sqljet/src/Sql.g:119:62: INDEXED BY index_name= id
                    {
                    INDEXED33=(Token)match(input,INDEXED,FOLLOW_INDEXED_in_qualified_table_name398); 
                    INDEXED33_tree = (Object)adaptor.create(INDEXED33);
                    adaptor.addChild(root_0, INDEXED33_tree);

                    BY34=(Token)match(input,BY,FOLLOW_BY_in_qualified_table_name400); 
                    BY34_tree = (Object)adaptor.create(BY34);
                    adaptor.addChild(root_0, BY34_tree);

                    pushFollow(FOLLOW_id_in_qualified_table_name404);
                    index_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, index_name.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:119:89: NOT INDEXED
                    {
                    NOT35=(Token)match(input,NOT,FOLLOW_NOT_in_qualified_table_name408); 
                    NOT35_tree = (Object)adaptor.create(NOT35);
                    adaptor.addChild(root_0, NOT35_tree);

                    INDEXED36=(Token)match(input,INDEXED,FOLLOW_INDEXED_in_qualified_table_name410); 
                    INDEXED36_tree = (Object)adaptor.create(INDEXED36);
                    adaptor.addChild(root_0, INDEXED36_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "qualified_table_name"

    public static class expr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr"
    // sqljet/src/Sql.g:121:1: expr : or_subexpr ( OR or_subexpr )* ;
    public final SqlParser.expr_return expr() throws RecognitionException {
        SqlParser.expr_return retval = new SqlParser.expr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token OR38=null;
        SqlParser.or_subexpr_return or_subexpr37 = null;

        SqlParser.or_subexpr_return or_subexpr39 = null;


        Object OR38_tree=null;

        try {
            // sqljet/src/Sql.g:121:5: ( or_subexpr ( OR or_subexpr )* )
            // sqljet/src/Sql.g:121:7: or_subexpr ( OR or_subexpr )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_or_subexpr_in_expr419);
            or_subexpr37=or_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, or_subexpr37.getTree());
            // sqljet/src/Sql.g:121:18: ( OR or_subexpr )*
            loop7:
            do {
                int alt7=2;
                alt7 = dfa7.predict(input);
                switch (alt7) {
            	case 1 :
            	    // sqljet/src/Sql.g:121:19: OR or_subexpr
            	    {
            	    OR38=(Token)match(input,OR,FOLLOW_OR_in_expr422); 
            	    OR38_tree = (Object)adaptor.create(OR38);
            	    root_0 = (Object)adaptor.becomeRoot(OR38_tree, root_0);

            	    pushFollow(FOLLOW_or_subexpr_in_expr425);
            	    or_subexpr39=or_subexpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, or_subexpr39.getTree());

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr"

    public static class or_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "or_subexpr"
    // sqljet/src/Sql.g:123:1: or_subexpr : and_subexpr ( AND and_subexpr )* ;
    public final SqlParser.or_subexpr_return or_subexpr() throws RecognitionException {
        SqlParser.or_subexpr_return retval = new SqlParser.or_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token AND41=null;
        SqlParser.and_subexpr_return and_subexpr40 = null;

        SqlParser.and_subexpr_return and_subexpr42 = null;


        Object AND41_tree=null;

        try {
            // sqljet/src/Sql.g:123:11: ( and_subexpr ( AND and_subexpr )* )
            // sqljet/src/Sql.g:123:13: and_subexpr ( AND and_subexpr )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_and_subexpr_in_or_subexpr434);
            and_subexpr40=and_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, and_subexpr40.getTree());
            // sqljet/src/Sql.g:123:25: ( AND and_subexpr )*
            loop8:
            do {
                int alt8=2;
                alt8 = dfa8.predict(input);
                switch (alt8) {
            	case 1 :
            	    // sqljet/src/Sql.g:123:26: AND and_subexpr
            	    {
            	    AND41=(Token)match(input,AND,FOLLOW_AND_in_or_subexpr437); 
            	    AND41_tree = (Object)adaptor.create(AND41);
            	    root_0 = (Object)adaptor.becomeRoot(AND41_tree, root_0);

            	    pushFollow(FOLLOW_and_subexpr_in_or_subexpr440);
            	    and_subexpr42=and_subexpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, and_subexpr42.getTree());

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "or_subexpr"

    public static class and_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "and_subexpr"
    // sqljet/src/Sql.g:125:1: and_subexpr : eq_subexpr ( cond_expr )? ;
    public final SqlParser.and_subexpr_return and_subexpr() throws RecognitionException {
        SqlParser.and_subexpr_return retval = new SqlParser.and_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        SqlParser.eq_subexpr_return eq_subexpr43 = null;

        SqlParser.cond_expr_return cond_expr44 = null;



        try {
            // sqljet/src/Sql.g:125:12: ( eq_subexpr ( cond_expr )? )
            // sqljet/src/Sql.g:125:14: eq_subexpr ( cond_expr )?
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_eq_subexpr_in_and_subexpr449);
            eq_subexpr43=eq_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, eq_subexpr43.getTree());
            // sqljet/src/Sql.g:125:34: ( cond_expr )?
            int alt9=2;
            alt9 = dfa9.predict(input);
            switch (alt9) {
                case 1 :
                    // sqljet/src/Sql.g:125:34: cond_expr
                    {
                    pushFollow(FOLLOW_cond_expr_in_and_subexpr451);
                    cond_expr44=cond_expr();

                    state._fsp--;

                    root_0 = (Object)adaptor.becomeRoot(cond_expr44.getTree(), root_0);

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "and_subexpr"

    public static class cond_expr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "cond_expr"
    // sqljet/src/Sql.g:127:1: cond_expr : ( ( NOT )? match_op match_expr= eq_subexpr ( ESCAPE escape_expr= eq_subexpr )? -> ^( match_op $match_expr ( NOT )? ( ^( ESCAPE $escape_expr) )? ) | ( NOT )? IN LPAREN expr ( COMMA expr )* RPAREN -> ^( IN_VALUES ( NOT )? ^( IN ( expr )+ ) ) | ( NOT )? IN (database_name= id DOT )? table_name= id -> ^( IN_TABLE ( NOT )? ^( IN ^( $table_name ( $database_name)? ) ) ) | ( ISNULL -> IS_NULL | NOTNULL -> NOT_NULL | IS NULL -> IS_NULL | NOT NULL -> NOT_NULL | IS NOT NULL -> NOT_NULL ) | ( NOT )? BETWEEN e1= eq_subexpr AND e2= eq_subexpr -> ^( BETWEEN ( NOT )? ^( AND $e1 $e2) ) | ( ( EQUALS | EQUALS2 | NOT_EQUALS | NOT_EQUALS2 ) eq_subexpr )+ );
    public final SqlParser.cond_expr_return cond_expr() throws RecognitionException {
        SqlParser.cond_expr_return retval = new SqlParser.cond_expr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token NOT45=null;
        Token ESCAPE47=null;
        Token NOT48=null;
        Token IN49=null;
        Token LPAREN50=null;
        Token COMMA52=null;
        Token RPAREN54=null;
        Token NOT55=null;
        Token IN56=null;
        Token DOT57=null;
        Token ISNULL58=null;
        Token NOTNULL59=null;
        Token IS60=null;
        Token NULL61=null;
        Token NOT62=null;
        Token NULL63=null;
        Token IS64=null;
        Token NOT65=null;
        Token NULL66=null;
        Token NOT67=null;
        Token BETWEEN68=null;
        Token AND69=null;
        Token set70=null;
        SqlParser.eq_subexpr_return match_expr = null;

        SqlParser.eq_subexpr_return escape_expr = null;

        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.eq_subexpr_return e1 = null;

        SqlParser.eq_subexpr_return e2 = null;

        SqlParser.match_op_return match_op46 = null;

        SqlParser.expr_return expr51 = null;

        SqlParser.expr_return expr53 = null;

        SqlParser.eq_subexpr_return eq_subexpr71 = null;


        Object NOT45_tree=null;
        Object ESCAPE47_tree=null;
        Object NOT48_tree=null;
        Object IN49_tree=null;
        Object LPAREN50_tree=null;
        Object COMMA52_tree=null;
        Object RPAREN54_tree=null;
        Object NOT55_tree=null;
        Object IN56_tree=null;
        Object DOT57_tree=null;
        Object ISNULL58_tree=null;
        Object NOTNULL59_tree=null;
        Object IS60_tree=null;
        Object NULL61_tree=null;
        Object NOT62_tree=null;
        Object NULL63_tree=null;
        Object IS64_tree=null;
        Object NOT65_tree=null;
        Object NULL66_tree=null;
        Object NOT67_tree=null;
        Object BETWEEN68_tree=null;
        Object AND69_tree=null;
        Object set70_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_AND=new RewriteRuleTokenStream(adaptor,"token AND");
        RewriteRuleTokenStream stream_IS=new RewriteRuleTokenStream(adaptor,"token IS");
        RewriteRuleTokenStream stream_NULL=new RewriteRuleTokenStream(adaptor,"token NULL");
        RewriteRuleTokenStream stream_ESCAPE=new RewriteRuleTokenStream(adaptor,"token ESCAPE");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_NOTNULL=new RewriteRuleTokenStream(adaptor,"token NOTNULL");
        RewriteRuleTokenStream stream_ISNULL=new RewriteRuleTokenStream(adaptor,"token ISNULL");
        RewriteRuleTokenStream stream_BETWEEN=new RewriteRuleTokenStream(adaptor,"token BETWEEN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_NOT=new RewriteRuleTokenStream(adaptor,"token NOT");
        RewriteRuleTokenStream stream_IN=new RewriteRuleTokenStream(adaptor,"token IN");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_match_op=new RewriteRuleSubtreeStream(adaptor,"rule match_op");
        RewriteRuleSubtreeStream stream_eq_subexpr=new RewriteRuleSubtreeStream(adaptor,"rule eq_subexpr");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:128:3: ( ( NOT )? match_op match_expr= eq_subexpr ( ESCAPE escape_expr= eq_subexpr )? -> ^( match_op $match_expr ( NOT )? ( ^( ESCAPE $escape_expr) )? ) | ( NOT )? IN LPAREN expr ( COMMA expr )* RPAREN -> ^( IN_VALUES ( NOT )? ^( IN ( expr )+ ) ) | ( NOT )? IN (database_name= id DOT )? table_name= id -> ^( IN_TABLE ( NOT )? ^( IN ^( $table_name ( $database_name)? ) ) ) | ( ISNULL -> IS_NULL | NOTNULL -> NOT_NULL | IS NULL -> IS_NULL | NOT NULL -> NOT_NULL | IS NOT NULL -> NOT_NULL ) | ( NOT )? BETWEEN e1= eq_subexpr AND e2= eq_subexpr -> ^( BETWEEN ( NOT )? ^( AND $e1 $e2) ) | ( ( EQUALS | EQUALS2 | NOT_EQUALS | NOT_EQUALS2 ) eq_subexpr )+ )
            int alt19=6;
            alt19 = dfa19.predict(input);
            switch (alt19) {
                case 1 :
                    // sqljet/src/Sql.g:128:5: ( NOT )? match_op match_expr= eq_subexpr ( ESCAPE escape_expr= eq_subexpr )?
                    {
                    // sqljet/src/Sql.g:128:5: ( NOT )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==NOT) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // sqljet/src/Sql.g:128:5: NOT
                            {
                            NOT45=(Token)match(input,NOT,FOLLOW_NOT_in_cond_expr463);  
                            stream_NOT.add(NOT45);


                            }
                            break;

                    }

                    pushFollow(FOLLOW_match_op_in_cond_expr466);
                    match_op46=match_op();

                    state._fsp--;

                    stream_match_op.add(match_op46.getTree());
                    pushFollow(FOLLOW_eq_subexpr_in_cond_expr470);
                    match_expr=eq_subexpr();

                    state._fsp--;

                    stream_eq_subexpr.add(match_expr.getTree());
                    // sqljet/src/Sql.g:128:41: ( ESCAPE escape_expr= eq_subexpr )?
                    int alt11=2;
                    alt11 = dfa11.predict(input);
                    switch (alt11) {
                        case 1 :
                            // sqljet/src/Sql.g:128:42: ESCAPE escape_expr= eq_subexpr
                            {
                            ESCAPE47=(Token)match(input,ESCAPE,FOLLOW_ESCAPE_in_cond_expr473);  
                            stream_ESCAPE.add(ESCAPE47);

                            pushFollow(FOLLOW_eq_subexpr_in_cond_expr477);
                            escape_expr=eq_subexpr();

                            state._fsp--;

                            stream_eq_subexpr.add(escape_expr.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: NOT, escape_expr, match_expr, ESCAPE, match_op
                    // token labels: 
                    // rule labels: match_expr, retval, escape_expr
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_match_expr=new RewriteRuleSubtreeStream(adaptor,"rule match_expr",match_expr!=null?match_expr.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_escape_expr=new RewriteRuleSubtreeStream(adaptor,"rule escape_expr",escape_expr!=null?escape_expr.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 128:74: -> ^( match_op $match_expr ( NOT )? ( ^( ESCAPE $escape_expr) )? )
                    {
                        // sqljet/src/Sql.g:128:77: ^( match_op $match_expr ( NOT )? ( ^( ESCAPE $escape_expr) )? )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_match_op.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_match_expr.nextTree());
                        // sqljet/src/Sql.g:128:100: ( NOT )?
                        if ( stream_NOT.hasNext() ) {
                            adaptor.addChild(root_1, stream_NOT.nextNode());

                        }
                        stream_NOT.reset();
                        // sqljet/src/Sql.g:128:105: ( ^( ESCAPE $escape_expr) )?
                        if ( stream_escape_expr.hasNext()||stream_ESCAPE.hasNext() ) {
                            // sqljet/src/Sql.g:128:105: ^( ESCAPE $escape_expr)
                            {
                            Object root_2 = (Object)adaptor.nil();
                            root_2 = (Object)adaptor.becomeRoot(stream_ESCAPE.nextNode(), root_2);

                            adaptor.addChild(root_2, stream_escape_expr.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_escape_expr.reset();
                        stream_ESCAPE.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:129:5: ( NOT )? IN LPAREN expr ( COMMA expr )* RPAREN
                    {
                    // sqljet/src/Sql.g:129:5: ( NOT )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==NOT) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // sqljet/src/Sql.g:129:5: NOT
                            {
                            NOT48=(Token)match(input,NOT,FOLLOW_NOT_in_cond_expr505);  
                            stream_NOT.add(NOT48);


                            }
                            break;

                    }

                    IN49=(Token)match(input,IN,FOLLOW_IN_in_cond_expr508);  
                    stream_IN.add(IN49);

                    LPAREN50=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_cond_expr510);  
                    stream_LPAREN.add(LPAREN50);

                    pushFollow(FOLLOW_expr_in_cond_expr512);
                    expr51=expr();

                    state._fsp--;

                    stream_expr.add(expr51.getTree());
                    // sqljet/src/Sql.g:129:25: ( COMMA expr )*
                    loop13:
                    do {
                        int alt13=2;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0==COMMA) ) {
                            alt13=1;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:129:26: COMMA expr
                    	    {
                    	    COMMA52=(Token)match(input,COMMA,FOLLOW_COMMA_in_cond_expr515);  
                    	    stream_COMMA.add(COMMA52);

                    	    pushFollow(FOLLOW_expr_in_cond_expr517);
                    	    expr53=expr();

                    	    state._fsp--;

                    	    stream_expr.add(expr53.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop13;
                        }
                    } while (true);

                    RPAREN54=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_cond_expr521);  
                    stream_RPAREN.add(RPAREN54);



                    // AST REWRITE
                    // elements: IN, expr, NOT
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 129:46: -> ^( IN_VALUES ( NOT )? ^( IN ( expr )+ ) )
                    {
                        // sqljet/src/Sql.g:129:49: ^( IN_VALUES ( NOT )? ^( IN ( expr )+ ) )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(IN_VALUES, "IN_VALUES"), root_1);

                        // sqljet/src/Sql.g:129:61: ( NOT )?
                        if ( stream_NOT.hasNext() ) {
                            adaptor.addChild(root_1, stream_NOT.nextNode());

                        }
                        stream_NOT.reset();
                        // sqljet/src/Sql.g:129:66: ^( IN ( expr )+ )
                        {
                        Object root_2 = (Object)adaptor.nil();
                        root_2 = (Object)adaptor.becomeRoot(stream_IN.nextNode(), root_2);

                        if ( !(stream_expr.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_expr.hasNext() ) {
                            adaptor.addChild(root_2, stream_expr.nextTree());

                        }
                        stream_expr.reset();

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:130:5: ( NOT )? IN (database_name= id DOT )? table_name= id
                    {
                    // sqljet/src/Sql.g:130:5: ( NOT )?
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( (LA14_0==NOT) ) {
                        alt14=1;
                    }
                    switch (alt14) {
                        case 1 :
                            // sqljet/src/Sql.g:130:5: NOT
                            {
                            NOT55=(Token)match(input,NOT,FOLLOW_NOT_in_cond_expr543);  
                            stream_NOT.add(NOT55);


                            }
                            break;

                    }

                    IN56=(Token)match(input,IN,FOLLOW_IN_in_cond_expr546);  
                    stream_IN.add(IN56);

                    // sqljet/src/Sql.g:130:13: (database_name= id DOT )?
                    int alt15=2;
                    alt15 = dfa15.predict(input);
                    switch (alt15) {
                        case 1 :
                            // sqljet/src/Sql.g:130:14: database_name= id DOT
                            {
                            pushFollow(FOLLOW_id_in_cond_expr551);
                            database_name=id();

                            state._fsp--;

                            stream_id.add(database_name.getTree());
                            DOT57=(Token)match(input,DOT,FOLLOW_DOT_in_cond_expr553);  
                            stream_DOT.add(DOT57);


                            }
                            break;

                    }

                    pushFollow(FOLLOW_id_in_cond_expr559);
                    table_name=id();

                    state._fsp--;

                    stream_id.add(table_name.getTree());


                    // AST REWRITE
                    // elements: NOT, table_name, database_name, IN
                    // token labels: 
                    // rule labels: database_name, retval, table_name
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_table_name=new RewriteRuleSubtreeStream(adaptor,"rule table_name",table_name!=null?table_name.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 130:51: -> ^( IN_TABLE ( NOT )? ^( IN ^( $table_name ( $database_name)? ) ) )
                    {
                        // sqljet/src/Sql.g:130:54: ^( IN_TABLE ( NOT )? ^( IN ^( $table_name ( $database_name)? ) ) )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(IN_TABLE, "IN_TABLE"), root_1);

                        // sqljet/src/Sql.g:130:65: ( NOT )?
                        if ( stream_NOT.hasNext() ) {
                            adaptor.addChild(root_1, stream_NOT.nextNode());

                        }
                        stream_NOT.reset();
                        // sqljet/src/Sql.g:130:70: ^( IN ^( $table_name ( $database_name)? ) )
                        {
                        Object root_2 = (Object)adaptor.nil();
                        root_2 = (Object)adaptor.becomeRoot(stream_IN.nextNode(), root_2);

                        // sqljet/src/Sql.g:130:75: ^( $table_name ( $database_name)? )
                        {
                        Object root_3 = (Object)adaptor.nil();
                        root_3 = (Object)adaptor.becomeRoot(stream_table_name.nextNode(), root_3);

                        // sqljet/src/Sql.g:130:89: ( $database_name)?
                        if ( stream_database_name.hasNext() ) {
                            adaptor.addChild(root_3, stream_database_name.nextTree());

                        }
                        stream_database_name.reset();

                        adaptor.addChild(root_2, root_3);
                        }

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 4 :
                    // sqljet/src/Sql.g:133:5: ( ISNULL -> IS_NULL | NOTNULL -> NOT_NULL | IS NULL -> IS_NULL | NOT NULL -> NOT_NULL | IS NOT NULL -> NOT_NULL )
                    {
                    // sqljet/src/Sql.g:133:5: ( ISNULL -> IS_NULL | NOTNULL -> NOT_NULL | IS NULL -> IS_NULL | NOT NULL -> NOT_NULL | IS NOT NULL -> NOT_NULL )
                    int alt16=5;
                    switch ( input.LA(1) ) {
                    case ISNULL:
                        {
                        alt16=1;
                        }
                        break;
                    case NOTNULL:
                        {
                        alt16=2;
                        }
                        break;
                    case IS:
                        {
                        int LA16_3 = input.LA(2);

                        if ( (LA16_3==NULL) ) {
                            alt16=3;
                        }
                        else if ( (LA16_3==NOT) ) {
                            alt16=5;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 16, 3, input);

                            throw nvae;
                        }
                        }
                        break;
                    case NOT:
                        {
                        alt16=4;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 16, 0, input);

                        throw nvae;
                    }

                    switch (alt16) {
                        case 1 :
                            // sqljet/src/Sql.g:133:6: ISNULL
                            {
                            ISNULL58=(Token)match(input,ISNULL,FOLLOW_ISNULL_in_cond_expr590);  
                            stream_ISNULL.add(ISNULL58);



                            // AST REWRITE
                            // elements: 
                            // token labels: 
                            // rule labels: retval
                            // token list labels: 
                            // rule list labels: 
                            // wildcard labels: 
                            retval.tree = root_0;
                            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                            root_0 = (Object)adaptor.nil();
                            // 133:13: -> IS_NULL
                            {
                                adaptor.addChild(root_0, (Object)adaptor.create(IS_NULL, "IS_NULL"));

                            }

                            retval.tree = root_0;
                            }
                            break;
                        case 2 :
                            // sqljet/src/Sql.g:133:26: NOTNULL
                            {
                            NOTNULL59=(Token)match(input,NOTNULL,FOLLOW_NOTNULL_in_cond_expr598);  
                            stream_NOTNULL.add(NOTNULL59);



                            // AST REWRITE
                            // elements: 
                            // token labels: 
                            // rule labels: retval
                            // token list labels: 
                            // rule list labels: 
                            // wildcard labels: 
                            retval.tree = root_0;
                            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                            root_0 = (Object)adaptor.nil();
                            // 133:34: -> NOT_NULL
                            {
                                adaptor.addChild(root_0, (Object)adaptor.create(NOT_NULL, "NOT_NULL"));

                            }

                            retval.tree = root_0;
                            }
                            break;
                        case 3 :
                            // sqljet/src/Sql.g:133:48: IS NULL
                            {
                            IS60=(Token)match(input,IS,FOLLOW_IS_in_cond_expr606);  
                            stream_IS.add(IS60);

                            NULL61=(Token)match(input,NULL,FOLLOW_NULL_in_cond_expr608);  
                            stream_NULL.add(NULL61);



                            // AST REWRITE
                            // elements: 
                            // token labels: 
                            // rule labels: retval
                            // token list labels: 
                            // rule list labels: 
                            // wildcard labels: 
                            retval.tree = root_0;
                            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                            root_0 = (Object)adaptor.nil();
                            // 133:56: -> IS_NULL
                            {
                                adaptor.addChild(root_0, (Object)adaptor.create(IS_NULL, "IS_NULL"));

                            }

                            retval.tree = root_0;
                            }
                            break;
                        case 4 :
                            // sqljet/src/Sql.g:133:69: NOT NULL
                            {
                            NOT62=(Token)match(input,NOT,FOLLOW_NOT_in_cond_expr616);  
                            stream_NOT.add(NOT62);

                            NULL63=(Token)match(input,NULL,FOLLOW_NULL_in_cond_expr618);  
                            stream_NULL.add(NULL63);



                            // AST REWRITE
                            // elements: 
                            // token labels: 
                            // rule labels: retval
                            // token list labels: 
                            // rule list labels: 
                            // wildcard labels: 
                            retval.tree = root_0;
                            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                            root_0 = (Object)adaptor.nil();
                            // 133:78: -> NOT_NULL
                            {
                                adaptor.addChild(root_0, (Object)adaptor.create(NOT_NULL, "NOT_NULL"));

                            }

                            retval.tree = root_0;
                            }
                            break;
                        case 5 :
                            // sqljet/src/Sql.g:133:92: IS NOT NULL
                            {
                            IS64=(Token)match(input,IS,FOLLOW_IS_in_cond_expr626);  
                            stream_IS.add(IS64);

                            NOT65=(Token)match(input,NOT,FOLLOW_NOT_in_cond_expr628);  
                            stream_NOT.add(NOT65);

                            NULL66=(Token)match(input,NULL,FOLLOW_NULL_in_cond_expr630);  
                            stream_NULL.add(NULL66);



                            // AST REWRITE
                            // elements: 
                            // token labels: 
                            // rule labels: retval
                            // token list labels: 
                            // rule list labels: 
                            // wildcard labels: 
                            retval.tree = root_0;
                            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                            root_0 = (Object)adaptor.nil();
                            // 133:104: -> NOT_NULL
                            {
                                adaptor.addChild(root_0, (Object)adaptor.create(NOT_NULL, "NOT_NULL"));

                            }

                            retval.tree = root_0;
                            }
                            break;

                    }


                    }
                    break;
                case 5 :
                    // sqljet/src/Sql.g:134:5: ( NOT )? BETWEEN e1= eq_subexpr AND e2= eq_subexpr
                    {
                    // sqljet/src/Sql.g:134:5: ( NOT )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==NOT) ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // sqljet/src/Sql.g:134:5: NOT
                            {
                            NOT67=(Token)match(input,NOT,FOLLOW_NOT_in_cond_expr641);  
                            stream_NOT.add(NOT67);


                            }
                            break;

                    }

                    BETWEEN68=(Token)match(input,BETWEEN,FOLLOW_BETWEEN_in_cond_expr644);  
                    stream_BETWEEN.add(BETWEEN68);

                    pushFollow(FOLLOW_eq_subexpr_in_cond_expr648);
                    e1=eq_subexpr();

                    state._fsp--;

                    stream_eq_subexpr.add(e1.getTree());
                    AND69=(Token)match(input,AND,FOLLOW_AND_in_cond_expr650);  
                    stream_AND.add(AND69);

                    pushFollow(FOLLOW_eq_subexpr_in_cond_expr654);
                    e2=eq_subexpr();

                    state._fsp--;

                    stream_eq_subexpr.add(e2.getTree());


                    // AST REWRITE
                    // elements: BETWEEN, e2, AND, e1, NOT
                    // token labels: 
                    // rule labels: e2, e1, retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 134:50: -> ^( BETWEEN ( NOT )? ^( AND $e1 $e2) )
                    {
                        // sqljet/src/Sql.g:134:53: ^( BETWEEN ( NOT )? ^( AND $e1 $e2) )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_BETWEEN.nextNode(), root_1);

                        // sqljet/src/Sql.g:134:63: ( NOT )?
                        if ( stream_NOT.hasNext() ) {
                            adaptor.addChild(root_1, stream_NOT.nextNode());

                        }
                        stream_NOT.reset();
                        // sqljet/src/Sql.g:134:68: ^( AND $e1 $e2)
                        {
                        Object root_2 = (Object)adaptor.nil();
                        root_2 = (Object)adaptor.becomeRoot(stream_AND.nextNode(), root_2);

                        adaptor.addChild(root_2, stream_e1.nextTree());
                        adaptor.addChild(root_2, stream_e2.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 6 :
                    // sqljet/src/Sql.g:135:5: ( ( EQUALS | EQUALS2 | NOT_EQUALS | NOT_EQUALS2 ) eq_subexpr )+
                    {
                    root_0 = (Object)adaptor.nil();

                    // sqljet/src/Sql.g:135:5: ( ( EQUALS | EQUALS2 | NOT_EQUALS | NOT_EQUALS2 ) eq_subexpr )+
                    int cnt18=0;
                    loop18:
                    do {
                        int alt18=2;
                        alt18 = dfa18.predict(input);
                        switch (alt18) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:135:6: ( EQUALS | EQUALS2 | NOT_EQUALS | NOT_EQUALS2 ) eq_subexpr
                    	    {
                    	    set70=(Token)input.LT(1);
                    	    set70=(Token)input.LT(1);
                    	    if ( (input.LA(1)>=EQUALS && input.LA(1)<=NOT_EQUALS2) ) {
                    	        input.consume();
                    	        root_0 = (Object)adaptor.becomeRoot((Object)adaptor.create(set70), root_0);
                    	        state.errorRecovery=false;
                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        throw mse;
                    	    }

                    	    pushFollow(FOLLOW_eq_subexpr_in_cond_expr697);
                    	    eq_subexpr71=eq_subexpr();

                    	    state._fsp--;

                    	    adaptor.addChild(root_0, eq_subexpr71.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt18 >= 1 ) break loop18;
                                EarlyExitException eee =
                                    new EarlyExitException(18, input);
                                throw eee;
                        }
                        cnt18++;
                    } while (true);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "cond_expr"

    public static class match_op_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "match_op"
    // sqljet/src/Sql.g:138:1: match_op : ( LIKE | GLOB | REGEXP | MATCH );
    public final SqlParser.match_op_return match_op() throws RecognitionException {
        SqlParser.match_op_return retval = new SqlParser.match_op_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set72=null;

        Object set72_tree=null;

        try {
            // sqljet/src/Sql.g:138:9: ( LIKE | GLOB | REGEXP | MATCH )
            // sqljet/src/Sql.g:
            {
            root_0 = (Object)adaptor.nil();

            set72=(Token)input.LT(1);
            if ( (input.LA(1)>=LIKE && input.LA(1)<=MATCH) ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set72));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "match_op"

    public static class eq_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "eq_subexpr"
    // sqljet/src/Sql.g:140:1: eq_subexpr : neq_subexpr ( ( LESS | LESS_OR_EQ | GREATER | GREATER_OR_EQ ) neq_subexpr )* ;
    public final SqlParser.eq_subexpr_return eq_subexpr() throws RecognitionException {
        SqlParser.eq_subexpr_return retval = new SqlParser.eq_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set74=null;
        SqlParser.neq_subexpr_return neq_subexpr73 = null;

        SqlParser.neq_subexpr_return neq_subexpr75 = null;


        Object set74_tree=null;

        try {
            // sqljet/src/Sql.g:140:11: ( neq_subexpr ( ( LESS | LESS_OR_EQ | GREATER | GREATER_OR_EQ ) neq_subexpr )* )
            // sqljet/src/Sql.g:140:13: neq_subexpr ( ( LESS | LESS_OR_EQ | GREATER | GREATER_OR_EQ ) neq_subexpr )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_neq_subexpr_in_eq_subexpr730);
            neq_subexpr73=neq_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, neq_subexpr73.getTree());
            // sqljet/src/Sql.g:140:25: ( ( LESS | LESS_OR_EQ | GREATER | GREATER_OR_EQ ) neq_subexpr )*
            loop20:
            do {
                int alt20=2;
                alt20 = dfa20.predict(input);
                switch (alt20) {
            	case 1 :
            	    // sqljet/src/Sql.g:140:26: ( LESS | LESS_OR_EQ | GREATER | GREATER_OR_EQ ) neq_subexpr
            	    {
            	    set74=(Token)input.LT(1);
            	    set74=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LESS && input.LA(1)<=GREATER_OR_EQ) ) {
            	        input.consume();
            	        root_0 = (Object)adaptor.becomeRoot((Object)adaptor.create(set74), root_0);
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_neq_subexpr_in_eq_subexpr750);
            	    neq_subexpr75=neq_subexpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, neq_subexpr75.getTree());

            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "eq_subexpr"

    public static class neq_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "neq_subexpr"
    // sqljet/src/Sql.g:142:1: neq_subexpr : bit_subexpr ( ( SHIFT_LEFT | SHIFT_RIGHT | AMPERSAND | PIPE ) bit_subexpr )* ;
    public final SqlParser.neq_subexpr_return neq_subexpr() throws RecognitionException {
        SqlParser.neq_subexpr_return retval = new SqlParser.neq_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set77=null;
        SqlParser.bit_subexpr_return bit_subexpr76 = null;

        SqlParser.bit_subexpr_return bit_subexpr78 = null;


        Object set77_tree=null;

        try {
            // sqljet/src/Sql.g:142:12: ( bit_subexpr ( ( SHIFT_LEFT | SHIFT_RIGHT | AMPERSAND | PIPE ) bit_subexpr )* )
            // sqljet/src/Sql.g:142:14: bit_subexpr ( ( SHIFT_LEFT | SHIFT_RIGHT | AMPERSAND | PIPE ) bit_subexpr )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_bit_subexpr_in_neq_subexpr759);
            bit_subexpr76=bit_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, bit_subexpr76.getTree());
            // sqljet/src/Sql.g:142:26: ( ( SHIFT_LEFT | SHIFT_RIGHT | AMPERSAND | PIPE ) bit_subexpr )*
            loop21:
            do {
                int alt21=2;
                alt21 = dfa21.predict(input);
                switch (alt21) {
            	case 1 :
            	    // sqljet/src/Sql.g:142:27: ( SHIFT_LEFT | SHIFT_RIGHT | AMPERSAND | PIPE ) bit_subexpr
            	    {
            	    set77=(Token)input.LT(1);
            	    set77=(Token)input.LT(1);
            	    if ( (input.LA(1)>=SHIFT_LEFT && input.LA(1)<=PIPE) ) {
            	        input.consume();
            	        root_0 = (Object)adaptor.becomeRoot((Object)adaptor.create(set77), root_0);
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_bit_subexpr_in_neq_subexpr779);
            	    bit_subexpr78=bit_subexpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, bit_subexpr78.getTree());

            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "neq_subexpr"

    public static class bit_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bit_subexpr"
    // sqljet/src/Sql.g:144:1: bit_subexpr : add_subexpr ( ( PLUS | MINUS ) add_subexpr )* ;
    public final SqlParser.bit_subexpr_return bit_subexpr() throws RecognitionException {
        SqlParser.bit_subexpr_return retval = new SqlParser.bit_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set80=null;
        SqlParser.add_subexpr_return add_subexpr79 = null;

        SqlParser.add_subexpr_return add_subexpr81 = null;


        Object set80_tree=null;

        try {
            // sqljet/src/Sql.g:144:12: ( add_subexpr ( ( PLUS | MINUS ) add_subexpr )* )
            // sqljet/src/Sql.g:144:14: add_subexpr ( ( PLUS | MINUS ) add_subexpr )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_add_subexpr_in_bit_subexpr788);
            add_subexpr79=add_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, add_subexpr79.getTree());
            // sqljet/src/Sql.g:144:26: ( ( PLUS | MINUS ) add_subexpr )*
            loop22:
            do {
                int alt22=2;
                alt22 = dfa22.predict(input);
                switch (alt22) {
            	case 1 :
            	    // sqljet/src/Sql.g:144:27: ( PLUS | MINUS ) add_subexpr
            	    {
            	    set80=(Token)input.LT(1);
            	    set80=(Token)input.LT(1);
            	    if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
            	        input.consume();
            	        root_0 = (Object)adaptor.becomeRoot((Object)adaptor.create(set80), root_0);
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_add_subexpr_in_bit_subexpr800);
            	    add_subexpr81=add_subexpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, add_subexpr81.getTree());

            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bit_subexpr"

    public static class add_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "add_subexpr"
    // sqljet/src/Sql.g:146:1: add_subexpr : mul_subexpr ( ( ASTERISK | SLASH | PERCENT ) mul_subexpr )* ;
    public final SqlParser.add_subexpr_return add_subexpr() throws RecognitionException {
        SqlParser.add_subexpr_return retval = new SqlParser.add_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set83=null;
        SqlParser.mul_subexpr_return mul_subexpr82 = null;

        SqlParser.mul_subexpr_return mul_subexpr84 = null;


        Object set83_tree=null;

        try {
            // sqljet/src/Sql.g:146:12: ( mul_subexpr ( ( ASTERISK | SLASH | PERCENT ) mul_subexpr )* )
            // sqljet/src/Sql.g:146:14: mul_subexpr ( ( ASTERISK | SLASH | PERCENT ) mul_subexpr )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_mul_subexpr_in_add_subexpr809);
            mul_subexpr82=mul_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, mul_subexpr82.getTree());
            // sqljet/src/Sql.g:146:26: ( ( ASTERISK | SLASH | PERCENT ) mul_subexpr )*
            loop23:
            do {
                int alt23=2;
                alt23 = dfa23.predict(input);
                switch (alt23) {
            	case 1 :
            	    // sqljet/src/Sql.g:146:27: ( ASTERISK | SLASH | PERCENT ) mul_subexpr
            	    {
            	    set83=(Token)input.LT(1);
            	    set83=(Token)input.LT(1);
            	    if ( (input.LA(1)>=ASTERISK && input.LA(1)<=PERCENT) ) {
            	        input.consume();
            	        root_0 = (Object)adaptor.becomeRoot((Object)adaptor.create(set83), root_0);
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_mul_subexpr_in_add_subexpr825);
            	    mul_subexpr84=mul_subexpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, mul_subexpr84.getTree());

            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "add_subexpr"

    public static class mul_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "mul_subexpr"
    // sqljet/src/Sql.g:148:1: mul_subexpr : con_subexpr ( DOUBLE_PIPE con_subexpr )* ;
    public final SqlParser.mul_subexpr_return mul_subexpr() throws RecognitionException {
        SqlParser.mul_subexpr_return retval = new SqlParser.mul_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DOUBLE_PIPE86=null;
        SqlParser.con_subexpr_return con_subexpr85 = null;

        SqlParser.con_subexpr_return con_subexpr87 = null;


        Object DOUBLE_PIPE86_tree=null;

        try {
            // sqljet/src/Sql.g:148:12: ( con_subexpr ( DOUBLE_PIPE con_subexpr )* )
            // sqljet/src/Sql.g:148:14: con_subexpr ( DOUBLE_PIPE con_subexpr )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_con_subexpr_in_mul_subexpr834);
            con_subexpr85=con_subexpr();

            state._fsp--;

            adaptor.addChild(root_0, con_subexpr85.getTree());
            // sqljet/src/Sql.g:148:26: ( DOUBLE_PIPE con_subexpr )*
            loop24:
            do {
                int alt24=2;
                alt24 = dfa24.predict(input);
                switch (alt24) {
            	case 1 :
            	    // sqljet/src/Sql.g:148:27: DOUBLE_PIPE con_subexpr
            	    {
            	    DOUBLE_PIPE86=(Token)match(input,DOUBLE_PIPE,FOLLOW_DOUBLE_PIPE_in_mul_subexpr837); 
            	    DOUBLE_PIPE86_tree = (Object)adaptor.create(DOUBLE_PIPE86);
            	    root_0 = (Object)adaptor.becomeRoot(DOUBLE_PIPE86_tree, root_0);

            	    pushFollow(FOLLOW_con_subexpr_in_mul_subexpr840);
            	    con_subexpr87=con_subexpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, con_subexpr87.getTree());

            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "mul_subexpr"

    public static class con_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "con_subexpr"
    // sqljet/src/Sql.g:150:1: con_subexpr : ( unary_subexpr | unary_op unary_subexpr -> ^( unary_op unary_subexpr ) );
    public final SqlParser.con_subexpr_return con_subexpr() throws RecognitionException {
        SqlParser.con_subexpr_return retval = new SqlParser.con_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        SqlParser.unary_subexpr_return unary_subexpr88 = null;

        SqlParser.unary_op_return unary_op89 = null;

        SqlParser.unary_subexpr_return unary_subexpr90 = null;


        RewriteRuleSubtreeStream stream_unary_op=new RewriteRuleSubtreeStream(adaptor,"rule unary_op");
        RewriteRuleSubtreeStream stream_unary_subexpr=new RewriteRuleSubtreeStream(adaptor,"rule unary_subexpr");
        try {
            // sqljet/src/Sql.g:150:12: ( unary_subexpr | unary_op unary_subexpr -> ^( unary_op unary_subexpr ) )
            int alt25=2;
            alt25 = dfa25.predict(input);
            switch (alt25) {
                case 1 :
                    // sqljet/src/Sql.g:150:14: unary_subexpr
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_unary_subexpr_in_con_subexpr849);
                    unary_subexpr88=unary_subexpr();

                    state._fsp--;

                    adaptor.addChild(root_0, unary_subexpr88.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:150:30: unary_op unary_subexpr
                    {
                    pushFollow(FOLLOW_unary_op_in_con_subexpr853);
                    unary_op89=unary_op();

                    state._fsp--;

                    stream_unary_op.add(unary_op89.getTree());
                    pushFollow(FOLLOW_unary_subexpr_in_con_subexpr855);
                    unary_subexpr90=unary_subexpr();

                    state._fsp--;

                    stream_unary_subexpr.add(unary_subexpr90.getTree());


                    // AST REWRITE
                    // elements: unary_subexpr, unary_op
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 150:53: -> ^( unary_op unary_subexpr )
                    {
                        // sqljet/src/Sql.g:150:56: ^( unary_op unary_subexpr )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_unary_op.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_unary_subexpr.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "con_subexpr"

    public static class unary_op_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_op"
    // sqljet/src/Sql.g:152:1: unary_op : ( PLUS | MINUS | TILDA | NOT );
    public final SqlParser.unary_op_return unary_op() throws RecognitionException {
        SqlParser.unary_op_return retval = new SqlParser.unary_op_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set91=null;

        Object set91_tree=null;

        try {
            // sqljet/src/Sql.g:152:9: ( PLUS | MINUS | TILDA | NOT )
            // sqljet/src/Sql.g:
            {
            root_0 = (Object)adaptor.nil();

            set91=(Token)input.LT(1);
            if ( input.LA(1)==NOT||(input.LA(1)>=PLUS && input.LA(1)<=MINUS)||input.LA(1)==TILDA ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set91));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_op"

    public static class unary_subexpr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary_subexpr"
    // sqljet/src/Sql.g:154:1: unary_subexpr : atom_expr ( COLLATE collation_name= ID )? ;
    public final SqlParser.unary_subexpr_return unary_subexpr() throws RecognitionException {
        SqlParser.unary_subexpr_return retval = new SqlParser.unary_subexpr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token collation_name=null;
        Token COLLATE93=null;
        SqlParser.atom_expr_return atom_expr92 = null;


        Object collation_name_tree=null;
        Object COLLATE93_tree=null;

        try {
            // sqljet/src/Sql.g:154:14: ( atom_expr ( COLLATE collation_name= ID )? )
            // sqljet/src/Sql.g:154:16: atom_expr ( COLLATE collation_name= ID )?
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_atom_expr_in_unary_subexpr889);
            atom_expr92=atom_expr();

            state._fsp--;

            adaptor.addChild(root_0, atom_expr92.getTree());
            // sqljet/src/Sql.g:154:26: ( COLLATE collation_name= ID )?
            int alt26=2;
            alt26 = dfa26.predict(input);
            switch (alt26) {
                case 1 :
                    // sqljet/src/Sql.g:154:27: COLLATE collation_name= ID
                    {
                    COLLATE93=(Token)match(input,COLLATE,FOLLOW_COLLATE_in_unary_subexpr892); 
                    COLLATE93_tree = (Object)adaptor.create(COLLATE93);
                    root_0 = (Object)adaptor.becomeRoot(COLLATE93_tree, root_0);

                    collation_name=(Token)match(input,ID,FOLLOW_ID_in_unary_subexpr897); 
                    collation_name_tree = (Object)adaptor.create(collation_name);
                    adaptor.addChild(root_0, collation_name_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary_subexpr"

    public static class atom_expr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom_expr"
    // sqljet/src/Sql.g:156:1: atom_expr : ( literal_value | bind_parameter | ( (database_name= id DOT )? table_name= id DOT )? column_name= ID -> ^( COLUMN_EXPRESSION ^( $column_name ( ^( $table_name ( $database_name)? ) )? ) ) | name= ID LPAREN ( ( DISTINCT )? args+= expr ( COMMA args+= expr )* | ASTERISK )? RPAREN -> ^( FUNCTION_EXPRESSION $name ( DISTINCT )? ( $args)* ( ASTERISK )? ) | LPAREN expr RPAREN | CAST LPAREN expr AS type_name RPAREN | CASE (case_expr= expr )? ( when_expr )+ ( ELSE else_expr= expr )? END -> ^( CASE ( $case_expr)? ( when_expr )+ ( $else_expr)? ) | raise_function );
    public final SqlParser.atom_expr_return atom_expr() throws RecognitionException {
        SqlParser.atom_expr_return retval = new SqlParser.atom_expr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token column_name=null;
        Token name=null;
        Token DOT96=null;
        Token DOT97=null;
        Token LPAREN98=null;
        Token DISTINCT99=null;
        Token COMMA100=null;
        Token ASTERISK101=null;
        Token RPAREN102=null;
        Token LPAREN103=null;
        Token RPAREN105=null;
        Token CAST106=null;
        Token LPAREN107=null;
        Token AS109=null;
        Token RPAREN111=null;
        Token CASE112=null;
        Token ELSE114=null;
        Token END115=null;
        List list_args=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.expr_return case_expr = null;

        SqlParser.expr_return else_expr = null;

        SqlParser.literal_value_return literal_value94 = null;

        SqlParser.bind_parameter_return bind_parameter95 = null;

        SqlParser.expr_return expr104 = null;

        SqlParser.expr_return expr108 = null;

        SqlParser.type_name_return type_name110 = null;

        SqlParser.when_expr_return when_expr113 = null;

        SqlParser.raise_function_return raise_function116 = null;

        SqlParser.expr_return args = null;
         args = null;
        Object column_name_tree=null;
        Object name_tree=null;
        Object DOT96_tree=null;
        Object DOT97_tree=null;
        Object LPAREN98_tree=null;
        Object DISTINCT99_tree=null;
        Object COMMA100_tree=null;
        Object ASTERISK101_tree=null;
        Object RPAREN102_tree=null;
        Object LPAREN103_tree=null;
        Object RPAREN105_tree=null;
        Object CAST106_tree=null;
        Object LPAREN107_tree=null;
        Object AS109_tree=null;
        Object RPAREN111_tree=null;
        Object CASE112_tree=null;
        Object ELSE114_tree=null;
        Object END115_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_ASTERISK=new RewriteRuleTokenStream(adaptor,"token ASTERISK");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_CASE=new RewriteRuleTokenStream(adaptor,"token CASE");
        RewriteRuleTokenStream stream_DISTINCT=new RewriteRuleTokenStream(adaptor,"token DISTINCT");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_ELSE=new RewriteRuleTokenStream(adaptor,"token ELSE");
        RewriteRuleTokenStream stream_END=new RewriteRuleTokenStream(adaptor,"token END");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        RewriteRuleSubtreeStream stream_when_expr=new RewriteRuleSubtreeStream(adaptor,"rule when_expr");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:157:3: ( literal_value | bind_parameter | ( (database_name= id DOT )? table_name= id DOT )? column_name= ID -> ^( COLUMN_EXPRESSION ^( $column_name ( ^( $table_name ( $database_name)? ) )? ) ) | name= ID LPAREN ( ( DISTINCT )? args+= expr ( COMMA args+= expr )* | ASTERISK )? RPAREN -> ^( FUNCTION_EXPRESSION $name ( DISTINCT )? ( $args)* ( ASTERISK )? ) | LPAREN expr RPAREN | CAST LPAREN expr AS type_name RPAREN | CASE (case_expr= expr )? ( when_expr )+ ( ELSE else_expr= expr )? END -> ^( CASE ( $case_expr)? ( when_expr )+ ( $else_expr)? ) | raise_function )
            int alt35=8;
            alt35 = dfa35.predict(input);
            switch (alt35) {
                case 1 :
                    // sqljet/src/Sql.g:157:5: literal_value
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_literal_value_in_atom_expr909);
                    literal_value94=literal_value();

                    state._fsp--;

                    adaptor.addChild(root_0, literal_value94.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:158:5: bind_parameter
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_bind_parameter_in_atom_expr915);
                    bind_parameter95=bind_parameter();

                    state._fsp--;

                    adaptor.addChild(root_0, bind_parameter95.getTree());

                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:159:5: ( (database_name= id DOT )? table_name= id DOT )? column_name= ID
                    {
                    // sqljet/src/Sql.g:159:5: ( (database_name= id DOT )? table_name= id DOT )?
                    int alt28=2;
                    alt28 = dfa28.predict(input);
                    switch (alt28) {
                        case 1 :
                            // sqljet/src/Sql.g:159:6: (database_name= id DOT )? table_name= id DOT
                            {
                            // sqljet/src/Sql.g:159:6: (database_name= id DOT )?
                            int alt27=2;
                            alt27 = dfa27.predict(input);
                            switch (alt27) {
                                case 1 :
                                    // sqljet/src/Sql.g:159:7: database_name= id DOT
                                    {
                                    pushFollow(FOLLOW_id_in_atom_expr925);
                                    database_name=id();

                                    state._fsp--;

                                    stream_id.add(database_name.getTree());
                                    DOT96=(Token)match(input,DOT,FOLLOW_DOT_in_atom_expr927);  
                                    stream_DOT.add(DOT96);


                                    }
                                    break;

                            }

                            pushFollow(FOLLOW_id_in_atom_expr933);
                            table_name=id();

                            state._fsp--;

                            stream_id.add(table_name.getTree());
                            DOT97=(Token)match(input,DOT,FOLLOW_DOT_in_atom_expr935);  
                            stream_DOT.add(DOT97);


                            }
                            break;

                    }

                    column_name=(Token)match(input,ID,FOLLOW_ID_in_atom_expr941);  
                    stream_ID.add(column_name);



                    // AST REWRITE
                    // elements: database_name, column_name, table_name
                    // token labels: column_name
                    // rule labels: database_name, retval, table_name
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleTokenStream stream_column_name=new RewriteRuleTokenStream(adaptor,"token column_name",column_name);
                    RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_table_name=new RewriteRuleSubtreeStream(adaptor,"rule table_name",table_name!=null?table_name.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 159:65: -> ^( COLUMN_EXPRESSION ^( $column_name ( ^( $table_name ( $database_name)? ) )? ) )
                    {
                        // sqljet/src/Sql.g:159:68: ^( COLUMN_EXPRESSION ^( $column_name ( ^( $table_name ( $database_name)? ) )? ) )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMN_EXPRESSION, "COLUMN_EXPRESSION"), root_1);

                        // sqljet/src/Sql.g:159:88: ^( $column_name ( ^( $table_name ( $database_name)? ) )? )
                        {
                        Object root_2 = (Object)adaptor.nil();
                        root_2 = (Object)adaptor.becomeRoot(stream_column_name.nextNode(), root_2);

                        // sqljet/src/Sql.g:159:103: ( ^( $table_name ( $database_name)? ) )?
                        if ( stream_database_name.hasNext()||stream_table_name.hasNext() ) {
                            // sqljet/src/Sql.g:159:103: ^( $table_name ( $database_name)? )
                            {
                            Object root_3 = (Object)adaptor.nil();
                            root_3 = (Object)adaptor.becomeRoot(stream_table_name.nextNode(), root_3);

                            // sqljet/src/Sql.g:159:117: ( $database_name)?
                            if ( stream_database_name.hasNext() ) {
                                adaptor.addChild(root_3, stream_database_name.nextTree());

                            }
                            stream_database_name.reset();

                            adaptor.addChild(root_2, root_3);
                            }

                        }
                        stream_database_name.reset();
                        stream_table_name.reset();

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 4 :
                    // sqljet/src/Sql.g:160:5: name= ID LPAREN ( ( DISTINCT )? args+= expr ( COMMA args+= expr )* | ASTERISK )? RPAREN
                    {
                    name=(Token)match(input,ID,FOLLOW_ID_in_atom_expr970);  
                    stream_ID.add(name);

                    LPAREN98=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_atom_expr972);  
                    stream_LPAREN.add(LPAREN98);

                    // sqljet/src/Sql.g:160:20: ( ( DISTINCT )? args+= expr ( COMMA args+= expr )* | ASTERISK )?
                    int alt31=3;
                    alt31 = dfa31.predict(input);
                    switch (alt31) {
                        case 1 :
                            // sqljet/src/Sql.g:160:21: ( DISTINCT )? args+= expr ( COMMA args+= expr )*
                            {
                            // sqljet/src/Sql.g:160:21: ( DISTINCT )?
                            int alt29=2;
                            alt29 = dfa29.predict(input);
                            switch (alt29) {
                                case 1 :
                                    // sqljet/src/Sql.g:160:21: DISTINCT
                                    {
                                    DISTINCT99=(Token)match(input,DISTINCT,FOLLOW_DISTINCT_in_atom_expr975);  
                                    stream_DISTINCT.add(DISTINCT99);


                                    }
                                    break;

                            }

                            pushFollow(FOLLOW_expr_in_atom_expr980);
                            args=expr();

                            state._fsp--;

                            stream_expr.add(args.getTree());
                            if (list_args==null) list_args=new ArrayList();
                            list_args.add(args.getTree());

                            // sqljet/src/Sql.g:160:42: ( COMMA args+= expr )*
                            loop30:
                            do {
                                int alt30=2;
                                int LA30_0 = input.LA(1);

                                if ( (LA30_0==COMMA) ) {
                                    alt30=1;
                                }


                                switch (alt30) {
                            	case 1 :
                            	    // sqljet/src/Sql.g:160:43: COMMA args+= expr
                            	    {
                            	    COMMA100=(Token)match(input,COMMA,FOLLOW_COMMA_in_atom_expr983);  
                            	    stream_COMMA.add(COMMA100);

                            	    pushFollow(FOLLOW_expr_in_atom_expr987);
                            	    args=expr();

                            	    state._fsp--;

                            	    stream_expr.add(args.getTree());
                            	    if (list_args==null) list_args=new ArrayList();
                            	    list_args.add(args.getTree());


                            	    }
                            	    break;

                            	default :
                            	    break loop30;
                                }
                            } while (true);


                            }
                            break;
                        case 2 :
                            // sqljet/src/Sql.g:160:64: ASTERISK
                            {
                            ASTERISK101=(Token)match(input,ASTERISK,FOLLOW_ASTERISK_in_atom_expr993);  
                            stream_ASTERISK.add(ASTERISK101);


                            }
                            break;

                    }

                    RPAREN102=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_atom_expr997);  
                    stream_RPAREN.add(RPAREN102);



                    // AST REWRITE
                    // elements: args, name, DISTINCT, ASTERISK
                    // token labels: name
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: args
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleTokenStream stream_name=new RewriteRuleTokenStream(adaptor,"token name",name);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_args=new RewriteRuleSubtreeStream(adaptor,"token args",list_args);
                    root_0 = (Object)adaptor.nil();
                    // 160:82: -> ^( FUNCTION_EXPRESSION $name ( DISTINCT )? ( $args)* ( ASTERISK )? )
                    {
                        // sqljet/src/Sql.g:160:85: ^( FUNCTION_EXPRESSION $name ( DISTINCT )? ( $args)* ( ASTERISK )? )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(FUNCTION_EXPRESSION, "FUNCTION_EXPRESSION"), root_1);

                        adaptor.addChild(root_1, stream_name.nextNode());
                        // sqljet/src/Sql.g:160:113: ( DISTINCT )?
                        if ( stream_DISTINCT.hasNext() ) {
                            adaptor.addChild(root_1, stream_DISTINCT.nextNode());

                        }
                        stream_DISTINCT.reset();
                        // sqljet/src/Sql.g:160:123: ( $args)*
                        while ( stream_args.hasNext() ) {
                            adaptor.addChild(root_1, stream_args.nextTree());

                        }
                        stream_args.reset();
                        // sqljet/src/Sql.g:160:130: ( ASTERISK )?
                        if ( stream_ASTERISK.hasNext() ) {
                            adaptor.addChild(root_1, stream_ASTERISK.nextNode());

                        }
                        stream_ASTERISK.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 5 :
                    // sqljet/src/Sql.g:161:5: LPAREN expr RPAREN
                    {
                    root_0 = (Object)adaptor.nil();

                    LPAREN103=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_atom_expr1022); 
                    pushFollow(FOLLOW_expr_in_atom_expr1025);
                    expr104=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr104.getTree());
                    RPAREN105=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_atom_expr1027); 

                    }
                    break;
                case 6 :
                    // sqljet/src/Sql.g:162:5: CAST LPAREN expr AS type_name RPAREN
                    {
                    root_0 = (Object)adaptor.nil();

                    CAST106=(Token)match(input,CAST,FOLLOW_CAST_in_atom_expr1034); 
                    CAST106_tree = (Object)adaptor.create(CAST106);
                    root_0 = (Object)adaptor.becomeRoot(CAST106_tree, root_0);

                    LPAREN107=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_atom_expr1037); 
                    pushFollow(FOLLOW_expr_in_atom_expr1040);
                    expr108=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr108.getTree());
                    AS109=(Token)match(input,AS,FOLLOW_AS_in_atom_expr1042); 
                    pushFollow(FOLLOW_type_name_in_atom_expr1045);
                    type_name110=type_name();

                    state._fsp--;

                    adaptor.addChild(root_0, type_name110.getTree());
                    RPAREN111=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_atom_expr1047); 

                    }
                    break;
                case 7 :
                    // sqljet/src/Sql.g:165:5: CASE (case_expr= expr )? ( when_expr )+ ( ELSE else_expr= expr )? END
                    {
                    CASE112=(Token)match(input,CASE,FOLLOW_CASE_in_atom_expr1056);  
                    stream_CASE.add(CASE112);

                    // sqljet/src/Sql.g:165:10: (case_expr= expr )?
                    int alt32=2;
                    alt32 = dfa32.predict(input);
                    switch (alt32) {
                        case 1 :
                            // sqljet/src/Sql.g:165:11: case_expr= expr
                            {
                            pushFollow(FOLLOW_expr_in_atom_expr1061);
                            case_expr=expr();

                            state._fsp--;

                            stream_expr.add(case_expr.getTree());

                            }
                            break;

                    }

                    // sqljet/src/Sql.g:165:28: ( when_expr )+
                    int cnt33=0;
                    loop33:
                    do {
                        int alt33=2;
                        int LA33_0 = input.LA(1);

                        if ( (LA33_0==WHEN) ) {
                            alt33=1;
                        }


                        switch (alt33) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:165:28: when_expr
                    	    {
                    	    pushFollow(FOLLOW_when_expr_in_atom_expr1065);
                    	    when_expr113=when_expr();

                    	    state._fsp--;

                    	    stream_when_expr.add(when_expr113.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt33 >= 1 ) break loop33;
                                EarlyExitException eee =
                                    new EarlyExitException(33, input);
                                throw eee;
                        }
                        cnt33++;
                    } while (true);

                    // sqljet/src/Sql.g:165:39: ( ELSE else_expr= expr )?
                    int alt34=2;
                    int LA34_0 = input.LA(1);

                    if ( (LA34_0==ELSE) ) {
                        alt34=1;
                    }
                    switch (alt34) {
                        case 1 :
                            // sqljet/src/Sql.g:165:40: ELSE else_expr= expr
                            {
                            ELSE114=(Token)match(input,ELSE,FOLLOW_ELSE_in_atom_expr1069);  
                            stream_ELSE.add(ELSE114);

                            pushFollow(FOLLOW_expr_in_atom_expr1073);
                            else_expr=expr();

                            state._fsp--;

                            stream_expr.add(else_expr.getTree());

                            }
                            break;

                    }

                    END115=(Token)match(input,END,FOLLOW_END_in_atom_expr1077);  
                    stream_END.add(END115);



                    // AST REWRITE
                    // elements: else_expr, when_expr, CASE, case_expr
                    // token labels: 
                    // rule labels: case_expr, else_expr, retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_case_expr=new RewriteRuleSubtreeStream(adaptor,"rule case_expr",case_expr!=null?case_expr.tree:null);
                    RewriteRuleSubtreeStream stream_else_expr=new RewriteRuleSubtreeStream(adaptor,"rule else_expr",else_expr!=null?else_expr.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 165:66: -> ^( CASE ( $case_expr)? ( when_expr )+ ( $else_expr)? )
                    {
                        // sqljet/src/Sql.g:165:69: ^( CASE ( $case_expr)? ( when_expr )+ ( $else_expr)? )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_CASE.nextNode(), root_1);

                        // sqljet/src/Sql.g:165:76: ( $case_expr)?
                        if ( stream_case_expr.hasNext() ) {
                            adaptor.addChild(root_1, stream_case_expr.nextTree());

                        }
                        stream_case_expr.reset();
                        if ( !(stream_when_expr.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_when_expr.hasNext() ) {
                            adaptor.addChild(root_1, stream_when_expr.nextTree());

                        }
                        stream_when_expr.reset();
                        // sqljet/src/Sql.g:165:99: ( $else_expr)?
                        if ( stream_else_expr.hasNext() ) {
                            adaptor.addChild(root_1, stream_else_expr.nextTree());

                        }
                        stream_else_expr.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 8 :
                    // sqljet/src/Sql.g:166:5: raise_function
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_raise_function_in_atom_expr1100);
                    raise_function116=raise_function();

                    state._fsp--;

                    adaptor.addChild(root_0, raise_function116.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atom_expr"

    public static class when_expr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "when_expr"
    // sqljet/src/Sql.g:169:1: when_expr : WHEN e1= expr THEN e2= expr -> ^( WHEN $e1 $e2) ;
    public final SqlParser.when_expr_return when_expr() throws RecognitionException {
        SqlParser.when_expr_return retval = new SqlParser.when_expr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token WHEN117=null;
        Token THEN118=null;
        SqlParser.expr_return e1 = null;

        SqlParser.expr_return e2 = null;


        Object WHEN117_tree=null;
        Object THEN118_tree=null;
        RewriteRuleTokenStream stream_THEN=new RewriteRuleTokenStream(adaptor,"token THEN");
        RewriteRuleTokenStream stream_WHEN=new RewriteRuleTokenStream(adaptor,"token WHEN");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        try {
            // sqljet/src/Sql.g:169:10: ( WHEN e1= expr THEN e2= expr -> ^( WHEN $e1 $e2) )
            // sqljet/src/Sql.g:169:12: WHEN e1= expr THEN e2= expr
            {
            WHEN117=(Token)match(input,WHEN,FOLLOW_WHEN_in_when_expr1110);  
            stream_WHEN.add(WHEN117);

            pushFollow(FOLLOW_expr_in_when_expr1114);
            e1=expr();

            state._fsp--;

            stream_expr.add(e1.getTree());
            THEN118=(Token)match(input,THEN,FOLLOW_THEN_in_when_expr1116);  
            stream_THEN.add(THEN118);

            pushFollow(FOLLOW_expr_in_when_expr1120);
            e2=expr();

            state._fsp--;

            stream_expr.add(e2.getTree());


            // AST REWRITE
            // elements: e2, WHEN, e1
            // token labels: 
            // rule labels: e2, e1, retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);
            RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 169:38: -> ^( WHEN $e1 $e2)
            {
                // sqljet/src/Sql.g:169:41: ^( WHEN $e1 $e2)
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_WHEN.nextNode(), root_1);

                adaptor.addChild(root_1, stream_e1.nextTree());
                adaptor.addChild(root_1, stream_e2.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "when_expr"

    public static class literal_value_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "literal_value"
    // sqljet/src/Sql.g:171:1: literal_value : ( INTEGER -> ^( INTEGER_LITERAL INTEGER ) | FLOAT -> ^( FLOAT_LITERAL FLOAT ) | STRING -> ^( STRING_LITERAL STRING ) | BLOB -> ^( BLOB_LITERAL BLOB ) | NULL | CURRENT_TIME -> ^( FUNCTION_LITERAL CURRENT_TIME ) | CURRENT_DATE -> ^( FUNCTION_LITERAL CURRENT_DATE ) | CURRENT_TIMESTAMP -> ^( FUNCTION_LITERAL CURRENT_TIMESTAMP ) );
    public final SqlParser.literal_value_return literal_value() throws RecognitionException {
        SqlParser.literal_value_return retval = new SqlParser.literal_value_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token INTEGER119=null;
        Token FLOAT120=null;
        Token STRING121=null;
        Token BLOB122=null;
        Token NULL123=null;
        Token CURRENT_TIME124=null;
        Token CURRENT_DATE125=null;
        Token CURRENT_TIMESTAMP126=null;

        Object INTEGER119_tree=null;
        Object FLOAT120_tree=null;
        Object STRING121_tree=null;
        Object BLOB122_tree=null;
        Object NULL123_tree=null;
        Object CURRENT_TIME124_tree=null;
        Object CURRENT_DATE125_tree=null;
        Object CURRENT_TIMESTAMP126_tree=null;
        RewriteRuleTokenStream stream_CURRENT_TIME=new RewriteRuleTokenStream(adaptor,"token CURRENT_TIME");
        RewriteRuleTokenStream stream_CURRENT_TIMESTAMP=new RewriteRuleTokenStream(adaptor,"token CURRENT_TIMESTAMP");
        RewriteRuleTokenStream stream_INTEGER=new RewriteRuleTokenStream(adaptor,"token INTEGER");
        RewriteRuleTokenStream stream_BLOB=new RewriteRuleTokenStream(adaptor,"token BLOB");
        RewriteRuleTokenStream stream_CURRENT_DATE=new RewriteRuleTokenStream(adaptor,"token CURRENT_DATE");
        RewriteRuleTokenStream stream_STRING=new RewriteRuleTokenStream(adaptor,"token STRING");
        RewriteRuleTokenStream stream_FLOAT=new RewriteRuleTokenStream(adaptor,"token FLOAT");

        try {
            // sqljet/src/Sql.g:172:3: ( INTEGER -> ^( INTEGER_LITERAL INTEGER ) | FLOAT -> ^( FLOAT_LITERAL FLOAT ) | STRING -> ^( STRING_LITERAL STRING ) | BLOB -> ^( BLOB_LITERAL BLOB ) | NULL | CURRENT_TIME -> ^( FUNCTION_LITERAL CURRENT_TIME ) | CURRENT_DATE -> ^( FUNCTION_LITERAL CURRENT_DATE ) | CURRENT_TIMESTAMP -> ^( FUNCTION_LITERAL CURRENT_TIMESTAMP ) )
            int alt36=8;
            switch ( input.LA(1) ) {
            case INTEGER:
                {
                alt36=1;
                }
                break;
            case FLOAT:
                {
                alt36=2;
                }
                break;
            case STRING:
                {
                alt36=3;
                }
                break;
            case BLOB:
                {
                alt36=4;
                }
                break;
            case NULL:
                {
                alt36=5;
                }
                break;
            case CURRENT_TIME:
                {
                alt36=6;
                }
                break;
            case CURRENT_DATE:
                {
                alt36=7;
                }
                break;
            case CURRENT_TIMESTAMP:
                {
                alt36=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 36, 0, input);

                throw nvae;
            }

            switch (alt36) {
                case 1 :
                    // sqljet/src/Sql.g:172:5: INTEGER
                    {
                    INTEGER119=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_literal_value1142);  
                    stream_INTEGER.add(INTEGER119);



                    // AST REWRITE
                    // elements: INTEGER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 172:13: -> ^( INTEGER_LITERAL INTEGER )
                    {
                        // sqljet/src/Sql.g:172:16: ^( INTEGER_LITERAL INTEGER )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(INTEGER_LITERAL, "INTEGER_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_INTEGER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:173:5: FLOAT
                    {
                    FLOAT120=(Token)match(input,FLOAT,FOLLOW_FLOAT_in_literal_value1156);  
                    stream_FLOAT.add(FLOAT120);



                    // AST REWRITE
                    // elements: FLOAT
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 173:11: -> ^( FLOAT_LITERAL FLOAT )
                    {
                        // sqljet/src/Sql.g:173:14: ^( FLOAT_LITERAL FLOAT )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(FLOAT_LITERAL, "FLOAT_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_FLOAT.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:174:5: STRING
                    {
                    STRING121=(Token)match(input,STRING,FOLLOW_STRING_in_literal_value1170);  
                    stream_STRING.add(STRING121);



                    // AST REWRITE
                    // elements: STRING
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 174:12: -> ^( STRING_LITERAL STRING )
                    {
                        // sqljet/src/Sql.g:174:15: ^( STRING_LITERAL STRING )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(STRING_LITERAL, "STRING_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_STRING.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 4 :
                    // sqljet/src/Sql.g:175:5: BLOB
                    {
                    BLOB122=(Token)match(input,BLOB,FOLLOW_BLOB_in_literal_value1184);  
                    stream_BLOB.add(BLOB122);



                    // AST REWRITE
                    // elements: BLOB
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 175:10: -> ^( BLOB_LITERAL BLOB )
                    {
                        // sqljet/src/Sql.g:175:13: ^( BLOB_LITERAL BLOB )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(BLOB_LITERAL, "BLOB_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_BLOB.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 5 :
                    // sqljet/src/Sql.g:176:5: NULL
                    {
                    root_0 = (Object)adaptor.nil();

                    NULL123=(Token)match(input,NULL,FOLLOW_NULL_in_literal_value1198); 
                    NULL123_tree = (Object)adaptor.create(NULL123);
                    adaptor.addChild(root_0, NULL123_tree);


                    }
                    break;
                case 6 :
                    // sqljet/src/Sql.g:177:5: CURRENT_TIME
                    {
                    CURRENT_TIME124=(Token)match(input,CURRENT_TIME,FOLLOW_CURRENT_TIME_in_literal_value1204);  
                    stream_CURRENT_TIME.add(CURRENT_TIME124);



                    // AST REWRITE
                    // elements: CURRENT_TIME
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 177:18: -> ^( FUNCTION_LITERAL CURRENT_TIME )
                    {
                        // sqljet/src/Sql.g:177:21: ^( FUNCTION_LITERAL CURRENT_TIME )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(FUNCTION_LITERAL, "FUNCTION_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_CURRENT_TIME.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 7 :
                    // sqljet/src/Sql.g:178:5: CURRENT_DATE
                    {
                    CURRENT_DATE125=(Token)match(input,CURRENT_DATE,FOLLOW_CURRENT_DATE_in_literal_value1218);  
                    stream_CURRENT_DATE.add(CURRENT_DATE125);



                    // AST REWRITE
                    // elements: CURRENT_DATE
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 178:18: -> ^( FUNCTION_LITERAL CURRENT_DATE )
                    {
                        // sqljet/src/Sql.g:178:21: ^( FUNCTION_LITERAL CURRENT_DATE )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(FUNCTION_LITERAL, "FUNCTION_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_CURRENT_DATE.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 8 :
                    // sqljet/src/Sql.g:179:5: CURRENT_TIMESTAMP
                    {
                    CURRENT_TIMESTAMP126=(Token)match(input,CURRENT_TIMESTAMP,FOLLOW_CURRENT_TIMESTAMP_in_literal_value1232);  
                    stream_CURRENT_TIMESTAMP.add(CURRENT_TIMESTAMP126);



                    // AST REWRITE
                    // elements: CURRENT_TIMESTAMP
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 179:23: -> ^( FUNCTION_LITERAL CURRENT_TIMESTAMP )
                    {
                        // sqljet/src/Sql.g:179:26: ^( FUNCTION_LITERAL CURRENT_TIMESTAMP )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(FUNCTION_LITERAL, "FUNCTION_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_CURRENT_TIMESTAMP.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "literal_value"

    public static class bind_parameter_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "bind_parameter"
    // sqljet/src/Sql.g:182:1: bind_parameter : ( QUESTION -> BIND | QUESTION position= INTEGER -> ^( BIND $position) | COLON name= id -> ^( BIND_NAME $name) | AT name= id -> ^( BIND_NAME $name) );
    public final SqlParser.bind_parameter_return bind_parameter() throws RecognitionException {
        SqlParser.bind_parameter_return retval = new SqlParser.bind_parameter_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token position=null;
        Token QUESTION127=null;
        Token QUESTION128=null;
        Token COLON129=null;
        Token AT130=null;
        SqlParser.id_return name = null;


        Object position_tree=null;
        Object QUESTION127_tree=null;
        Object QUESTION128_tree=null;
        Object COLON129_tree=null;
        Object AT130_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_INTEGER=new RewriteRuleTokenStream(adaptor,"token INTEGER");
        RewriteRuleTokenStream stream_QUESTION=new RewriteRuleTokenStream(adaptor,"token QUESTION");
        RewriteRuleTokenStream stream_AT=new RewriteRuleTokenStream(adaptor,"token AT");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:183:3: ( QUESTION -> BIND | QUESTION position= INTEGER -> ^( BIND $position) | COLON name= id -> ^( BIND_NAME $name) | AT name= id -> ^( BIND_NAME $name) )
            int alt37=4;
            alt37 = dfa37.predict(input);
            switch (alt37) {
                case 1 :
                    // sqljet/src/Sql.g:183:5: QUESTION
                    {
                    QUESTION127=(Token)match(input,QUESTION,FOLLOW_QUESTION_in_bind_parameter1253);  
                    stream_QUESTION.add(QUESTION127);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 183:14: -> BIND
                    {
                        adaptor.addChild(root_0, (Object)adaptor.create(BIND, "BIND"));

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:184:5: QUESTION position= INTEGER
                    {
                    QUESTION128=(Token)match(input,QUESTION,FOLLOW_QUESTION_in_bind_parameter1263);  
                    stream_QUESTION.add(QUESTION128);

                    position=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_bind_parameter1267);  
                    stream_INTEGER.add(position);



                    // AST REWRITE
                    // elements: position
                    // token labels: position
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleTokenStream stream_position=new RewriteRuleTokenStream(adaptor,"token position",position);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 184:31: -> ^( BIND $position)
                    {
                        // sqljet/src/Sql.g:184:34: ^( BIND $position)
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(BIND, "BIND"), root_1);

                        adaptor.addChild(root_1, stream_position.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:185:5: COLON name= id
                    {
                    COLON129=(Token)match(input,COLON,FOLLOW_COLON_in_bind_parameter1282);  
                    stream_COLON.add(COLON129);

                    pushFollow(FOLLOW_id_in_bind_parameter1286);
                    name=id();

                    state._fsp--;

                    stream_id.add(name.getTree());


                    // AST REWRITE
                    // elements: name
                    // token labels: 
                    // rule labels: retval, name
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name",name!=null?name.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 185:19: -> ^( BIND_NAME $name)
                    {
                        // sqljet/src/Sql.g:185:22: ^( BIND_NAME $name)
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(BIND_NAME, "BIND_NAME"), root_1);

                        adaptor.addChild(root_1, stream_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 4 :
                    // sqljet/src/Sql.g:186:5: AT name= id
                    {
                    AT130=(Token)match(input,AT,FOLLOW_AT_in_bind_parameter1301);  
                    stream_AT.add(AT130);

                    pushFollow(FOLLOW_id_in_bind_parameter1305);
                    name=id();

                    state._fsp--;

                    stream_id.add(name.getTree());


                    // AST REWRITE
                    // elements: name
                    // token labels: 
                    // rule labels: retval, name
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name",name!=null?name.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 186:16: -> ^( BIND_NAME $name)
                    {
                        // sqljet/src/Sql.g:186:19: ^( BIND_NAME $name)
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(BIND_NAME, "BIND_NAME"), root_1);

                        adaptor.addChild(root_1, stream_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "bind_parameter"

    public static class raise_function_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "raise_function"
    // sqljet/src/Sql.g:191:1: raise_function : RAISE LPAREN ( IGNORE | ( ROLLBACK | ABORT | FAIL ) COMMA error_message= STRING ) RPAREN ;
    public final SqlParser.raise_function_return raise_function() throws RecognitionException {
        SqlParser.raise_function_return retval = new SqlParser.raise_function_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token error_message=null;
        Token RAISE131=null;
        Token LPAREN132=null;
        Token IGNORE133=null;
        Token set134=null;
        Token COMMA135=null;
        Token RPAREN136=null;

        Object error_message_tree=null;
        Object RAISE131_tree=null;
        Object LPAREN132_tree=null;
        Object IGNORE133_tree=null;
        Object set134_tree=null;
        Object COMMA135_tree=null;
        Object RPAREN136_tree=null;

        try {
            // sqljet/src/Sql.g:191:15: ( RAISE LPAREN ( IGNORE | ( ROLLBACK | ABORT | FAIL ) COMMA error_message= STRING ) RPAREN )
            // sqljet/src/Sql.g:191:17: RAISE LPAREN ( IGNORE | ( ROLLBACK | ABORT | FAIL ) COMMA error_message= STRING ) RPAREN
            {
            root_0 = (Object)adaptor.nil();

            RAISE131=(Token)match(input,RAISE,FOLLOW_RAISE_in_raise_function1326); 
            RAISE131_tree = (Object)adaptor.create(RAISE131);
            root_0 = (Object)adaptor.becomeRoot(RAISE131_tree, root_0);

            LPAREN132=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_raise_function1329); 
            // sqljet/src/Sql.g:191:32: ( IGNORE | ( ROLLBACK | ABORT | FAIL ) COMMA error_message= STRING )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==IGNORE) ) {
                alt38=1;
            }
            else if ( ((LA38_0>=ROLLBACK && LA38_0<=FAIL)) ) {
                alt38=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // sqljet/src/Sql.g:191:33: IGNORE
                    {
                    IGNORE133=(Token)match(input,IGNORE,FOLLOW_IGNORE_in_raise_function1333); 
                    IGNORE133_tree = (Object)adaptor.create(IGNORE133);
                    adaptor.addChild(root_0, IGNORE133_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:191:42: ( ROLLBACK | ABORT | FAIL ) COMMA error_message= STRING
                    {
                    set134=(Token)input.LT(1);
                    if ( (input.LA(1)>=ROLLBACK && input.LA(1)<=FAIL) ) {
                        input.consume();
                        adaptor.addChild(root_0, (Object)adaptor.create(set134));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }

                    COMMA135=(Token)match(input,COMMA,FOLLOW_COMMA_in_raise_function1349); 
                    error_message=(Token)match(input,STRING,FOLLOW_STRING_in_raise_function1354); 
                    error_message_tree = (Object)adaptor.create(error_message);
                    adaptor.addChild(root_0, error_message_tree);


                    }
                    break;

            }

            RPAREN136=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_raise_function1357); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "raise_function"

    public static class type_name_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "type_name"
    // sqljet/src/Sql.g:193:1: type_name : (names+= ID )+ ( LPAREN size1= signed_number ( COMMA size2= signed_number )? RPAREN )? -> ^( TYPE ^( TYPE_PARAMS ( $size1)? ( $size2)? ) ( $names)+ ) ;
    public final SqlParser.type_name_return type_name() throws RecognitionException {
        SqlParser.type_name_return retval = new SqlParser.type_name_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token LPAREN137=null;
        Token COMMA138=null;
        Token RPAREN139=null;
        Token names=null;
        List list_names=null;
        SqlParser.signed_number_return size1 = null;

        SqlParser.signed_number_return size2 = null;


        Object LPAREN137_tree=null;
        Object COMMA138_tree=null;
        Object RPAREN139_tree=null;
        Object names_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleSubtreeStream stream_signed_number=new RewriteRuleSubtreeStream(adaptor,"rule signed_number");
        try {
            // sqljet/src/Sql.g:193:10: ( (names+= ID )+ ( LPAREN size1= signed_number ( COMMA size2= signed_number )? RPAREN )? -> ^( TYPE ^( TYPE_PARAMS ( $size1)? ( $size2)? ) ( $names)+ ) )
            // sqljet/src/Sql.g:193:12: (names+= ID )+ ( LPAREN size1= signed_number ( COMMA size2= signed_number )? RPAREN )?
            {
            // sqljet/src/Sql.g:193:17: (names+= ID )+
            int cnt39=0;
            loop39:
            do {
                int alt39=2;
                alt39 = dfa39.predict(input);
                switch (alt39) {
            	case 1 :
            	    // sqljet/src/Sql.g:193:17: names+= ID
            	    {
            	    names=(Token)match(input,ID,FOLLOW_ID_in_type_name1367);  
            	    stream_ID.add(names);

            	    if (list_names==null) list_names=new ArrayList();
            	    list_names.add(names);


            	    }
            	    break;

            	default :
            	    if ( cnt39 >= 1 ) break loop39;
                        EarlyExitException eee =
                            new EarlyExitException(39, input);
                        throw eee;
                }
                cnt39++;
            } while (true);

            // sqljet/src/Sql.g:193:23: ( LPAREN size1= signed_number ( COMMA size2= signed_number )? RPAREN )?
            int alt41=2;
            alt41 = dfa41.predict(input);
            switch (alt41) {
                case 1 :
                    // sqljet/src/Sql.g:193:24: LPAREN size1= signed_number ( COMMA size2= signed_number )? RPAREN
                    {
                    LPAREN137=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_type_name1371);  
                    stream_LPAREN.add(LPAREN137);

                    pushFollow(FOLLOW_signed_number_in_type_name1375);
                    size1=signed_number();

                    state._fsp--;

                    stream_signed_number.add(size1.getTree());
                    // sqljet/src/Sql.g:193:51: ( COMMA size2= signed_number )?
                    int alt40=2;
                    int LA40_0 = input.LA(1);

                    if ( (LA40_0==COMMA) ) {
                        alt40=1;
                    }
                    switch (alt40) {
                        case 1 :
                            // sqljet/src/Sql.g:193:52: COMMA size2= signed_number
                            {
                            COMMA138=(Token)match(input,COMMA,FOLLOW_COMMA_in_type_name1378);  
                            stream_COMMA.add(COMMA138);

                            pushFollow(FOLLOW_signed_number_in_type_name1382);
                            size2=signed_number();

                            state._fsp--;

                            stream_signed_number.add(size2.getTree());

                            }
                            break;

                    }

                    RPAREN139=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_type_name1386);  
                    stream_RPAREN.add(RPAREN139);


                    }
                    break;

            }



            // AST REWRITE
            // elements: size2, names, size1
            // token labels: 
            // rule labels: size2, size1, retval
            // token list labels: names
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_names=new RewriteRuleTokenStream(adaptor,"token names", list_names);
            RewriteRuleSubtreeStream stream_size2=new RewriteRuleSubtreeStream(adaptor,"rule size2",size2!=null?size2.tree:null);
            RewriteRuleSubtreeStream stream_size1=new RewriteRuleSubtreeStream(adaptor,"rule size1",size1!=null?size1.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 194:1: -> ^( TYPE ^( TYPE_PARAMS ( $size1)? ( $size2)? ) ( $names)+ )
            {
                // sqljet/src/Sql.g:194:4: ^( TYPE ^( TYPE_PARAMS ( $size1)? ( $size2)? ) ( $names)+ )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(TYPE, "TYPE"), root_1);

                // sqljet/src/Sql.g:194:11: ^( TYPE_PARAMS ( $size1)? ( $size2)? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(TYPE_PARAMS, "TYPE_PARAMS"), root_2);

                // sqljet/src/Sql.g:194:25: ( $size1)?
                if ( stream_size1.hasNext() ) {
                    adaptor.addChild(root_2, stream_size1.nextTree());

                }
                stream_size1.reset();
                // sqljet/src/Sql.g:194:33: ( $size2)?
                if ( stream_size2.hasNext() ) {
                    adaptor.addChild(root_2, stream_size2.nextTree());

                }
                stream_size2.reset();

                adaptor.addChild(root_1, root_2);
                }
                if ( !(stream_names.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_names.hasNext() ) {
                    adaptor.addChild(root_1, stream_names.nextNode());

                }
                stream_names.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "type_name"

    public static class signed_number_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "signed_number"
    // sqljet/src/Sql.g:196:1: signed_number : ( PLUS | MINUS )? ( INTEGER | FLOAT ) ;
    public final SqlParser.signed_number_return signed_number() throws RecognitionException {
        SqlParser.signed_number_return retval = new SqlParser.signed_number_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set140=null;
        Token set141=null;

        Object set140_tree=null;
        Object set141_tree=null;

        try {
            // sqljet/src/Sql.g:196:14: ( ( PLUS | MINUS )? ( INTEGER | FLOAT ) )
            // sqljet/src/Sql.g:196:16: ( PLUS | MINUS )? ( INTEGER | FLOAT )
            {
            root_0 = (Object)adaptor.nil();

            // sqljet/src/Sql.g:196:16: ( PLUS | MINUS )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( ((LA42_0>=PLUS && LA42_0<=MINUS)) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // sqljet/src/Sql.g:
                    {
                    set140=(Token)input.LT(1);
                    if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
                        input.consume();
                        adaptor.addChild(root_0, (Object)adaptor.create(set140));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            set141=(Token)input.LT(1);
            if ( (input.LA(1)>=INTEGER && input.LA(1)<=FLOAT) ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set141));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "signed_number"

    public static class pragma_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pragma_stmt"
    // sqljet/src/Sql.g:199:1: pragma_stmt : PRAGMA (database_name= id DOT )? pragma_name= id ( EQUALS pragma_value | LPAREN pragma_value RPAREN )? -> ^( PRAGMA ^( $pragma_name ( $database_name)? ) ( pragma_value )? ) ;
    public final SqlParser.pragma_stmt_return pragma_stmt() throws RecognitionException {
        SqlParser.pragma_stmt_return retval = new SqlParser.pragma_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PRAGMA142=null;
        Token DOT143=null;
        Token EQUALS144=null;
        Token LPAREN146=null;
        Token RPAREN148=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return pragma_name = null;

        SqlParser.pragma_value_return pragma_value145 = null;

        SqlParser.pragma_value_return pragma_value147 = null;


        Object PRAGMA142_tree=null;
        Object DOT143_tree=null;
        Object EQUALS144_tree=null;
        Object LPAREN146_tree=null;
        Object RPAREN148_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_EQUALS=new RewriteRuleTokenStream(adaptor,"token EQUALS");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_PRAGMA=new RewriteRuleTokenStream(adaptor,"token PRAGMA");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_pragma_value=new RewriteRuleSubtreeStream(adaptor,"rule pragma_value");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:199:12: ( PRAGMA (database_name= id DOT )? pragma_name= id ( EQUALS pragma_value | LPAREN pragma_value RPAREN )? -> ^( PRAGMA ^( $pragma_name ( $database_name)? ) ( pragma_value )? ) )
            // sqljet/src/Sql.g:199:14: PRAGMA (database_name= id DOT )? pragma_name= id ( EQUALS pragma_value | LPAREN pragma_value RPAREN )?
            {
            PRAGMA142=(Token)match(input,PRAGMA,FOLLOW_PRAGMA_in_pragma_stmt1440);  
            stream_PRAGMA.add(PRAGMA142);

            // sqljet/src/Sql.g:199:21: (database_name= id DOT )?
            int alt43=2;
            alt43 = dfa43.predict(input);
            switch (alt43) {
                case 1 :
                    // sqljet/src/Sql.g:199:22: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_pragma_stmt1445);
                    database_name=id();

                    state._fsp--;

                    stream_id.add(database_name.getTree());
                    DOT143=(Token)match(input,DOT,FOLLOW_DOT_in_pragma_stmt1447);  
                    stream_DOT.add(DOT143);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_pragma_stmt1453);
            pragma_name=id();

            state._fsp--;

            stream_id.add(pragma_name.getTree());
            // sqljet/src/Sql.g:199:60: ( EQUALS pragma_value | LPAREN pragma_value RPAREN )?
            int alt44=3;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==EQUALS) ) {
                alt44=1;
            }
            else if ( (LA44_0==LPAREN) ) {
                alt44=2;
            }
            switch (alt44) {
                case 1 :
                    // sqljet/src/Sql.g:199:61: EQUALS pragma_value
                    {
                    EQUALS144=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_pragma_stmt1456);  
                    stream_EQUALS.add(EQUALS144);

                    pushFollow(FOLLOW_pragma_value_in_pragma_stmt1458);
                    pragma_value145=pragma_value();

                    state._fsp--;

                    stream_pragma_value.add(pragma_value145.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:199:83: LPAREN pragma_value RPAREN
                    {
                    LPAREN146=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_pragma_stmt1462);  
                    stream_LPAREN.add(LPAREN146);

                    pushFollow(FOLLOW_pragma_value_in_pragma_stmt1464);
                    pragma_value147=pragma_value();

                    state._fsp--;

                    stream_pragma_value.add(pragma_value147.getTree());
                    RPAREN148=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_pragma_stmt1466);  
                    stream_RPAREN.add(RPAREN148);


                    }
                    break;

            }



            // AST REWRITE
            // elements: PRAGMA, pragma_name, database_name, pragma_value
            // token labels: 
            // rule labels: pragma_name, database_name, retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_pragma_name=new RewriteRuleSubtreeStream(adaptor,"rule pragma_name",pragma_name!=null?pragma_name.tree:null);
            RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 200:1: -> ^( PRAGMA ^( $pragma_name ( $database_name)? ) ( pragma_value )? )
            {
                // sqljet/src/Sql.g:200:4: ^( PRAGMA ^( $pragma_name ( $database_name)? ) ( pragma_value )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_PRAGMA.nextNode(), root_1);

                // sqljet/src/Sql.g:200:13: ^( $pragma_name ( $database_name)? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot(stream_pragma_name.nextNode(), root_2);

                // sqljet/src/Sql.g:200:28: ( $database_name)?
                if ( stream_database_name.hasNext() ) {
                    adaptor.addChild(root_2, stream_database_name.nextTree());

                }
                stream_database_name.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:200:45: ( pragma_value )?
                if ( stream_pragma_value.hasNext() ) {
                    adaptor.addChild(root_1, stream_pragma_value.nextTree());

                }
                stream_pragma_value.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pragma_stmt"

    public static class pragma_value_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pragma_value"
    // sqljet/src/Sql.g:202:1: pragma_value : ( signed_number -> ^( FLOAT_LITERAL signed_number ) | id -> ^( ID_LITERAL id ) | STRING -> ^( STRING_LITERAL STRING ) );
    public final SqlParser.pragma_value_return pragma_value() throws RecognitionException {
        SqlParser.pragma_value_return retval = new SqlParser.pragma_value_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token STRING151=null;
        SqlParser.signed_number_return signed_number149 = null;

        SqlParser.id_return id150 = null;


        Object STRING151_tree=null;
        RewriteRuleTokenStream stream_STRING=new RewriteRuleTokenStream(adaptor,"token STRING");
        RewriteRuleSubtreeStream stream_signed_number=new RewriteRuleSubtreeStream(adaptor,"rule signed_number");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:203:2: ( signed_number -> ^( FLOAT_LITERAL signed_number ) | id -> ^( ID_LITERAL id ) | STRING -> ^( STRING_LITERAL STRING ) )
            int alt45=3;
            switch ( input.LA(1) ) {
            case PLUS:
            case MINUS:
            case INTEGER:
            case FLOAT:
                {
                alt45=1;
                }
                break;
            case EXPLAIN:
            case QUERY:
            case PLAN:
            case INDEXED:
            case BY:
            case OR:
            case AND:
            case ESCAPE:
            case IS:
            case NULL:
            case BETWEEN:
            case COLLATE:
            case ID:
            case DISTINCT:
            case CAST:
            case AS:
            case CASE:
            case ELSE:
            case END:
            case WHEN:
            case THEN:
            case CURRENT_TIME:
            case CURRENT_DATE:
            case CURRENT_TIMESTAMP:
            case RAISE:
            case IGNORE:
            case ROLLBACK:
            case ABORT:
            case FAIL:
            case PRAGMA:
            case ATTACH:
            case DATABASE:
            case DETACH:
            case ANALYZE:
            case REINDEX:
            case VACUUM:
            case REPLACE:
            case ASC:
            case DESC:
            case ORDER:
            case LIMIT:
            case OFFSET:
            case UNION:
            case ALL:
            case INTERSECT:
            case EXCEPT:
            case SELECT:
            case FROM:
            case WHERE:
            case GROUP:
            case HAVING:
            case NATURAL:
            case LEFT:
            case OUTER:
            case INNER:
            case CROSS:
            case JOIN:
            case ON:
            case USING:
            case INSERT:
            case INTO:
            case VALUES:
            case DEFAULT:
            case UPDATE:
            case SET:
            case DELETE:
            case BEGIN:
            case DEFERRED:
            case IMMEDIATE:
            case EXCLUSIVE:
            case TRANSACTION:
            case COMMIT:
            case TO:
            case SAVEPOINT:
            case RELEASE:
            case CONFLICT:
            case CREATE:
            case VIRTUAL:
            case TABLE:
            case TEMPORARY:
            case IF:
            case EXISTS:
            case CONSTRAINT:
            case PRIMARY:
            case KEY:
            case AUTOINCREMENT:
            case UNIQUE:
            case CHECK:
            case FOREIGN:
            case REFERENCES:
            case CASCADE:
            case RESTRICT:
            case DEFERRABLE:
            case INITIALLY:
            case DROP:
            case ALTER:
            case RENAME:
            case ADD:
            case COLUMN:
            case VIEW:
            case INDEX:
            case TRIGGER:
            case BEFORE:
            case AFTER:
            case INSTEAD:
            case OF:
            case FOR:
            case EACH:
            case ROW:
                {
                alt45=2;
                }
                break;
            case STRING:
                {
                alt45=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 45, 0, input);

                throw nvae;
            }

            switch (alt45) {
                case 1 :
                    // sqljet/src/Sql.g:203:4: signed_number
                    {
                    pushFollow(FOLLOW_signed_number_in_pragma_value1495);
                    signed_number149=signed_number();

                    state._fsp--;

                    stream_signed_number.add(signed_number149.getTree());


                    // AST REWRITE
                    // elements: signed_number
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 203:18: -> ^( FLOAT_LITERAL signed_number )
                    {
                        // sqljet/src/Sql.g:203:21: ^( FLOAT_LITERAL signed_number )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(FLOAT_LITERAL, "FLOAT_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_signed_number.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:204:4: id
                    {
                    pushFollow(FOLLOW_id_in_pragma_value1508);
                    id150=id();

                    state._fsp--;

                    stream_id.add(id150.getTree());


                    // AST REWRITE
                    // elements: id
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 204:7: -> ^( ID_LITERAL id )
                    {
                        // sqljet/src/Sql.g:204:10: ^( ID_LITERAL id )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(ID_LITERAL, "ID_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_id.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:205:4: STRING
                    {
                    STRING151=(Token)match(input,STRING,FOLLOW_STRING_in_pragma_value1521);  
                    stream_STRING.add(STRING151);



                    // AST REWRITE
                    // elements: STRING
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 205:11: -> ^( STRING_LITERAL STRING )
                    {
                        // sqljet/src/Sql.g:205:14: ^( STRING_LITERAL STRING )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(STRING_LITERAL, "STRING_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_STRING.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pragma_value"

    public static class attach_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "attach_stmt"
    // sqljet/src/Sql.g:209:1: attach_stmt : ATTACH ( DATABASE )? filename= ( STRING | id ) AS database_name= id ;
    public final SqlParser.attach_stmt_return attach_stmt() throws RecognitionException {
        SqlParser.attach_stmt_return retval = new SqlParser.attach_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token filename=null;
        Token ATTACH152=null;
        Token DATABASE153=null;
        Token STRING154=null;
        Token AS156=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return id155 = null;


        Object filename_tree=null;
        Object ATTACH152_tree=null;
        Object DATABASE153_tree=null;
        Object STRING154_tree=null;
        Object AS156_tree=null;

        try {
            // sqljet/src/Sql.g:209:12: ( ATTACH ( DATABASE )? filename= ( STRING | id ) AS database_name= id )
            // sqljet/src/Sql.g:209:14: ATTACH ( DATABASE )? filename= ( STRING | id ) AS database_name= id
            {
            root_0 = (Object)adaptor.nil();

            ATTACH152=(Token)match(input,ATTACH,FOLLOW_ATTACH_in_attach_stmt1539); 
            ATTACH152_tree = (Object)adaptor.create(ATTACH152);
            adaptor.addChild(root_0, ATTACH152_tree);

            // sqljet/src/Sql.g:209:21: ( DATABASE )?
            int alt46=2;
            alt46 = dfa46.predict(input);
            switch (alt46) {
                case 1 :
                    // sqljet/src/Sql.g:209:22: DATABASE
                    {
                    DATABASE153=(Token)match(input,DATABASE,FOLLOW_DATABASE_in_attach_stmt1542); 
                    DATABASE153_tree = (Object)adaptor.create(DATABASE153);
                    adaptor.addChild(root_0, DATABASE153_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:209:42: ( STRING | id )
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==STRING) ) {
                alt47=1;
            }
            else if ( ((LA47_0>=EXPLAIN && LA47_0<=PLAN)||(LA47_0>=INDEXED && LA47_0<=BY)||(LA47_0>=OR && LA47_0<=ESCAPE)||(LA47_0>=IS && LA47_0<=BETWEEN)||(LA47_0>=COLLATE && LA47_0<=THEN)||(LA47_0>=CURRENT_TIME && LA47_0<=CURRENT_TIMESTAMP)||(LA47_0>=RAISE && LA47_0<=ROW)) ) {
                alt47=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 47, 0, input);

                throw nvae;
            }
            switch (alt47) {
                case 1 :
                    // sqljet/src/Sql.g:209:43: STRING
                    {
                    STRING154=(Token)match(input,STRING,FOLLOW_STRING_in_attach_stmt1549); 
                    STRING154_tree = (Object)adaptor.create(STRING154);
                    adaptor.addChild(root_0, STRING154_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:209:52: id
                    {
                    pushFollow(FOLLOW_id_in_attach_stmt1553);
                    id155=id();

                    state._fsp--;

                    adaptor.addChild(root_0, id155.getTree());

                    }
                    break;

            }

            AS156=(Token)match(input,AS,FOLLOW_AS_in_attach_stmt1556); 
            AS156_tree = (Object)adaptor.create(AS156);
            adaptor.addChild(root_0, AS156_tree);

            pushFollow(FOLLOW_id_in_attach_stmt1560);
            database_name=id();

            state._fsp--;

            adaptor.addChild(root_0, database_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "attach_stmt"

    public static class detach_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "detach_stmt"
    // sqljet/src/Sql.g:212:1: detach_stmt : DETACH ( DATABASE )? database_name= id ;
    public final SqlParser.detach_stmt_return detach_stmt() throws RecognitionException {
        SqlParser.detach_stmt_return retval = new SqlParser.detach_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DETACH157=null;
        Token DATABASE158=null;
        SqlParser.id_return database_name = null;


        Object DETACH157_tree=null;
        Object DATABASE158_tree=null;

        try {
            // sqljet/src/Sql.g:212:12: ( DETACH ( DATABASE )? database_name= id )
            // sqljet/src/Sql.g:212:14: DETACH ( DATABASE )? database_name= id
            {
            root_0 = (Object)adaptor.nil();

            DETACH157=(Token)match(input,DETACH,FOLLOW_DETACH_in_detach_stmt1568); 
            DETACH157_tree = (Object)adaptor.create(DETACH157);
            adaptor.addChild(root_0, DETACH157_tree);

            // sqljet/src/Sql.g:212:21: ( DATABASE )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==DATABASE) ) {
                int LA48_1 = input.LA(2);

                if ( ((LA48_1>=EXPLAIN && LA48_1<=PLAN)||(LA48_1>=INDEXED && LA48_1<=BY)||(LA48_1>=OR && LA48_1<=ESCAPE)||(LA48_1>=IS && LA48_1<=BETWEEN)||(LA48_1>=COLLATE && LA48_1<=THEN)||(LA48_1>=CURRENT_TIME && LA48_1<=CURRENT_TIMESTAMP)||(LA48_1>=RAISE && LA48_1<=ROW)) ) {
                    alt48=1;
                }
            }
            switch (alt48) {
                case 1 :
                    // sqljet/src/Sql.g:212:22: DATABASE
                    {
                    DATABASE158=(Token)match(input,DATABASE,FOLLOW_DATABASE_in_detach_stmt1571); 
                    DATABASE158_tree = (Object)adaptor.create(DATABASE158);
                    adaptor.addChild(root_0, DATABASE158_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_detach_stmt1577);
            database_name=id();

            state._fsp--;

            adaptor.addChild(root_0, database_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "detach_stmt"

    public static class analyze_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "analyze_stmt"
    // sqljet/src/Sql.g:215:1: analyze_stmt : ANALYZE (database_or_table_name= id | database_name= id DOT table_name= id )? ;
    public final SqlParser.analyze_stmt_return analyze_stmt() throws RecognitionException {
        SqlParser.analyze_stmt_return retval = new SqlParser.analyze_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ANALYZE159=null;
        Token DOT160=null;
        SqlParser.id_return database_or_table_name = null;

        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;


        Object ANALYZE159_tree=null;
        Object DOT160_tree=null;

        try {
            // sqljet/src/Sql.g:215:13: ( ANALYZE (database_or_table_name= id | database_name= id DOT table_name= id )? )
            // sqljet/src/Sql.g:215:15: ANALYZE (database_or_table_name= id | database_name= id DOT table_name= id )?
            {
            root_0 = (Object)adaptor.nil();

            ANALYZE159=(Token)match(input,ANALYZE,FOLLOW_ANALYZE_in_analyze_stmt1585); 
            ANALYZE159_tree = (Object)adaptor.create(ANALYZE159);
            adaptor.addChild(root_0, ANALYZE159_tree);

            // sqljet/src/Sql.g:215:23: (database_or_table_name= id | database_name= id DOT table_name= id )?
            int alt49=3;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==ID) ) {
                int LA49_1 = input.LA(2);

                if ( (LA49_1==DOT) ) {
                    alt49=2;
                }
                else if ( (LA49_1==SEMI) ) {
                    alt49=1;
                }
            }
            else if ( ((LA49_0>=EXPLAIN && LA49_0<=PLAN)||(LA49_0>=INDEXED && LA49_0<=BY)||(LA49_0>=OR && LA49_0<=ESCAPE)||(LA49_0>=IS && LA49_0<=BETWEEN)||LA49_0==COLLATE||(LA49_0>=DISTINCT && LA49_0<=THEN)||(LA49_0>=CURRENT_TIME && LA49_0<=CURRENT_TIMESTAMP)||(LA49_0>=RAISE && LA49_0<=ROW)) ) {
                int LA49_2 = input.LA(2);

                if ( (LA49_2==DOT) ) {
                    alt49=2;
                }
                else if ( (LA49_2==SEMI) ) {
                    alt49=1;
                }
            }
            switch (alt49) {
                case 1 :
                    // sqljet/src/Sql.g:215:24: database_or_table_name= id
                    {
                    pushFollow(FOLLOW_id_in_analyze_stmt1590);
                    database_or_table_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_or_table_name.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:215:52: database_name= id DOT table_name= id
                    {
                    pushFollow(FOLLOW_id_in_analyze_stmt1596);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT160=(Token)match(input,DOT,FOLLOW_DOT_in_analyze_stmt1598); 
                    DOT160_tree = (Object)adaptor.create(DOT160);
                    adaptor.addChild(root_0, DOT160_tree);

                    pushFollow(FOLLOW_id_in_analyze_stmt1602);
                    table_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, table_name.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "analyze_stmt"

    public static class reindex_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "reindex_stmt"
    // sqljet/src/Sql.g:218:1: reindex_stmt : REINDEX (database_name= id DOT )? collation_or_table_or_index_name= id ;
    public final SqlParser.reindex_stmt_return reindex_stmt() throws RecognitionException {
        SqlParser.reindex_stmt_return retval = new SqlParser.reindex_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token REINDEX161=null;
        Token DOT162=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return collation_or_table_or_index_name = null;


        Object REINDEX161_tree=null;
        Object DOT162_tree=null;

        try {
            // sqljet/src/Sql.g:218:13: ( REINDEX (database_name= id DOT )? collation_or_table_or_index_name= id )
            // sqljet/src/Sql.g:218:15: REINDEX (database_name= id DOT )? collation_or_table_or_index_name= id
            {
            root_0 = (Object)adaptor.nil();

            REINDEX161=(Token)match(input,REINDEX,FOLLOW_REINDEX_in_reindex_stmt1612); 
            REINDEX161_tree = (Object)adaptor.create(REINDEX161);
            adaptor.addChild(root_0, REINDEX161_tree);

            // sqljet/src/Sql.g:218:23: (database_name= id DOT )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( (LA50_0==ID) ) {
                int LA50_1 = input.LA(2);

                if ( (LA50_1==DOT) ) {
                    alt50=1;
                }
            }
            else if ( ((LA50_0>=EXPLAIN && LA50_0<=PLAN)||(LA50_0>=INDEXED && LA50_0<=BY)||(LA50_0>=OR && LA50_0<=ESCAPE)||(LA50_0>=IS && LA50_0<=BETWEEN)||LA50_0==COLLATE||(LA50_0>=DISTINCT && LA50_0<=THEN)||(LA50_0>=CURRENT_TIME && LA50_0<=CURRENT_TIMESTAMP)||(LA50_0>=RAISE && LA50_0<=ROW)) ) {
                int LA50_2 = input.LA(2);

                if ( (LA50_2==DOT) ) {
                    alt50=1;
                }
            }
            switch (alt50) {
                case 1 :
                    // sqljet/src/Sql.g:218:24: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_reindex_stmt1617);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT162=(Token)match(input,DOT,FOLLOW_DOT_in_reindex_stmt1619); 
                    DOT162_tree = (Object)adaptor.create(DOT162);
                    adaptor.addChild(root_0, DOT162_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_reindex_stmt1625);
            collation_or_table_or_index_name=id();

            state._fsp--;

            adaptor.addChild(root_0, collation_or_table_or_index_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "reindex_stmt"

    public static class vacuum_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "vacuum_stmt"
    // sqljet/src/Sql.g:221:1: vacuum_stmt : VACUUM ;
    public final SqlParser.vacuum_stmt_return vacuum_stmt() throws RecognitionException {
        SqlParser.vacuum_stmt_return retval = new SqlParser.vacuum_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token VACUUM163=null;

        Object VACUUM163_tree=null;

        try {
            // sqljet/src/Sql.g:221:12: ( VACUUM )
            // sqljet/src/Sql.g:221:14: VACUUM
            {
            root_0 = (Object)adaptor.nil();

            VACUUM163=(Token)match(input,VACUUM,FOLLOW_VACUUM_in_vacuum_stmt1633); 
            VACUUM163_tree = (Object)adaptor.create(VACUUM163);
            adaptor.addChild(root_0, VACUUM163_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "vacuum_stmt"

    public static class operation_conflict_clause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "operation_conflict_clause"
    // sqljet/src/Sql.g:227:1: operation_conflict_clause : OR ( ROLLBACK | ABORT | FAIL | IGNORE | REPLACE ) ;
    public final SqlParser.operation_conflict_clause_return operation_conflict_clause() throws RecognitionException {
        SqlParser.operation_conflict_clause_return retval = new SqlParser.operation_conflict_clause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token OR164=null;
        Token set165=null;

        Object OR164_tree=null;
        Object set165_tree=null;

        try {
            // sqljet/src/Sql.g:227:26: ( OR ( ROLLBACK | ABORT | FAIL | IGNORE | REPLACE ) )
            // sqljet/src/Sql.g:227:28: OR ( ROLLBACK | ABORT | FAIL | IGNORE | REPLACE )
            {
            root_0 = (Object)adaptor.nil();

            OR164=(Token)match(input,OR,FOLLOW_OR_in_operation_conflict_clause1644); 
            OR164_tree = (Object)adaptor.create(OR164);
            adaptor.addChild(root_0, OR164_tree);

            set165=(Token)input.LT(1);
            if ( (input.LA(1)>=IGNORE && input.LA(1)<=FAIL)||input.LA(1)==REPLACE ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set165));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "operation_conflict_clause"

    public static class ordering_term_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ordering_term"
    // sqljet/src/Sql.g:229:1: ordering_term : expr ( ASC | DESC )? -> ^( ORDERING expr ( ASC )? ( DESC )? ) ;
    public final SqlParser.ordering_term_return ordering_term() throws RecognitionException {
        SqlParser.ordering_term_return retval = new SqlParser.ordering_term_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ASC167=null;
        Token DESC168=null;
        SqlParser.expr_return expr166 = null;


        Object ASC167_tree=null;
        Object DESC168_tree=null;
        RewriteRuleTokenStream stream_DESC=new RewriteRuleTokenStream(adaptor,"token DESC");
        RewriteRuleTokenStream stream_ASC=new RewriteRuleTokenStream(adaptor,"token ASC");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        try {
            // sqljet/src/Sql.g:229:14: ( expr ( ASC | DESC )? -> ^( ORDERING expr ( ASC )? ( DESC )? ) )
            // sqljet/src/Sql.g:229:16: expr ( ASC | DESC )?
            {
            pushFollow(FOLLOW_expr_in_ordering_term1671);
            expr166=expr();

            state._fsp--;

            stream_expr.add(expr166.getTree());
            // sqljet/src/Sql.g:229:82: ( ASC | DESC )?
            int alt51=3;
            alt51 = dfa51.predict(input);
            switch (alt51) {
                case 1 :
                    // sqljet/src/Sql.g:229:83: ASC
                    {
                    ASC167=(Token)match(input,ASC,FOLLOW_ASC_in_ordering_term1676);  
                    stream_ASC.add(ASC167);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:229:89: DESC
                    {
                    DESC168=(Token)match(input,DESC,FOLLOW_DESC_in_ordering_term1680);  
                    stream_DESC.add(DESC168);


                    }
                    break;

            }



            // AST REWRITE
            // elements: ASC, DESC, expr
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 230:1: -> ^( ORDERING expr ( ASC )? ( DESC )? )
            {
                // sqljet/src/Sql.g:230:4: ^( ORDERING expr ( ASC )? ( DESC )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(ORDERING, "ORDERING"), root_1);

                adaptor.addChild(root_1, stream_expr.nextTree());
                // sqljet/src/Sql.g:230:20: ( ASC )?
                if ( stream_ASC.hasNext() ) {
                    adaptor.addChild(root_1, stream_ASC.nextNode());

                }
                stream_ASC.reset();
                // sqljet/src/Sql.g:230:27: ( DESC )?
                if ( stream_DESC.hasNext() ) {
                    adaptor.addChild(root_1, stream_DESC.nextNode());

                }
                stream_DESC.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ordering_term"

    public static class operation_limited_clause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "operation_limited_clause"
    // sqljet/src/Sql.g:232:1: operation_limited_clause : ( ORDER BY ordering_term ( COMMA ordering_term )* )? LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )? ;
    public final SqlParser.operation_limited_clause_return operation_limited_clause() throws RecognitionException {
        SqlParser.operation_limited_clause_return retval = new SqlParser.operation_limited_clause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token limit=null;
        Token offset=null;
        Token ORDER169=null;
        Token BY170=null;
        Token COMMA172=null;
        Token LIMIT174=null;
        Token set175=null;
        SqlParser.ordering_term_return ordering_term171 = null;

        SqlParser.ordering_term_return ordering_term173 = null;


        Object limit_tree=null;
        Object offset_tree=null;
        Object ORDER169_tree=null;
        Object BY170_tree=null;
        Object COMMA172_tree=null;
        Object LIMIT174_tree=null;
        Object set175_tree=null;

        try {
            // sqljet/src/Sql.g:232:25: ( ( ORDER BY ordering_term ( COMMA ordering_term )* )? LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )? )
            // sqljet/src/Sql.g:233:3: ( ORDER BY ordering_term ( COMMA ordering_term )* )? LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )?
            {
            root_0 = (Object)adaptor.nil();

            // sqljet/src/Sql.g:233:3: ( ORDER BY ordering_term ( COMMA ordering_term )* )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==ORDER) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // sqljet/src/Sql.g:233:4: ORDER BY ordering_term ( COMMA ordering_term )*
                    {
                    ORDER169=(Token)match(input,ORDER,FOLLOW_ORDER_in_operation_limited_clause1710); 
                    ORDER169_tree = (Object)adaptor.create(ORDER169);
                    adaptor.addChild(root_0, ORDER169_tree);

                    BY170=(Token)match(input,BY,FOLLOW_BY_in_operation_limited_clause1712); 
                    BY170_tree = (Object)adaptor.create(BY170);
                    adaptor.addChild(root_0, BY170_tree);

                    pushFollow(FOLLOW_ordering_term_in_operation_limited_clause1714);
                    ordering_term171=ordering_term();

                    state._fsp--;

                    adaptor.addChild(root_0, ordering_term171.getTree());
                    // sqljet/src/Sql.g:233:27: ( COMMA ordering_term )*
                    loop52:
                    do {
                        int alt52=2;
                        int LA52_0 = input.LA(1);

                        if ( (LA52_0==COMMA) ) {
                            alt52=1;
                        }


                        switch (alt52) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:233:28: COMMA ordering_term
                    	    {
                    	    COMMA172=(Token)match(input,COMMA,FOLLOW_COMMA_in_operation_limited_clause1717); 
                    	    COMMA172_tree = (Object)adaptor.create(COMMA172);
                    	    adaptor.addChild(root_0, COMMA172_tree);

                    	    pushFollow(FOLLOW_ordering_term_in_operation_limited_clause1719);
                    	    ordering_term173=ordering_term();

                    	    state._fsp--;

                    	    adaptor.addChild(root_0, ordering_term173.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop52;
                        }
                    } while (true);


                    }
                    break;

            }

            LIMIT174=(Token)match(input,LIMIT,FOLLOW_LIMIT_in_operation_limited_clause1727); 
            LIMIT174_tree = (Object)adaptor.create(LIMIT174);
            adaptor.addChild(root_0, LIMIT174_tree);

            limit=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_operation_limited_clause1731); 
            limit_tree = (Object)adaptor.create(limit);
            adaptor.addChild(root_0, limit_tree);

            // sqljet/src/Sql.g:234:23: ( ( OFFSET | COMMA ) offset= INTEGER )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==COMMA||LA54_0==OFFSET) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // sqljet/src/Sql.g:234:24: ( OFFSET | COMMA ) offset= INTEGER
                    {
                    set175=(Token)input.LT(1);
                    if ( input.LA(1)==COMMA||input.LA(1)==OFFSET ) {
                        input.consume();
                        adaptor.addChild(root_0, (Object)adaptor.create(set175));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }

                    offset=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_operation_limited_clause1744); 
                    offset_tree = (Object)adaptor.create(offset);
                    adaptor.addChild(root_0, offset_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "operation_limited_clause"

    public static class select_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "select_stmt"
    // sqljet/src/Sql.g:237:1: select_stmt : select_list ( ORDER BY ordering_term ( COMMA ordering_term )* )? ( LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )? )? -> ^( SELECT select_list ( ^( ORDER ( ordering_term )+ ) )? ( ^( LIMIT $limit ( $offset)? ) )? ) ;
    public final SqlParser.select_stmt_return select_stmt() throws RecognitionException {
        SqlParser.select_stmt_return retval = new SqlParser.select_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token limit=null;
        Token offset=null;
        Token ORDER177=null;
        Token BY178=null;
        Token COMMA180=null;
        Token LIMIT182=null;
        Token OFFSET183=null;
        Token COMMA184=null;
        SqlParser.select_list_return select_list176 = null;

        SqlParser.ordering_term_return ordering_term179 = null;

        SqlParser.ordering_term_return ordering_term181 = null;


        Object limit_tree=null;
        Object offset_tree=null;
        Object ORDER177_tree=null;
        Object BY178_tree=null;
        Object COMMA180_tree=null;
        Object LIMIT182_tree=null;
        Object OFFSET183_tree=null;
        Object COMMA184_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_ORDER=new RewriteRuleTokenStream(adaptor,"token ORDER");
        RewriteRuleTokenStream stream_INTEGER=new RewriteRuleTokenStream(adaptor,"token INTEGER");
        RewriteRuleTokenStream stream_BY=new RewriteRuleTokenStream(adaptor,"token BY");
        RewriteRuleTokenStream stream_LIMIT=new RewriteRuleTokenStream(adaptor,"token LIMIT");
        RewriteRuleTokenStream stream_OFFSET=new RewriteRuleTokenStream(adaptor,"token OFFSET");
        RewriteRuleSubtreeStream stream_ordering_term=new RewriteRuleSubtreeStream(adaptor,"rule ordering_term");
        RewriteRuleSubtreeStream stream_select_list=new RewriteRuleSubtreeStream(adaptor,"rule select_list");
        try {
            // sqljet/src/Sql.g:237:12: ( select_list ( ORDER BY ordering_term ( COMMA ordering_term )* )? ( LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )? )? -> ^( SELECT select_list ( ^( ORDER ( ordering_term )+ ) )? ( ^( LIMIT $limit ( $offset)? ) )? ) )
            // sqljet/src/Sql.g:237:14: select_list ( ORDER BY ordering_term ( COMMA ordering_term )* )? ( LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )? )?
            {
            pushFollow(FOLLOW_select_list_in_select_stmt1754);
            select_list176=select_list();

            state._fsp--;

            stream_select_list.add(select_list176.getTree());
            // sqljet/src/Sql.g:238:3: ( ORDER BY ordering_term ( COMMA ordering_term )* )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==ORDER) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // sqljet/src/Sql.g:238:4: ORDER BY ordering_term ( COMMA ordering_term )*
                    {
                    ORDER177=(Token)match(input,ORDER,FOLLOW_ORDER_in_select_stmt1759);  
                    stream_ORDER.add(ORDER177);

                    BY178=(Token)match(input,BY,FOLLOW_BY_in_select_stmt1761);  
                    stream_BY.add(BY178);

                    pushFollow(FOLLOW_ordering_term_in_select_stmt1763);
                    ordering_term179=ordering_term();

                    state._fsp--;

                    stream_ordering_term.add(ordering_term179.getTree());
                    // sqljet/src/Sql.g:238:27: ( COMMA ordering_term )*
                    loop55:
                    do {
                        int alt55=2;
                        int LA55_0 = input.LA(1);

                        if ( (LA55_0==COMMA) ) {
                            alt55=1;
                        }


                        switch (alt55) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:238:28: COMMA ordering_term
                    	    {
                    	    COMMA180=(Token)match(input,COMMA,FOLLOW_COMMA_in_select_stmt1766);  
                    	    stream_COMMA.add(COMMA180);

                    	    pushFollow(FOLLOW_ordering_term_in_select_stmt1768);
                    	    ordering_term181=ordering_term();

                    	    state._fsp--;

                    	    stream_ordering_term.add(ordering_term181.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop55;
                        }
                    } while (true);


                    }
                    break;

            }

            // sqljet/src/Sql.g:239:3: ( LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )? )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==LIMIT) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // sqljet/src/Sql.g:239:4: LIMIT limit= INTEGER ( ( OFFSET | COMMA ) offset= INTEGER )?
                    {
                    LIMIT182=(Token)match(input,LIMIT,FOLLOW_LIMIT_in_select_stmt1777);  
                    stream_LIMIT.add(LIMIT182);

                    limit=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_select_stmt1781);  
                    stream_INTEGER.add(limit);

                    // sqljet/src/Sql.g:239:24: ( ( OFFSET | COMMA ) offset= INTEGER )?
                    int alt58=2;
                    int LA58_0 = input.LA(1);

                    if ( (LA58_0==COMMA||LA58_0==OFFSET) ) {
                        alt58=1;
                    }
                    switch (alt58) {
                        case 1 :
                            // sqljet/src/Sql.g:239:25: ( OFFSET | COMMA ) offset= INTEGER
                            {
                            // sqljet/src/Sql.g:239:25: ( OFFSET | COMMA )
                            int alt57=2;
                            int LA57_0 = input.LA(1);

                            if ( (LA57_0==OFFSET) ) {
                                alt57=1;
                            }
                            else if ( (LA57_0==COMMA) ) {
                                alt57=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 57, 0, input);

                                throw nvae;
                            }
                            switch (alt57) {
                                case 1 :
                                    // sqljet/src/Sql.g:239:26: OFFSET
                                    {
                                    OFFSET183=(Token)match(input,OFFSET,FOLLOW_OFFSET_in_select_stmt1785);  
                                    stream_OFFSET.add(OFFSET183);


                                    }
                                    break;
                                case 2 :
                                    // sqljet/src/Sql.g:239:35: COMMA
                                    {
                                    COMMA184=(Token)match(input,COMMA,FOLLOW_COMMA_in_select_stmt1789);  
                                    stream_COMMA.add(COMMA184);


                                    }
                                    break;

                            }

                            offset=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_select_stmt1794);  
                            stream_INTEGER.add(offset);


                            }
                            break;

                    }


                    }
                    break;

            }



            // AST REWRITE
            // elements: LIMIT, ORDER, ordering_term, offset, limit, select_list
            // token labels: limit, offset
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleTokenStream stream_limit=new RewriteRuleTokenStream(adaptor,"token limit",limit);
            RewriteRuleTokenStream stream_offset=new RewriteRuleTokenStream(adaptor,"token offset",offset);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 240:1: -> ^( SELECT select_list ( ^( ORDER ( ordering_term )+ ) )? ( ^( LIMIT $limit ( $offset)? ) )? )
            {
                // sqljet/src/Sql.g:240:4: ^( SELECT select_list ( ^( ORDER ( ordering_term )+ ) )? ( ^( LIMIT $limit ( $offset)? ) )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(SELECT, "SELECT"), root_1);

                adaptor.addChild(root_1, stream_select_list.nextTree());
                // sqljet/src/Sql.g:241:22: ( ^( ORDER ( ordering_term )+ ) )?
                if ( stream_ORDER.hasNext()||stream_ordering_term.hasNext() ) {
                    // sqljet/src/Sql.g:241:22: ^( ORDER ( ordering_term )+ )
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot(stream_ORDER.nextNode(), root_2);

                    if ( !(stream_ordering_term.hasNext()) ) {
                        throw new RewriteEarlyExitException();
                    }
                    while ( stream_ordering_term.hasNext() ) {
                        adaptor.addChild(root_2, stream_ordering_term.nextTree());

                    }
                    stream_ordering_term.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_ORDER.reset();
                stream_ordering_term.reset();
                // sqljet/src/Sql.g:241:47: ( ^( LIMIT $limit ( $offset)? ) )?
                if ( stream_LIMIT.hasNext()||stream_offset.hasNext()||stream_limit.hasNext() ) {
                    // sqljet/src/Sql.g:241:47: ^( LIMIT $limit ( $offset)? )
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot(stream_LIMIT.nextNode(), root_2);

                    adaptor.addChild(root_2, stream_limit.nextNode());
                    // sqljet/src/Sql.g:241:62: ( $offset)?
                    if ( stream_offset.hasNext() ) {
                        adaptor.addChild(root_2, stream_offset.nextNode());

                    }
                    stream_offset.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_LIMIT.reset();
                stream_offset.reset();
                stream_limit.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "select_stmt"

    public static class select_list_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "select_list"
    // sqljet/src/Sql.g:244:1: select_list : select_core ( select_op select_core )* ;
    public final SqlParser.select_list_return select_list() throws RecognitionException {
        SqlParser.select_list_return retval = new SqlParser.select_list_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        SqlParser.select_core_return select_core185 = null;

        SqlParser.select_op_return select_op186 = null;

        SqlParser.select_core_return select_core187 = null;



        try {
            // sqljet/src/Sql.g:244:12: ( select_core ( select_op select_core )* )
            // sqljet/src/Sql.g:245:3: select_core ( select_op select_core )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_select_core_in_select_list1839);
            select_core185=select_core();

            state._fsp--;

            adaptor.addChild(root_0, select_core185.getTree());
            // sqljet/src/Sql.g:245:15: ( select_op select_core )*
            loop60:
            do {
                int alt60=2;
                int LA60_0 = input.LA(1);

                if ( (LA60_0==UNION||(LA60_0>=INTERSECT && LA60_0<=EXCEPT)) ) {
                    alt60=1;
                }


                switch (alt60) {
            	case 1 :
            	    // sqljet/src/Sql.g:245:16: select_op select_core
            	    {
            	    pushFollow(FOLLOW_select_op_in_select_list1842);
            	    select_op186=select_op();

            	    state._fsp--;

            	    root_0 = (Object)adaptor.becomeRoot(select_op186.getTree(), root_0);
            	    pushFollow(FOLLOW_select_core_in_select_list1845);
            	    select_core187=select_core();

            	    state._fsp--;

            	    adaptor.addChild(root_0, select_core187.getTree());

            	    }
            	    break;

            	default :
            	    break loop60;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "select_list"

    public static class select_op_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "select_op"
    // sqljet/src/Sql.g:247:1: select_op : ( UNION ( ALL )? | INTERSECT | EXCEPT );
    public final SqlParser.select_op_return select_op() throws RecognitionException {
        SqlParser.select_op_return retval = new SqlParser.select_op_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token UNION188=null;
        Token ALL189=null;
        Token INTERSECT190=null;
        Token EXCEPT191=null;

        Object UNION188_tree=null;
        Object ALL189_tree=null;
        Object INTERSECT190_tree=null;
        Object EXCEPT191_tree=null;

        try {
            // sqljet/src/Sql.g:247:10: ( UNION ( ALL )? | INTERSECT | EXCEPT )
            int alt62=3;
            switch ( input.LA(1) ) {
            case UNION:
                {
                alt62=1;
                }
                break;
            case INTERSECT:
                {
                alt62=2;
                }
                break;
            case EXCEPT:
                {
                alt62=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 62, 0, input);

                throw nvae;
            }

            switch (alt62) {
                case 1 :
                    // sqljet/src/Sql.g:247:12: UNION ( ALL )?
                    {
                    root_0 = (Object)adaptor.nil();

                    UNION188=(Token)match(input,UNION,FOLLOW_UNION_in_select_op1854); 
                    UNION188_tree = (Object)adaptor.create(UNION188);
                    root_0 = (Object)adaptor.becomeRoot(UNION188_tree, root_0);

                    // sqljet/src/Sql.g:247:19: ( ALL )?
                    int alt61=2;
                    int LA61_0 = input.LA(1);

                    if ( (LA61_0==ALL) ) {
                        alt61=1;
                    }
                    switch (alt61) {
                        case 1 :
                            // sqljet/src/Sql.g:247:20: ALL
                            {
                            ALL189=(Token)match(input,ALL,FOLLOW_ALL_in_select_op1858); 
                            ALL189_tree = (Object)adaptor.create(ALL189);
                            adaptor.addChild(root_0, ALL189_tree);


                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:247:28: INTERSECT
                    {
                    root_0 = (Object)adaptor.nil();

                    INTERSECT190=(Token)match(input,INTERSECT,FOLLOW_INTERSECT_in_select_op1864); 
                    INTERSECT190_tree = (Object)adaptor.create(INTERSECT190);
                    adaptor.addChild(root_0, INTERSECT190_tree);


                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:247:40: EXCEPT
                    {
                    root_0 = (Object)adaptor.nil();

                    EXCEPT191=(Token)match(input,EXCEPT,FOLLOW_EXCEPT_in_select_op1868); 
                    EXCEPT191_tree = (Object)adaptor.create(EXCEPT191);
                    adaptor.addChild(root_0, EXCEPT191_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "select_op"

    public static class select_core_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "select_core"
    // sqljet/src/Sql.g:249:1: select_core : SELECT ( ALL | DISTINCT )? result_column ( COMMA result_column )* ( FROM join_source )? ( WHERE where_expr= expr )? ( GROUP BY ordering_term ( COMMA ordering_term )* ( HAVING having_expr= expr )? )? -> ^( SELECT_CORE ( DISTINCT )? ^( COLUMNS ( result_column )+ ) ( ^( FROM join_source ) )? ( ^( WHERE $where_expr) )? ( ^( GROUP ( ordering_term )+ ( ^( HAVING $having_expr) )? ) )? ) ;
    public final SqlParser.select_core_return select_core() throws RecognitionException {
        SqlParser.select_core_return retval = new SqlParser.select_core_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token SELECT192=null;
        Token ALL193=null;
        Token DISTINCT194=null;
        Token COMMA196=null;
        Token FROM198=null;
        Token WHERE200=null;
        Token GROUP201=null;
        Token BY202=null;
        Token COMMA204=null;
        Token HAVING206=null;
        SqlParser.expr_return where_expr = null;

        SqlParser.expr_return having_expr = null;

        SqlParser.result_column_return result_column195 = null;

        SqlParser.result_column_return result_column197 = null;

        SqlParser.join_source_return join_source199 = null;

        SqlParser.ordering_term_return ordering_term203 = null;

        SqlParser.ordering_term_return ordering_term205 = null;


        Object SELECT192_tree=null;
        Object ALL193_tree=null;
        Object DISTINCT194_tree=null;
        Object COMMA196_tree=null;
        Object FROM198_tree=null;
        Object WHERE200_tree=null;
        Object GROUP201_tree=null;
        Object BY202_tree=null;
        Object COMMA204_tree=null;
        Object HAVING206_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_DISTINCT=new RewriteRuleTokenStream(adaptor,"token DISTINCT");
        RewriteRuleTokenStream stream_BY=new RewriteRuleTokenStream(adaptor,"token BY");
        RewriteRuleTokenStream stream_HAVING=new RewriteRuleTokenStream(adaptor,"token HAVING");
        RewriteRuleTokenStream stream_ALL=new RewriteRuleTokenStream(adaptor,"token ALL");
        RewriteRuleTokenStream stream_SELECT=new RewriteRuleTokenStream(adaptor,"token SELECT");
        RewriteRuleTokenStream stream_GROUP=new RewriteRuleTokenStream(adaptor,"token GROUP");
        RewriteRuleTokenStream stream_FROM=new RewriteRuleTokenStream(adaptor,"token FROM");
        RewriteRuleTokenStream stream_WHERE=new RewriteRuleTokenStream(adaptor,"token WHERE");
        RewriteRuleSubtreeStream stream_result_column=new RewriteRuleSubtreeStream(adaptor,"rule result_column");
        RewriteRuleSubtreeStream stream_join_source=new RewriteRuleSubtreeStream(adaptor,"rule join_source");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        RewriteRuleSubtreeStream stream_ordering_term=new RewriteRuleSubtreeStream(adaptor,"rule ordering_term");
        try {
            // sqljet/src/Sql.g:249:12: ( SELECT ( ALL | DISTINCT )? result_column ( COMMA result_column )* ( FROM join_source )? ( WHERE where_expr= expr )? ( GROUP BY ordering_term ( COMMA ordering_term )* ( HAVING having_expr= expr )? )? -> ^( SELECT_CORE ( DISTINCT )? ^( COLUMNS ( result_column )+ ) ( ^( FROM join_source ) )? ( ^( WHERE $where_expr) )? ( ^( GROUP ( ordering_term )+ ( ^( HAVING $having_expr) )? ) )? ) )
            // sqljet/src/Sql.g:250:3: SELECT ( ALL | DISTINCT )? result_column ( COMMA result_column )* ( FROM join_source )? ( WHERE where_expr= expr )? ( GROUP BY ordering_term ( COMMA ordering_term )* ( HAVING having_expr= expr )? )?
            {
            SELECT192=(Token)match(input,SELECT,FOLLOW_SELECT_in_select_core1877);  
            stream_SELECT.add(SELECT192);

            // sqljet/src/Sql.g:250:10: ( ALL | DISTINCT )?
            int alt63=3;
            alt63 = dfa63.predict(input);
            switch (alt63) {
                case 1 :
                    // sqljet/src/Sql.g:250:11: ALL
                    {
                    ALL193=(Token)match(input,ALL,FOLLOW_ALL_in_select_core1880);  
                    stream_ALL.add(ALL193);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:250:17: DISTINCT
                    {
                    DISTINCT194=(Token)match(input,DISTINCT,FOLLOW_DISTINCT_in_select_core1884);  
                    stream_DISTINCT.add(DISTINCT194);


                    }
                    break;

            }

            pushFollow(FOLLOW_result_column_in_select_core1888);
            result_column195=result_column();

            state._fsp--;

            stream_result_column.add(result_column195.getTree());
            // sqljet/src/Sql.g:250:42: ( COMMA result_column )*
            loop64:
            do {
                int alt64=2;
                alt64 = dfa64.predict(input);
                switch (alt64) {
            	case 1 :
            	    // sqljet/src/Sql.g:250:43: COMMA result_column
            	    {
            	    COMMA196=(Token)match(input,COMMA,FOLLOW_COMMA_in_select_core1891);  
            	    stream_COMMA.add(COMMA196);

            	    pushFollow(FOLLOW_result_column_in_select_core1893);
            	    result_column197=result_column();

            	    state._fsp--;

            	    stream_result_column.add(result_column197.getTree());

            	    }
            	    break;

            	default :
            	    break loop64;
                }
            } while (true);

            // sqljet/src/Sql.g:250:65: ( FROM join_source )?
            int alt65=2;
            alt65 = dfa65.predict(input);
            switch (alt65) {
                case 1 :
                    // sqljet/src/Sql.g:250:66: FROM join_source
                    {
                    FROM198=(Token)match(input,FROM,FOLLOW_FROM_in_select_core1898);  
                    stream_FROM.add(FROM198);

                    pushFollow(FOLLOW_join_source_in_select_core1900);
                    join_source199=join_source();

                    state._fsp--;

                    stream_join_source.add(join_source199.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:250:85: ( WHERE where_expr= expr )?
            int alt66=2;
            alt66 = dfa66.predict(input);
            switch (alt66) {
                case 1 :
                    // sqljet/src/Sql.g:250:86: WHERE where_expr= expr
                    {
                    WHERE200=(Token)match(input,WHERE,FOLLOW_WHERE_in_select_core1905);  
                    stream_WHERE.add(WHERE200);

                    pushFollow(FOLLOW_expr_in_select_core1909);
                    where_expr=expr();

                    state._fsp--;

                    stream_expr.add(where_expr.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:251:3: ( GROUP BY ordering_term ( COMMA ordering_term )* ( HAVING having_expr= expr )? )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==GROUP) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // sqljet/src/Sql.g:251:5: GROUP BY ordering_term ( COMMA ordering_term )* ( HAVING having_expr= expr )?
                    {
                    GROUP201=(Token)match(input,GROUP,FOLLOW_GROUP_in_select_core1917);  
                    stream_GROUP.add(GROUP201);

                    BY202=(Token)match(input,BY,FOLLOW_BY_in_select_core1919);  
                    stream_BY.add(BY202);

                    pushFollow(FOLLOW_ordering_term_in_select_core1921);
                    ordering_term203=ordering_term();

                    state._fsp--;

                    stream_ordering_term.add(ordering_term203.getTree());
                    // sqljet/src/Sql.g:251:28: ( COMMA ordering_term )*
                    loop67:
                    do {
                        int alt67=2;
                        alt67 = dfa67.predict(input);
                        switch (alt67) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:251:29: COMMA ordering_term
                    	    {
                    	    COMMA204=(Token)match(input,COMMA,FOLLOW_COMMA_in_select_core1924);  
                    	    stream_COMMA.add(COMMA204);

                    	    pushFollow(FOLLOW_ordering_term_in_select_core1926);
                    	    ordering_term205=ordering_term();

                    	    state._fsp--;

                    	    stream_ordering_term.add(ordering_term205.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop67;
                        }
                    } while (true);

                    // sqljet/src/Sql.g:251:51: ( HAVING having_expr= expr )?
                    int alt68=2;
                    int LA68_0 = input.LA(1);

                    if ( (LA68_0==HAVING) ) {
                        alt68=1;
                    }
                    switch (alt68) {
                        case 1 :
                            // sqljet/src/Sql.g:251:52: HAVING having_expr= expr
                            {
                            HAVING206=(Token)match(input,HAVING,FOLLOW_HAVING_in_select_core1931);  
                            stream_HAVING.add(HAVING206);

                            pushFollow(FOLLOW_expr_in_select_core1935);
                            having_expr=expr();

                            state._fsp--;

                            stream_expr.add(having_expr.getTree());

                            }
                            break;

                    }


                    }
                    break;

            }



            // AST REWRITE
            // elements: DISTINCT, ordering_term, WHERE, GROUP, where_expr, result_column, having_expr, HAVING, FROM, join_source
            // token labels: 
            // rule labels: where_expr, retval, having_expr
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_where_expr=new RewriteRuleSubtreeStream(adaptor,"rule where_expr",where_expr!=null?where_expr.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_having_expr=new RewriteRuleSubtreeStream(adaptor,"rule having_expr",having_expr!=null?having_expr.tree:null);

            root_0 = (Object)adaptor.nil();
            // 252:1: -> ^( SELECT_CORE ( DISTINCT )? ^( COLUMNS ( result_column )+ ) ( ^( FROM join_source ) )? ( ^( WHERE $where_expr) )? ( ^( GROUP ( ordering_term )+ ( ^( HAVING $having_expr) )? ) )? )
            {
                // sqljet/src/Sql.g:252:4: ^( SELECT_CORE ( DISTINCT )? ^( COLUMNS ( result_column )+ ) ( ^( FROM join_source ) )? ( ^( WHERE $where_expr) )? ( ^( GROUP ( ordering_term )+ ( ^( HAVING $having_expr) )? ) )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(SELECT_CORE, "SELECT_CORE"), root_1);

                // sqljet/src/Sql.g:253:15: ( DISTINCT )?
                if ( stream_DISTINCT.hasNext() ) {
                    adaptor.addChild(root_1, stream_DISTINCT.nextNode());

                }
                stream_DISTINCT.reset();
                // sqljet/src/Sql.g:253:27: ^( COLUMNS ( result_column )+ )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMNS, "COLUMNS"), root_2);

                if ( !(stream_result_column.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_result_column.hasNext() ) {
                    adaptor.addChild(root_2, stream_result_column.nextTree());

                }
                stream_result_column.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:253:53: ( ^( FROM join_source ) )?
                if ( stream_FROM.hasNext()||stream_join_source.hasNext() ) {
                    // sqljet/src/Sql.g:253:53: ^( FROM join_source )
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot(stream_FROM.nextNode(), root_2);

                    adaptor.addChild(root_2, stream_join_source.nextTree());

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_FROM.reset();
                stream_join_source.reset();
                // sqljet/src/Sql.g:253:74: ( ^( WHERE $where_expr) )?
                if ( stream_WHERE.hasNext()||stream_where_expr.hasNext() ) {
                    // sqljet/src/Sql.g:253:74: ^( WHERE $where_expr)
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot(stream_WHERE.nextNode(), root_2);

                    adaptor.addChild(root_2, stream_where_expr.nextTree());

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_WHERE.reset();
                stream_where_expr.reset();
                // sqljet/src/Sql.g:254:3: ( ^( GROUP ( ordering_term )+ ( ^( HAVING $having_expr) )? ) )?
                if ( stream_ordering_term.hasNext()||stream_GROUP.hasNext()||stream_HAVING.hasNext()||stream_having_expr.hasNext() ) {
                    // sqljet/src/Sql.g:254:3: ^( GROUP ( ordering_term )+ ( ^( HAVING $having_expr) )? )
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot(stream_GROUP.nextNode(), root_2);

                    if ( !(stream_ordering_term.hasNext()) ) {
                        throw new RewriteEarlyExitException();
                    }
                    while ( stream_ordering_term.hasNext() ) {
                        adaptor.addChild(root_2, stream_ordering_term.nextTree());

                    }
                    stream_ordering_term.reset();
                    // sqljet/src/Sql.g:254:26: ( ^( HAVING $having_expr) )?
                    if ( stream_having_expr.hasNext()||stream_HAVING.hasNext() ) {
                        // sqljet/src/Sql.g:254:26: ^( HAVING $having_expr)
                        {
                        Object root_3 = (Object)adaptor.nil();
                        root_3 = (Object)adaptor.becomeRoot(stream_HAVING.nextNode(), root_3);

                        adaptor.addChild(root_3, stream_having_expr.nextTree());

                        adaptor.addChild(root_2, root_3);
                        }

                    }
                    stream_having_expr.reset();
                    stream_HAVING.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_ordering_term.reset();
                stream_GROUP.reset();
                stream_HAVING.reset();
                stream_having_expr.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "select_core"

    public static class result_column_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "result_column"
    // sqljet/src/Sql.g:257:1: result_column : ( ASTERISK | table_name= id DOT ASTERISK -> ^( ASTERISK $table_name) | expr ( ( AS )? column_alias= id )? -> ^( ALIAS expr ( $column_alias)? ) );
    public final SqlParser.result_column_return result_column() throws RecognitionException {
        SqlParser.result_column_return retval = new SqlParser.result_column_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ASTERISK207=null;
        Token DOT208=null;
        Token ASTERISK209=null;
        Token AS211=null;
        SqlParser.id_return table_name = null;

        SqlParser.id_return column_alias = null;

        SqlParser.expr_return expr210 = null;


        Object ASTERISK207_tree=null;
        Object DOT208_tree=null;
        Object ASTERISK209_tree=null;
        Object AS211_tree=null;
        RewriteRuleTokenStream stream_ASTERISK=new RewriteRuleTokenStream(adaptor,"token ASTERISK");
        RewriteRuleTokenStream stream_AS=new RewriteRuleTokenStream(adaptor,"token AS");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:258:3: ( ASTERISK | table_name= id DOT ASTERISK -> ^( ASTERISK $table_name) | expr ( ( AS )? column_alias= id )? -> ^( ALIAS expr ( $column_alias)? ) )
            int alt72=3;
            alt72 = dfa72.predict(input);
            switch (alt72) {
                case 1 :
                    // sqljet/src/Sql.g:258:5: ASTERISK
                    {
                    root_0 = (Object)adaptor.nil();

                    ASTERISK207=(Token)match(input,ASTERISK,FOLLOW_ASTERISK_in_result_column2005); 
                    ASTERISK207_tree = (Object)adaptor.create(ASTERISK207);
                    adaptor.addChild(root_0, ASTERISK207_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:259:5: table_name= id DOT ASTERISK
                    {
                    pushFollow(FOLLOW_id_in_result_column2013);
                    table_name=id();

                    state._fsp--;

                    stream_id.add(table_name.getTree());
                    DOT208=(Token)match(input,DOT,FOLLOW_DOT_in_result_column2015);  
                    stream_DOT.add(DOT208);

                    ASTERISK209=(Token)match(input,ASTERISK,FOLLOW_ASTERISK_in_result_column2017);  
                    stream_ASTERISK.add(ASTERISK209);



                    // AST REWRITE
                    // elements: table_name, ASTERISK
                    // token labels: 
                    // rule labels: retval, table_name
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_table_name=new RewriteRuleSubtreeStream(adaptor,"rule table_name",table_name!=null?table_name.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 259:32: -> ^( ASTERISK $table_name)
                    {
                        // sqljet/src/Sql.g:259:35: ^( ASTERISK $table_name)
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_ASTERISK.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_table_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:260:5: expr ( ( AS )? column_alias= id )?
                    {
                    pushFollow(FOLLOW_expr_in_result_column2032);
                    expr210=expr();

                    state._fsp--;

                    stream_expr.add(expr210.getTree());
                    // sqljet/src/Sql.g:260:10: ( ( AS )? column_alias= id )?
                    int alt71=2;
                    alt71 = dfa71.predict(input);
                    switch (alt71) {
                        case 1 :
                            // sqljet/src/Sql.g:260:11: ( AS )? column_alias= id
                            {
                            // sqljet/src/Sql.g:260:11: ( AS )?
                            int alt70=2;
                            alt70 = dfa70.predict(input);
                            switch (alt70) {
                                case 1 :
                                    // sqljet/src/Sql.g:260:12: AS
                                    {
                                    AS211=(Token)match(input,AS,FOLLOW_AS_in_result_column2036);  
                                    stream_AS.add(AS211);


                                    }
                                    break;

                            }

                            pushFollow(FOLLOW_id_in_result_column2042);
                            column_alias=id();

                            state._fsp--;

                            stream_id.add(column_alias.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: column_alias, expr
                    // token labels: 
                    // rule labels: retval, column_alias
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_column_alias=new RewriteRuleSubtreeStream(adaptor,"rule column_alias",column_alias!=null?column_alias.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 260:35: -> ^( ALIAS expr ( $column_alias)? )
                    {
                        // sqljet/src/Sql.g:260:38: ^( ALIAS expr ( $column_alias)? )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(ALIAS, "ALIAS"), root_1);

                        adaptor.addChild(root_1, stream_expr.nextTree());
                        // sqljet/src/Sql.g:260:51: ( $column_alias)?
                        if ( stream_column_alias.hasNext() ) {
                            adaptor.addChild(root_1, stream_column_alias.nextTree());

                        }
                        stream_column_alias.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "result_column"

    public static class join_source_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "join_source"
    // sqljet/src/Sql.g:262:1: join_source : single_source ( join_op single_source ( join_constraint )? )* ;
    public final SqlParser.join_source_return join_source() throws RecognitionException {
        SqlParser.join_source_return retval = new SqlParser.join_source_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        SqlParser.single_source_return single_source212 = null;

        SqlParser.join_op_return join_op213 = null;

        SqlParser.single_source_return single_source214 = null;

        SqlParser.join_constraint_return join_constraint215 = null;



        try {
            // sqljet/src/Sql.g:262:12: ( single_source ( join_op single_source ( join_constraint )? )* )
            // sqljet/src/Sql.g:262:14: single_source ( join_op single_source ( join_constraint )? )*
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_single_source_in_join_source2063);
            single_source212=single_source();

            state._fsp--;

            adaptor.addChild(root_0, single_source212.getTree());
            // sqljet/src/Sql.g:262:28: ( join_op single_source ( join_constraint )? )*
            loop74:
            do {
                int alt74=2;
                alt74 = dfa74.predict(input);
                switch (alt74) {
            	case 1 :
            	    // sqljet/src/Sql.g:262:29: join_op single_source ( join_constraint )?
            	    {
            	    pushFollow(FOLLOW_join_op_in_join_source2066);
            	    join_op213=join_op();

            	    state._fsp--;

            	    root_0 = (Object)adaptor.becomeRoot(join_op213.getTree(), root_0);
            	    pushFollow(FOLLOW_single_source_in_join_source2069);
            	    single_source214=single_source();

            	    state._fsp--;

            	    adaptor.addChild(root_0, single_source214.getTree());
            	    // sqljet/src/Sql.g:262:52: ( join_constraint )?
            	    int alt73=2;
            	    alt73 = dfa73.predict(input);
            	    switch (alt73) {
            	        case 1 :
            	            // sqljet/src/Sql.g:262:53: join_constraint
            	            {
            	            pushFollow(FOLLOW_join_constraint_in_join_source2072);
            	            join_constraint215=join_constraint();

            	            state._fsp--;

            	            adaptor.addChild(root_0, join_constraint215.getTree());

            	            }
            	            break;

            	    }


            	    }
            	    break;

            	default :
            	    break loop74;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "join_source"

    public static class single_source_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "single_source"
    // sqljet/src/Sql.g:264:1: single_source : ( (database_name= id DOT )? table_name= ID ( ( AS )? table_alias= ID )? ( INDEXED BY index_name= id | NOT INDEXED )? -> ^( ALIAS ^( $table_name ( $database_name)? ) ( $table_alias)? ( ^( INDEXED ( NOT )? ( $index_name)? ) )? ) | LPAREN select_stmt RPAREN ( ( AS )? table_alias= ID )? -> ^( ALIAS select_stmt ( $table_alias)? ) | LPAREN join_source RPAREN );
    public final SqlParser.single_source_return single_source() throws RecognitionException {
        SqlParser.single_source_return retval = new SqlParser.single_source_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token table_name=null;
        Token table_alias=null;
        Token DOT216=null;
        Token AS217=null;
        Token INDEXED218=null;
        Token BY219=null;
        Token NOT220=null;
        Token INDEXED221=null;
        Token LPAREN222=null;
        Token RPAREN224=null;
        Token AS225=null;
        Token LPAREN226=null;
        Token RPAREN228=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return index_name = null;

        SqlParser.select_stmt_return select_stmt223 = null;

        SqlParser.join_source_return join_source227 = null;


        Object table_name_tree=null;
        Object table_alias_tree=null;
        Object DOT216_tree=null;
        Object AS217_tree=null;
        Object INDEXED218_tree=null;
        Object BY219_tree=null;
        Object NOT220_tree=null;
        Object INDEXED221_tree=null;
        Object LPAREN222_tree=null;
        Object RPAREN224_tree=null;
        Object AS225_tree=null;
        Object LPAREN226_tree=null;
        Object RPAREN228_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_INDEXED=new RewriteRuleTokenStream(adaptor,"token INDEXED");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_AS=new RewriteRuleTokenStream(adaptor,"token AS");
        RewriteRuleTokenStream stream_BY=new RewriteRuleTokenStream(adaptor,"token BY");
        RewriteRuleTokenStream stream_NOT=new RewriteRuleTokenStream(adaptor,"token NOT");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleSubtreeStream stream_select_stmt=new RewriteRuleSubtreeStream(adaptor,"rule select_stmt");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:265:3: ( (database_name= id DOT )? table_name= ID ( ( AS )? table_alias= ID )? ( INDEXED BY index_name= id | NOT INDEXED )? -> ^( ALIAS ^( $table_name ( $database_name)? ) ( $table_alias)? ( ^( INDEXED ( NOT )? ( $index_name)? ) )? ) | LPAREN select_stmt RPAREN ( ( AS )? table_alias= ID )? -> ^( ALIAS select_stmt ( $table_alias)? ) | LPAREN join_source RPAREN )
            int alt81=3;
            alt81 = dfa81.predict(input);
            switch (alt81) {
                case 1 :
                    // sqljet/src/Sql.g:265:5: (database_name= id DOT )? table_name= ID ( ( AS )? table_alias= ID )? ( INDEXED BY index_name= id | NOT INDEXED )?
                    {
                    // sqljet/src/Sql.g:265:5: (database_name= id DOT )?
                    int alt75=2;
                    alt75 = dfa75.predict(input);
                    switch (alt75) {
                        case 1 :
                            // sqljet/src/Sql.g:265:6: database_name= id DOT
                            {
                            pushFollow(FOLLOW_id_in_single_source2089);
                            database_name=id();

                            state._fsp--;

                            stream_id.add(database_name.getTree());
                            DOT216=(Token)match(input,DOT,FOLLOW_DOT_in_single_source2091);  
                            stream_DOT.add(DOT216);


                            }
                            break;

                    }

                    table_name=(Token)match(input,ID,FOLLOW_ID_in_single_source2097);  
                    stream_ID.add(table_name);

                    // sqljet/src/Sql.g:265:43: ( ( AS )? table_alias= ID )?
                    int alt77=2;
                    alt77 = dfa77.predict(input);
                    switch (alt77) {
                        case 1 :
                            // sqljet/src/Sql.g:265:44: ( AS )? table_alias= ID
                            {
                            // sqljet/src/Sql.g:265:44: ( AS )?
                            int alt76=2;
                            int LA76_0 = input.LA(1);

                            if ( (LA76_0==AS) ) {
                                alt76=1;
                            }
                            switch (alt76) {
                                case 1 :
                                    // sqljet/src/Sql.g:265:45: AS
                                    {
                                    AS217=(Token)match(input,AS,FOLLOW_AS_in_single_source2101);  
                                    stream_AS.add(AS217);


                                    }
                                    break;

                            }

                            table_alias=(Token)match(input,ID,FOLLOW_ID_in_single_source2107);  
                            stream_ID.add(table_alias);


                            }
                            break;

                    }

                    // sqljet/src/Sql.g:265:67: ( INDEXED BY index_name= id | NOT INDEXED )?
                    int alt78=3;
                    alt78 = dfa78.predict(input);
                    switch (alt78) {
                        case 1 :
                            // sqljet/src/Sql.g:265:68: INDEXED BY index_name= id
                            {
                            INDEXED218=(Token)match(input,INDEXED,FOLLOW_INDEXED_in_single_source2112);  
                            stream_INDEXED.add(INDEXED218);

                            BY219=(Token)match(input,BY,FOLLOW_BY_in_single_source2114);  
                            stream_BY.add(BY219);

                            pushFollow(FOLLOW_id_in_single_source2118);
                            index_name=id();

                            state._fsp--;

                            stream_id.add(index_name.getTree());

                            }
                            break;
                        case 2 :
                            // sqljet/src/Sql.g:265:95: NOT INDEXED
                            {
                            NOT220=(Token)match(input,NOT,FOLLOW_NOT_in_single_source2122);  
                            stream_NOT.add(NOT220);

                            INDEXED221=(Token)match(input,INDEXED,FOLLOW_INDEXED_in_single_source2124);  
                            stream_INDEXED.add(INDEXED221);


                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: table_name, table_alias, NOT, database_name, index_name, INDEXED
                    // token labels: table_alias, table_name
                    // rule labels: index_name, database_name, retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleTokenStream stream_table_alias=new RewriteRuleTokenStream(adaptor,"token table_alias",table_alias);
                    RewriteRuleTokenStream stream_table_name=new RewriteRuleTokenStream(adaptor,"token table_name",table_name);
                    RewriteRuleSubtreeStream stream_index_name=new RewriteRuleSubtreeStream(adaptor,"rule index_name",index_name!=null?index_name.tree:null);
                    RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 266:3: -> ^( ALIAS ^( $table_name ( $database_name)? ) ( $table_alias)? ( ^( INDEXED ( NOT )? ( $index_name)? ) )? )
                    {
                        // sqljet/src/Sql.g:266:6: ^( ALIAS ^( $table_name ( $database_name)? ) ( $table_alias)? ( ^( INDEXED ( NOT )? ( $index_name)? ) )? )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(ALIAS, "ALIAS"), root_1);

                        // sqljet/src/Sql.g:266:14: ^( $table_name ( $database_name)? )
                        {
                        Object root_2 = (Object)adaptor.nil();
                        root_2 = (Object)adaptor.becomeRoot(stream_table_name.nextNode(), root_2);

                        // sqljet/src/Sql.g:266:28: ( $database_name)?
                        if ( stream_database_name.hasNext() ) {
                            adaptor.addChild(root_2, stream_database_name.nextTree());

                        }
                        stream_database_name.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // sqljet/src/Sql.g:266:45: ( $table_alias)?
                        if ( stream_table_alias.hasNext() ) {
                            adaptor.addChild(root_1, stream_table_alias.nextNode());

                        }
                        stream_table_alias.reset();
                        // sqljet/src/Sql.g:266:59: ( ^( INDEXED ( NOT )? ( $index_name)? ) )?
                        if ( stream_NOT.hasNext()||stream_index_name.hasNext()||stream_INDEXED.hasNext() ) {
                            // sqljet/src/Sql.g:266:59: ^( INDEXED ( NOT )? ( $index_name)? )
                            {
                            Object root_2 = (Object)adaptor.nil();
                            root_2 = (Object)adaptor.becomeRoot(stream_INDEXED.nextNode(), root_2);

                            // sqljet/src/Sql.g:266:69: ( NOT )?
                            if ( stream_NOT.hasNext() ) {
                                adaptor.addChild(root_2, stream_NOT.nextNode());

                            }
                            stream_NOT.reset();
                            // sqljet/src/Sql.g:266:74: ( $index_name)?
                            if ( stream_index_name.hasNext() ) {
                                adaptor.addChild(root_2, stream_index_name.nextTree());

                            }
                            stream_index_name.reset();

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_NOT.reset();
                        stream_index_name.reset();
                        stream_INDEXED.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:267:5: LPAREN select_stmt RPAREN ( ( AS )? table_alias= ID )?
                    {
                    LPAREN222=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_single_source2165);  
                    stream_LPAREN.add(LPAREN222);

                    pushFollow(FOLLOW_select_stmt_in_single_source2167);
                    select_stmt223=select_stmt();

                    state._fsp--;

                    stream_select_stmt.add(select_stmt223.getTree());
                    RPAREN224=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_single_source2169);  
                    stream_RPAREN.add(RPAREN224);

                    // sqljet/src/Sql.g:267:31: ( ( AS )? table_alias= ID )?
                    int alt80=2;
                    alt80 = dfa80.predict(input);
                    switch (alt80) {
                        case 1 :
                            // sqljet/src/Sql.g:267:32: ( AS )? table_alias= ID
                            {
                            // sqljet/src/Sql.g:267:32: ( AS )?
                            int alt79=2;
                            int LA79_0 = input.LA(1);

                            if ( (LA79_0==AS) ) {
                                alt79=1;
                            }
                            switch (alt79) {
                                case 1 :
                                    // sqljet/src/Sql.g:267:33: AS
                                    {
                                    AS225=(Token)match(input,AS,FOLLOW_AS_in_single_source2173);  
                                    stream_AS.add(AS225);


                                    }
                                    break;

                            }

                            table_alias=(Token)match(input,ID,FOLLOW_ID_in_single_source2179);  
                            stream_ID.add(table_alias);


                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: table_alias, select_stmt
                    // token labels: table_alias
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleTokenStream stream_table_alias=new RewriteRuleTokenStream(adaptor,"token table_alias",table_alias);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 268:3: -> ^( ALIAS select_stmt ( $table_alias)? )
                    {
                        // sqljet/src/Sql.g:268:6: ^( ALIAS select_stmt ( $table_alias)? )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(ALIAS, "ALIAS"), root_1);

                        adaptor.addChild(root_1, stream_select_stmt.nextTree());
                        // sqljet/src/Sql.g:268:26: ( $table_alias)?
                        if ( stream_table_alias.hasNext() ) {
                            adaptor.addChild(root_1, stream_table_alias.nextNode());

                        }
                        stream_table_alias.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:269:5: LPAREN join_source RPAREN
                    {
                    root_0 = (Object)adaptor.nil();

                    LPAREN226=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_single_source2201); 
                    pushFollow(FOLLOW_join_source_in_single_source2204);
                    join_source227=join_source();

                    state._fsp--;

                    adaptor.addChild(root_0, join_source227.getTree());
                    RPAREN228=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_single_source2206); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "single_source"

    public static class join_op_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "join_op"
    // sqljet/src/Sql.g:271:1: join_op : ( COMMA | ( NATURAL )? ( ( LEFT )? ( OUTER )? | INNER | CROSS ) JOIN );
    public final SqlParser.join_op_return join_op() throws RecognitionException {
        SqlParser.join_op_return retval = new SqlParser.join_op_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token COMMA229=null;
        Token NATURAL230=null;
        Token LEFT231=null;
        Token OUTER232=null;
        Token INNER233=null;
        Token CROSS234=null;
        Token JOIN235=null;

        Object COMMA229_tree=null;
        Object NATURAL230_tree=null;
        Object LEFT231_tree=null;
        Object OUTER232_tree=null;
        Object INNER233_tree=null;
        Object CROSS234_tree=null;
        Object JOIN235_tree=null;

        try {
            // sqljet/src/Sql.g:272:3: ( COMMA | ( NATURAL )? ( ( LEFT )? ( OUTER )? | INNER | CROSS ) JOIN )
            int alt86=2;
            int LA86_0 = input.LA(1);

            if ( (LA86_0==COMMA) ) {
                alt86=1;
            }
            else if ( ((LA86_0>=NATURAL && LA86_0<=JOIN)) ) {
                alt86=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 86, 0, input);

                throw nvae;
            }
            switch (alt86) {
                case 1 :
                    // sqljet/src/Sql.g:272:5: COMMA
                    {
                    root_0 = (Object)adaptor.nil();

                    COMMA229=(Token)match(input,COMMA,FOLLOW_COMMA_in_join_op2217); 
                    COMMA229_tree = (Object)adaptor.create(COMMA229);
                    adaptor.addChild(root_0, COMMA229_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:273:5: ( NATURAL )? ( ( LEFT )? ( OUTER )? | INNER | CROSS ) JOIN
                    {
                    root_0 = (Object)adaptor.nil();

                    // sqljet/src/Sql.g:273:5: ( NATURAL )?
                    int alt82=2;
                    int LA82_0 = input.LA(1);

                    if ( (LA82_0==NATURAL) ) {
                        alt82=1;
                    }
                    switch (alt82) {
                        case 1 :
                            // sqljet/src/Sql.g:273:6: NATURAL
                            {
                            NATURAL230=(Token)match(input,NATURAL,FOLLOW_NATURAL_in_join_op2224); 
                            NATURAL230_tree = (Object)adaptor.create(NATURAL230);
                            adaptor.addChild(root_0, NATURAL230_tree);


                            }
                            break;

                    }

                    // sqljet/src/Sql.g:273:16: ( ( LEFT )? ( OUTER )? | INNER | CROSS )
                    int alt85=3;
                    switch ( input.LA(1) ) {
                    case LEFT:
                    case OUTER:
                    case JOIN:
                        {
                        alt85=1;
                        }
                        break;
                    case INNER:
                        {
                        alt85=2;
                        }
                        break;
                    case CROSS:
                        {
                        alt85=3;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 85, 0, input);

                        throw nvae;
                    }

                    switch (alt85) {
                        case 1 :
                            // sqljet/src/Sql.g:273:17: ( LEFT )? ( OUTER )?
                            {
                            // sqljet/src/Sql.g:273:17: ( LEFT )?
                            int alt83=2;
                            int LA83_0 = input.LA(1);

                            if ( (LA83_0==LEFT) ) {
                                alt83=1;
                            }
                            switch (alt83) {
                                case 1 :
                                    // sqljet/src/Sql.g:273:18: LEFT
                                    {
                                    LEFT231=(Token)match(input,LEFT,FOLLOW_LEFT_in_join_op2230); 
                                    LEFT231_tree = (Object)adaptor.create(LEFT231);
                                    adaptor.addChild(root_0, LEFT231_tree);


                                    }
                                    break;

                            }

                            // sqljet/src/Sql.g:273:25: ( OUTER )?
                            int alt84=2;
                            int LA84_0 = input.LA(1);

                            if ( (LA84_0==OUTER) ) {
                                alt84=1;
                            }
                            switch (alt84) {
                                case 1 :
                                    // sqljet/src/Sql.g:273:26: OUTER
                                    {
                                    OUTER232=(Token)match(input,OUTER,FOLLOW_OUTER_in_join_op2235); 
                                    OUTER232_tree = (Object)adaptor.create(OUTER232);
                                    adaptor.addChild(root_0, OUTER232_tree);


                                    }
                                    break;

                            }


                            }
                            break;
                        case 2 :
                            // sqljet/src/Sql.g:273:36: INNER
                            {
                            INNER233=(Token)match(input,INNER,FOLLOW_INNER_in_join_op2241); 
                            INNER233_tree = (Object)adaptor.create(INNER233);
                            adaptor.addChild(root_0, INNER233_tree);


                            }
                            break;
                        case 3 :
                            // sqljet/src/Sql.g:273:44: CROSS
                            {
                            CROSS234=(Token)match(input,CROSS,FOLLOW_CROSS_in_join_op2245); 
                            CROSS234_tree = (Object)adaptor.create(CROSS234);
                            adaptor.addChild(root_0, CROSS234_tree);


                            }
                            break;

                    }

                    JOIN235=(Token)match(input,JOIN,FOLLOW_JOIN_in_join_op2248); 
                    JOIN235_tree = (Object)adaptor.create(JOIN235);
                    root_0 = (Object)adaptor.becomeRoot(JOIN235_tree, root_0);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "join_op"

    public static class join_constraint_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "join_constraint"
    // sqljet/src/Sql.g:275:1: join_constraint : ( ON expr | USING LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN -> ^( USING ( $column_names)+ ) );
    public final SqlParser.join_constraint_return join_constraint() throws RecognitionException {
        SqlParser.join_constraint_return retval = new SqlParser.join_constraint_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ON236=null;
        Token USING238=null;
        Token LPAREN239=null;
        Token COMMA240=null;
        Token RPAREN241=null;
        List list_column_names=null;
        SqlParser.expr_return expr237 = null;

        SqlParser.id_return column_names = null;
         column_names = null;
        Object ON236_tree=null;
        Object USING238_tree=null;
        Object LPAREN239_tree=null;
        Object COMMA240_tree=null;
        Object RPAREN241_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_USING=new RewriteRuleTokenStream(adaptor,"token USING");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:276:3: ( ON expr | USING LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN -> ^( USING ( $column_names)+ ) )
            int alt88=2;
            int LA88_0 = input.LA(1);

            if ( (LA88_0==ON) ) {
                alt88=1;
            }
            else if ( (LA88_0==USING) ) {
                alt88=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 88, 0, input);

                throw nvae;
            }
            switch (alt88) {
                case 1 :
                    // sqljet/src/Sql.g:276:5: ON expr
                    {
                    root_0 = (Object)adaptor.nil();

                    ON236=(Token)match(input,ON,FOLLOW_ON_in_join_constraint2259); 
                    ON236_tree = (Object)adaptor.create(ON236);
                    root_0 = (Object)adaptor.becomeRoot(ON236_tree, root_0);

                    pushFollow(FOLLOW_expr_in_join_constraint2262);
                    expr237=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr237.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:277:5: USING LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN
                    {
                    USING238=(Token)match(input,USING,FOLLOW_USING_in_join_constraint2268);  
                    stream_USING.add(USING238);

                    LPAREN239=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_join_constraint2270);  
                    stream_LPAREN.add(LPAREN239);

                    pushFollow(FOLLOW_id_in_join_constraint2274);
                    column_names=id();

                    state._fsp--;

                    stream_id.add(column_names.getTree());
                    if (list_column_names==null) list_column_names=new ArrayList();
                    list_column_names.add(column_names.getTree());

                    // sqljet/src/Sql.g:277:35: ( COMMA column_names+= id )*
                    loop87:
                    do {
                        int alt87=2;
                        int LA87_0 = input.LA(1);

                        if ( (LA87_0==COMMA) ) {
                            alt87=1;
                        }


                        switch (alt87) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:277:36: COMMA column_names+= id
                    	    {
                    	    COMMA240=(Token)match(input,COMMA,FOLLOW_COMMA_in_join_constraint2277);  
                    	    stream_COMMA.add(COMMA240);

                    	    pushFollow(FOLLOW_id_in_join_constraint2281);
                    	    column_names=id();

                    	    state._fsp--;

                    	    stream_id.add(column_names.getTree());
                    	    if (list_column_names==null) list_column_names=new ArrayList();
                    	    list_column_names.add(column_names.getTree());


                    	    }
                    	    break;

                    	default :
                    	    break loop87;
                        }
                    } while (true);

                    RPAREN241=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_join_constraint2285);  
                    stream_RPAREN.add(RPAREN241);



                    // AST REWRITE
                    // elements: column_names, USING
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: column_names
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_column_names=new RewriteRuleSubtreeStream(adaptor,"token column_names",list_column_names);
                    root_0 = (Object)adaptor.nil();
                    // 277:68: -> ^( USING ( $column_names)+ )
                    {
                        // sqljet/src/Sql.g:277:71: ^( USING ( $column_names)+ )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_USING.nextNode(), root_1);

                        if ( !(stream_column_names.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_column_names.hasNext() ) {
                            adaptor.addChild(root_1, stream_column_names.nextTree());

                        }
                        stream_column_names.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "join_constraint"

    public static class insert_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "insert_stmt"
    // sqljet/src/Sql.g:280:1: insert_stmt : ( INSERT ( operation_conflict_clause )? | REPLACE ) INTO (database_name= id DOT )? table_name= id ( ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( VALUES LPAREN values+= expr ( COMMA values+= expr )* RPAREN | select_stmt ) | DEFAULT VALUES ) ;
    public final SqlParser.insert_stmt_return insert_stmt() throws RecognitionException {
        SqlParser.insert_stmt_return retval = new SqlParser.insert_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token INSERT242=null;
        Token REPLACE244=null;
        Token INTO245=null;
        Token DOT246=null;
        Token LPAREN247=null;
        Token COMMA248=null;
        Token RPAREN249=null;
        Token VALUES250=null;
        Token LPAREN251=null;
        Token COMMA252=null;
        Token RPAREN253=null;
        Token DEFAULT255=null;
        Token VALUES256=null;
        List list_column_names=null;
        List list_values=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.operation_conflict_clause_return operation_conflict_clause243 = null;

        SqlParser.select_stmt_return select_stmt254 = null;

        SqlParser.id_return column_names = null;
         column_names = null;
        SqlParser.expr_return values = null;
         values = null;
        Object INSERT242_tree=null;
        Object REPLACE244_tree=null;
        Object INTO245_tree=null;
        Object DOT246_tree=null;
        Object LPAREN247_tree=null;
        Object COMMA248_tree=null;
        Object RPAREN249_tree=null;
        Object VALUES250_tree=null;
        Object LPAREN251_tree=null;
        Object COMMA252_tree=null;
        Object RPAREN253_tree=null;
        Object DEFAULT255_tree=null;
        Object VALUES256_tree=null;

        try {
            // sqljet/src/Sql.g:280:12: ( ( INSERT ( operation_conflict_clause )? | REPLACE ) INTO (database_name= id DOT )? table_name= id ( ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( VALUES LPAREN values+= expr ( COMMA values+= expr )* RPAREN | select_stmt ) | DEFAULT VALUES ) )
            // sqljet/src/Sql.g:280:14: ( INSERT ( operation_conflict_clause )? | REPLACE ) INTO (database_name= id DOT )? table_name= id ( ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( VALUES LPAREN values+= expr ( COMMA values+= expr )* RPAREN | select_stmt ) | DEFAULT VALUES )
            {
            root_0 = (Object)adaptor.nil();

            // sqljet/src/Sql.g:280:14: ( INSERT ( operation_conflict_clause )? | REPLACE )
            int alt90=2;
            int LA90_0 = input.LA(1);

            if ( (LA90_0==INSERT) ) {
                alt90=1;
            }
            else if ( (LA90_0==REPLACE) ) {
                alt90=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 90, 0, input);

                throw nvae;
            }
            switch (alt90) {
                case 1 :
                    // sqljet/src/Sql.g:280:15: INSERT ( operation_conflict_clause )?
                    {
                    INSERT242=(Token)match(input,INSERT,FOLLOW_INSERT_in_insert_stmt2304); 
                    INSERT242_tree = (Object)adaptor.create(INSERT242);
                    adaptor.addChild(root_0, INSERT242_tree);

                    // sqljet/src/Sql.g:280:22: ( operation_conflict_clause )?
                    int alt89=2;
                    int LA89_0 = input.LA(1);

                    if ( (LA89_0==OR) ) {
                        alt89=1;
                    }
                    switch (alt89) {
                        case 1 :
                            // sqljet/src/Sql.g:280:23: operation_conflict_clause
                            {
                            pushFollow(FOLLOW_operation_conflict_clause_in_insert_stmt2307);
                            operation_conflict_clause243=operation_conflict_clause();

                            state._fsp--;

                            adaptor.addChild(root_0, operation_conflict_clause243.getTree());

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:280:53: REPLACE
                    {
                    REPLACE244=(Token)match(input,REPLACE,FOLLOW_REPLACE_in_insert_stmt2313); 
                    REPLACE244_tree = (Object)adaptor.create(REPLACE244);
                    adaptor.addChild(root_0, REPLACE244_tree);


                    }
                    break;

            }

            INTO245=(Token)match(input,INTO,FOLLOW_INTO_in_insert_stmt2316); 
            INTO245_tree = (Object)adaptor.create(INTO245);
            adaptor.addChild(root_0, INTO245_tree);

            // sqljet/src/Sql.g:280:67: (database_name= id DOT )?
            int alt91=2;
            alt91 = dfa91.predict(input);
            switch (alt91) {
                case 1 :
                    // sqljet/src/Sql.g:280:68: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_insert_stmt2321);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT246=(Token)match(input,DOT,FOLLOW_DOT_in_insert_stmt2323); 
                    DOT246_tree = (Object)adaptor.create(DOT246);
                    adaptor.addChild(root_0, DOT246_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_insert_stmt2329);
            table_name=id();

            state._fsp--;

            adaptor.addChild(root_0, table_name.getTree());
            // sqljet/src/Sql.g:281:3: ( ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( VALUES LPAREN values+= expr ( COMMA values+= expr )* RPAREN | select_stmt ) | DEFAULT VALUES )
            int alt96=2;
            int LA96_0 = input.LA(1);

            if ( (LA96_0==LPAREN||LA96_0==SELECT||LA96_0==VALUES) ) {
                alt96=1;
            }
            else if ( (LA96_0==DEFAULT) ) {
                alt96=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 96, 0, input);

                throw nvae;
            }
            switch (alt96) {
                case 1 :
                    // sqljet/src/Sql.g:281:5: ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( VALUES LPAREN values+= expr ( COMMA values+= expr )* RPAREN | select_stmt )
                    {
                    // sqljet/src/Sql.g:281:5: ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )?
                    int alt93=2;
                    int LA93_0 = input.LA(1);

                    if ( (LA93_0==LPAREN) ) {
                        alt93=1;
                    }
                    switch (alt93) {
                        case 1 :
                            // sqljet/src/Sql.g:281:6: LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN
                            {
                            LPAREN247=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_insert_stmt2336); 
                            LPAREN247_tree = (Object)adaptor.create(LPAREN247);
                            adaptor.addChild(root_0, LPAREN247_tree);

                            pushFollow(FOLLOW_id_in_insert_stmt2340);
                            column_names=id();

                            state._fsp--;

                            adaptor.addChild(root_0, column_names.getTree());
                            if (list_column_names==null) list_column_names=new ArrayList();
                            list_column_names.add(column_names.getTree());

                            // sqljet/src/Sql.g:281:30: ( COMMA column_names+= id )*
                            loop92:
                            do {
                                int alt92=2;
                                int LA92_0 = input.LA(1);

                                if ( (LA92_0==COMMA) ) {
                                    alt92=1;
                                }


                                switch (alt92) {
                            	case 1 :
                            	    // sqljet/src/Sql.g:281:31: COMMA column_names+= id
                            	    {
                            	    COMMA248=(Token)match(input,COMMA,FOLLOW_COMMA_in_insert_stmt2343); 
                            	    COMMA248_tree = (Object)adaptor.create(COMMA248);
                            	    adaptor.addChild(root_0, COMMA248_tree);

                            	    pushFollow(FOLLOW_id_in_insert_stmt2347);
                            	    column_names=id();

                            	    state._fsp--;

                            	    adaptor.addChild(root_0, column_names.getTree());
                            	    if (list_column_names==null) list_column_names=new ArrayList();
                            	    list_column_names.add(column_names.getTree());


                            	    }
                            	    break;

                            	default :
                            	    break loop92;
                                }
                            } while (true);

                            RPAREN249=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_insert_stmt2351); 
                            RPAREN249_tree = (Object)adaptor.create(RPAREN249);
                            adaptor.addChild(root_0, RPAREN249_tree);


                            }
                            break;

                    }

                    // sqljet/src/Sql.g:282:5: ( VALUES LPAREN values+= expr ( COMMA values+= expr )* RPAREN | select_stmt )
                    int alt95=2;
                    int LA95_0 = input.LA(1);

                    if ( (LA95_0==VALUES) ) {
                        alt95=1;
                    }
                    else if ( (LA95_0==SELECT) ) {
                        alt95=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 95, 0, input);

                        throw nvae;
                    }
                    switch (alt95) {
                        case 1 :
                            // sqljet/src/Sql.g:282:6: VALUES LPAREN values+= expr ( COMMA values+= expr )* RPAREN
                            {
                            VALUES250=(Token)match(input,VALUES,FOLLOW_VALUES_in_insert_stmt2360); 
                            VALUES250_tree = (Object)adaptor.create(VALUES250);
                            adaptor.addChild(root_0, VALUES250_tree);

                            LPAREN251=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_insert_stmt2362); 
                            LPAREN251_tree = (Object)adaptor.create(LPAREN251);
                            adaptor.addChild(root_0, LPAREN251_tree);

                            pushFollow(FOLLOW_expr_in_insert_stmt2366);
                            values=expr();

                            state._fsp--;

                            adaptor.addChild(root_0, values.getTree());
                            if (list_values==null) list_values=new ArrayList();
                            list_values.add(values.getTree());

                            // sqljet/src/Sql.g:282:33: ( COMMA values+= expr )*
                            loop94:
                            do {
                                int alt94=2;
                                int LA94_0 = input.LA(1);

                                if ( (LA94_0==COMMA) ) {
                                    alt94=1;
                                }


                                switch (alt94) {
                            	case 1 :
                            	    // sqljet/src/Sql.g:282:34: COMMA values+= expr
                            	    {
                            	    COMMA252=(Token)match(input,COMMA,FOLLOW_COMMA_in_insert_stmt2369); 
                            	    COMMA252_tree = (Object)adaptor.create(COMMA252);
                            	    adaptor.addChild(root_0, COMMA252_tree);

                            	    pushFollow(FOLLOW_expr_in_insert_stmt2373);
                            	    values=expr();

                            	    state._fsp--;

                            	    adaptor.addChild(root_0, values.getTree());
                            	    if (list_values==null) list_values=new ArrayList();
                            	    list_values.add(values.getTree());


                            	    }
                            	    break;

                            	default :
                            	    break loop94;
                                }
                            } while (true);

                            RPAREN253=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_insert_stmt2377); 
                            RPAREN253_tree = (Object)adaptor.create(RPAREN253);
                            adaptor.addChild(root_0, RPAREN253_tree);


                            }
                            break;
                        case 2 :
                            // sqljet/src/Sql.g:282:64: select_stmt
                            {
                            pushFollow(FOLLOW_select_stmt_in_insert_stmt2381);
                            select_stmt254=select_stmt();

                            state._fsp--;

                            adaptor.addChild(root_0, select_stmt254.getTree());

                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:283:5: DEFAULT VALUES
                    {
                    DEFAULT255=(Token)match(input,DEFAULT,FOLLOW_DEFAULT_in_insert_stmt2388); 
                    DEFAULT255_tree = (Object)adaptor.create(DEFAULT255);
                    adaptor.addChild(root_0, DEFAULT255_tree);

                    VALUES256=(Token)match(input,VALUES,FOLLOW_VALUES_in_insert_stmt2390); 
                    VALUES256_tree = (Object)adaptor.create(VALUES256);
                    adaptor.addChild(root_0, VALUES256_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "insert_stmt"

    public static class update_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "update_stmt"
    // sqljet/src/Sql.g:286:1: update_stmt : UPDATE ( operation_conflict_clause )? qualified_table_name SET values+= update_set ( COMMA values+= update_set )* ( WHERE expr )? ( operation_limited_clause )? ;
    public final SqlParser.update_stmt_return update_stmt() throws RecognitionException {
        SqlParser.update_stmt_return retval = new SqlParser.update_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token UPDATE257=null;
        Token SET260=null;
        Token COMMA261=null;
        Token WHERE262=null;
        List list_values=null;
        SqlParser.operation_conflict_clause_return operation_conflict_clause258 = null;

        SqlParser.qualified_table_name_return qualified_table_name259 = null;

        SqlParser.expr_return expr263 = null;

        SqlParser.operation_limited_clause_return operation_limited_clause264 = null;

        SqlParser.update_set_return values = null;
         values = null;
        Object UPDATE257_tree=null;
        Object SET260_tree=null;
        Object COMMA261_tree=null;
        Object WHERE262_tree=null;

        try {
            // sqljet/src/Sql.g:286:12: ( UPDATE ( operation_conflict_clause )? qualified_table_name SET values+= update_set ( COMMA values+= update_set )* ( WHERE expr )? ( operation_limited_clause )? )
            // sqljet/src/Sql.g:286:14: UPDATE ( operation_conflict_clause )? qualified_table_name SET values+= update_set ( COMMA values+= update_set )* ( WHERE expr )? ( operation_limited_clause )?
            {
            root_0 = (Object)adaptor.nil();

            UPDATE257=(Token)match(input,UPDATE,FOLLOW_UPDATE_in_update_stmt2400); 
            UPDATE257_tree = (Object)adaptor.create(UPDATE257);
            adaptor.addChild(root_0, UPDATE257_tree);

            // sqljet/src/Sql.g:286:21: ( operation_conflict_clause )?
            int alt97=2;
            int LA97_0 = input.LA(1);

            if ( (LA97_0==OR) ) {
                int LA97_1 = input.LA(2);

                if ( ((LA97_1>=IGNORE && LA97_1<=FAIL)||LA97_1==REPLACE) ) {
                    alt97=1;
                }
            }
            switch (alt97) {
                case 1 :
                    // sqljet/src/Sql.g:286:22: operation_conflict_clause
                    {
                    pushFollow(FOLLOW_operation_conflict_clause_in_update_stmt2403);
                    operation_conflict_clause258=operation_conflict_clause();

                    state._fsp--;

                    adaptor.addChild(root_0, operation_conflict_clause258.getTree());

                    }
                    break;

            }

            pushFollow(FOLLOW_qualified_table_name_in_update_stmt2407);
            qualified_table_name259=qualified_table_name();

            state._fsp--;

            adaptor.addChild(root_0, qualified_table_name259.getTree());
            SET260=(Token)match(input,SET,FOLLOW_SET_in_update_stmt2411); 
            SET260_tree = (Object)adaptor.create(SET260);
            adaptor.addChild(root_0, SET260_tree);

            pushFollow(FOLLOW_update_set_in_update_stmt2415);
            values=update_set();

            state._fsp--;

            adaptor.addChild(root_0, values.getTree());
            if (list_values==null) list_values=new ArrayList();
            list_values.add(values.getTree());

            // sqljet/src/Sql.g:287:26: ( COMMA values+= update_set )*
            loop98:
            do {
                int alt98=2;
                int LA98_0 = input.LA(1);

                if ( (LA98_0==COMMA) ) {
                    alt98=1;
                }


                switch (alt98) {
            	case 1 :
            	    // sqljet/src/Sql.g:287:27: COMMA values+= update_set
            	    {
            	    COMMA261=(Token)match(input,COMMA,FOLLOW_COMMA_in_update_stmt2418); 
            	    COMMA261_tree = (Object)adaptor.create(COMMA261);
            	    adaptor.addChild(root_0, COMMA261_tree);

            	    pushFollow(FOLLOW_update_set_in_update_stmt2422);
            	    values=update_set();

            	    state._fsp--;

            	    adaptor.addChild(root_0, values.getTree());
            	    if (list_values==null) list_values=new ArrayList();
            	    list_values.add(values.getTree());


            	    }
            	    break;

            	default :
            	    break loop98;
                }
            } while (true);

            // sqljet/src/Sql.g:287:54: ( WHERE expr )?
            int alt99=2;
            int LA99_0 = input.LA(1);

            if ( (LA99_0==WHERE) ) {
                alt99=1;
            }
            switch (alt99) {
                case 1 :
                    // sqljet/src/Sql.g:287:55: WHERE expr
                    {
                    WHERE262=(Token)match(input,WHERE,FOLLOW_WHERE_in_update_stmt2427); 
                    WHERE262_tree = (Object)adaptor.create(WHERE262);
                    adaptor.addChild(root_0, WHERE262_tree);

                    pushFollow(FOLLOW_expr_in_update_stmt2429);
                    expr263=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr263.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:287:68: ( operation_limited_clause )?
            int alt100=2;
            int LA100_0 = input.LA(1);

            if ( ((LA100_0>=ORDER && LA100_0<=LIMIT)) ) {
                alt100=1;
            }
            switch (alt100) {
                case 1 :
                    // sqljet/src/Sql.g:287:69: operation_limited_clause
                    {
                    pushFollow(FOLLOW_operation_limited_clause_in_update_stmt2434);
                    operation_limited_clause264=operation_limited_clause();

                    state._fsp--;

                    adaptor.addChild(root_0, operation_limited_clause264.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "update_stmt"

    public static class update_set_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "update_set"
    // sqljet/src/Sql.g:289:1: update_set : column_name= id EQUALS expr ;
    public final SqlParser.update_set_return update_set() throws RecognitionException {
        SqlParser.update_set_return retval = new SqlParser.update_set_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token EQUALS265=null;
        SqlParser.id_return column_name = null;

        SqlParser.expr_return expr266 = null;


        Object EQUALS265_tree=null;

        try {
            // sqljet/src/Sql.g:289:11: (column_name= id EQUALS expr )
            // sqljet/src/Sql.g:289:13: column_name= id EQUALS expr
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_id_in_update_set2445);
            column_name=id();

            state._fsp--;

            adaptor.addChild(root_0, column_name.getTree());
            EQUALS265=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_update_set2447); 
            EQUALS265_tree = (Object)adaptor.create(EQUALS265);
            adaptor.addChild(root_0, EQUALS265_tree);

            pushFollow(FOLLOW_expr_in_update_set2449);
            expr266=expr();

            state._fsp--;

            adaptor.addChild(root_0, expr266.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "update_set"

    public static class delete_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "delete_stmt"
    // sqljet/src/Sql.g:292:1: delete_stmt : DELETE FROM qualified_table_name ( WHERE expr )? ( operation_limited_clause )? ;
    public final SqlParser.delete_stmt_return delete_stmt() throws RecognitionException {
        SqlParser.delete_stmt_return retval = new SqlParser.delete_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DELETE267=null;
        Token FROM268=null;
        Token WHERE270=null;
        SqlParser.qualified_table_name_return qualified_table_name269 = null;

        SqlParser.expr_return expr271 = null;

        SqlParser.operation_limited_clause_return operation_limited_clause272 = null;


        Object DELETE267_tree=null;
        Object FROM268_tree=null;
        Object WHERE270_tree=null;

        try {
            // sqljet/src/Sql.g:292:12: ( DELETE FROM qualified_table_name ( WHERE expr )? ( operation_limited_clause )? )
            // sqljet/src/Sql.g:292:14: DELETE FROM qualified_table_name ( WHERE expr )? ( operation_limited_clause )?
            {
            root_0 = (Object)adaptor.nil();

            DELETE267=(Token)match(input,DELETE,FOLLOW_DELETE_in_delete_stmt2457); 
            DELETE267_tree = (Object)adaptor.create(DELETE267);
            adaptor.addChild(root_0, DELETE267_tree);

            FROM268=(Token)match(input,FROM,FOLLOW_FROM_in_delete_stmt2459); 
            FROM268_tree = (Object)adaptor.create(FROM268);
            adaptor.addChild(root_0, FROM268_tree);

            pushFollow(FOLLOW_qualified_table_name_in_delete_stmt2461);
            qualified_table_name269=qualified_table_name();

            state._fsp--;

            adaptor.addChild(root_0, qualified_table_name269.getTree());
            // sqljet/src/Sql.g:292:47: ( WHERE expr )?
            int alt101=2;
            int LA101_0 = input.LA(1);

            if ( (LA101_0==WHERE) ) {
                alt101=1;
            }
            switch (alt101) {
                case 1 :
                    // sqljet/src/Sql.g:292:48: WHERE expr
                    {
                    WHERE270=(Token)match(input,WHERE,FOLLOW_WHERE_in_delete_stmt2464); 
                    WHERE270_tree = (Object)adaptor.create(WHERE270);
                    adaptor.addChild(root_0, WHERE270_tree);

                    pushFollow(FOLLOW_expr_in_delete_stmt2466);
                    expr271=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr271.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:292:61: ( operation_limited_clause )?
            int alt102=2;
            int LA102_0 = input.LA(1);

            if ( ((LA102_0>=ORDER && LA102_0<=LIMIT)) ) {
                alt102=1;
            }
            switch (alt102) {
                case 1 :
                    // sqljet/src/Sql.g:292:62: operation_limited_clause
                    {
                    pushFollow(FOLLOW_operation_limited_clause_in_delete_stmt2471);
                    operation_limited_clause272=operation_limited_clause();

                    state._fsp--;

                    adaptor.addChild(root_0, operation_limited_clause272.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "delete_stmt"

    public static class begin_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "begin_stmt"
    // sqljet/src/Sql.g:295:1: begin_stmt : BEGIN ( DEFERRED | IMMEDIATE | EXCLUSIVE )? ( TRANSACTION )? ;
    public final SqlParser.begin_stmt_return begin_stmt() throws RecognitionException {
        SqlParser.begin_stmt_return retval = new SqlParser.begin_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token BEGIN273=null;
        Token set274=null;
        Token TRANSACTION275=null;

        Object BEGIN273_tree=null;
        Object set274_tree=null;
        Object TRANSACTION275_tree=null;

        try {
            // sqljet/src/Sql.g:295:11: ( BEGIN ( DEFERRED | IMMEDIATE | EXCLUSIVE )? ( TRANSACTION )? )
            // sqljet/src/Sql.g:295:13: BEGIN ( DEFERRED | IMMEDIATE | EXCLUSIVE )? ( TRANSACTION )?
            {
            root_0 = (Object)adaptor.nil();

            BEGIN273=(Token)match(input,BEGIN,FOLLOW_BEGIN_in_begin_stmt2481); 
            BEGIN273_tree = (Object)adaptor.create(BEGIN273);
            adaptor.addChild(root_0, BEGIN273_tree);

            // sqljet/src/Sql.g:295:19: ( DEFERRED | IMMEDIATE | EXCLUSIVE )?
            int alt103=2;
            int LA103_0 = input.LA(1);

            if ( ((LA103_0>=DEFERRED && LA103_0<=EXCLUSIVE)) ) {
                alt103=1;
            }
            switch (alt103) {
                case 1 :
                    // sqljet/src/Sql.g:
                    {
                    set274=(Token)input.LT(1);
                    if ( (input.LA(1)>=DEFERRED && input.LA(1)<=EXCLUSIVE) ) {
                        input.consume();
                        adaptor.addChild(root_0, (Object)adaptor.create(set274));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            // sqljet/src/Sql.g:295:55: ( TRANSACTION )?
            int alt104=2;
            int LA104_0 = input.LA(1);

            if ( (LA104_0==TRANSACTION) ) {
                alt104=1;
            }
            switch (alt104) {
                case 1 :
                    // sqljet/src/Sql.g:295:56: TRANSACTION
                    {
                    TRANSACTION275=(Token)match(input,TRANSACTION,FOLLOW_TRANSACTION_in_begin_stmt2497); 
                    TRANSACTION275_tree = (Object)adaptor.create(TRANSACTION275);
                    adaptor.addChild(root_0, TRANSACTION275_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "begin_stmt"

    public static class commit_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "commit_stmt"
    // sqljet/src/Sql.g:298:1: commit_stmt : ( COMMIT | END ) ( TRANSACTION )? ;
    public final SqlParser.commit_stmt_return commit_stmt() throws RecognitionException {
        SqlParser.commit_stmt_return retval = new SqlParser.commit_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set276=null;
        Token TRANSACTION277=null;

        Object set276_tree=null;
        Object TRANSACTION277_tree=null;

        try {
            // sqljet/src/Sql.g:298:12: ( ( COMMIT | END ) ( TRANSACTION )? )
            // sqljet/src/Sql.g:298:14: ( COMMIT | END ) ( TRANSACTION )?
            {
            root_0 = (Object)adaptor.nil();

            set276=(Token)input.LT(1);
            if ( input.LA(1)==END||input.LA(1)==COMMIT ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set276));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            // sqljet/src/Sql.g:298:29: ( TRANSACTION )?
            int alt105=2;
            int LA105_0 = input.LA(1);

            if ( (LA105_0==TRANSACTION) ) {
                alt105=1;
            }
            switch (alt105) {
                case 1 :
                    // sqljet/src/Sql.g:298:30: TRANSACTION
                    {
                    TRANSACTION277=(Token)match(input,TRANSACTION,FOLLOW_TRANSACTION_in_commit_stmt2516); 
                    TRANSACTION277_tree = (Object)adaptor.create(TRANSACTION277);
                    adaptor.addChild(root_0, TRANSACTION277_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "commit_stmt"

    public static class rollback_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "rollback_stmt"
    // sqljet/src/Sql.g:301:1: rollback_stmt : ROLLBACK ( TRANSACTION )? ( TO ( SAVEPOINT )? savepoint_name= id )? ;
    public final SqlParser.rollback_stmt_return rollback_stmt() throws RecognitionException {
        SqlParser.rollback_stmt_return retval = new SqlParser.rollback_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ROLLBACK278=null;
        Token TRANSACTION279=null;
        Token TO280=null;
        Token SAVEPOINT281=null;
        SqlParser.id_return savepoint_name = null;


        Object ROLLBACK278_tree=null;
        Object TRANSACTION279_tree=null;
        Object TO280_tree=null;
        Object SAVEPOINT281_tree=null;

        try {
            // sqljet/src/Sql.g:301:14: ( ROLLBACK ( TRANSACTION )? ( TO ( SAVEPOINT )? savepoint_name= id )? )
            // sqljet/src/Sql.g:301:16: ROLLBACK ( TRANSACTION )? ( TO ( SAVEPOINT )? savepoint_name= id )?
            {
            root_0 = (Object)adaptor.nil();

            ROLLBACK278=(Token)match(input,ROLLBACK,FOLLOW_ROLLBACK_in_rollback_stmt2526); 
            ROLLBACK278_tree = (Object)adaptor.create(ROLLBACK278);
            adaptor.addChild(root_0, ROLLBACK278_tree);

            // sqljet/src/Sql.g:301:25: ( TRANSACTION )?
            int alt106=2;
            int LA106_0 = input.LA(1);

            if ( (LA106_0==TRANSACTION) ) {
                alt106=1;
            }
            switch (alt106) {
                case 1 :
                    // sqljet/src/Sql.g:301:26: TRANSACTION
                    {
                    TRANSACTION279=(Token)match(input,TRANSACTION,FOLLOW_TRANSACTION_in_rollback_stmt2529); 
                    TRANSACTION279_tree = (Object)adaptor.create(TRANSACTION279);
                    adaptor.addChild(root_0, TRANSACTION279_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:301:40: ( TO ( SAVEPOINT )? savepoint_name= id )?
            int alt108=2;
            int LA108_0 = input.LA(1);

            if ( (LA108_0==TO) ) {
                alt108=1;
            }
            switch (alt108) {
                case 1 :
                    // sqljet/src/Sql.g:301:41: TO ( SAVEPOINT )? savepoint_name= id
                    {
                    TO280=(Token)match(input,TO,FOLLOW_TO_in_rollback_stmt2534); 
                    TO280_tree = (Object)adaptor.create(TO280);
                    adaptor.addChild(root_0, TO280_tree);

                    // sqljet/src/Sql.g:301:44: ( SAVEPOINT )?
                    int alt107=2;
                    int LA107_0 = input.LA(1);

                    if ( (LA107_0==SAVEPOINT) ) {
                        int LA107_1 = input.LA(2);

                        if ( ((LA107_1>=EXPLAIN && LA107_1<=PLAN)||(LA107_1>=INDEXED && LA107_1<=BY)||(LA107_1>=OR && LA107_1<=ESCAPE)||(LA107_1>=IS && LA107_1<=BETWEEN)||(LA107_1>=COLLATE && LA107_1<=THEN)||(LA107_1>=CURRENT_TIME && LA107_1<=CURRENT_TIMESTAMP)||(LA107_1>=RAISE && LA107_1<=ROW)) ) {
                            alt107=1;
                        }
                    }
                    switch (alt107) {
                        case 1 :
                            // sqljet/src/Sql.g:301:45: SAVEPOINT
                            {
                            SAVEPOINT281=(Token)match(input,SAVEPOINT,FOLLOW_SAVEPOINT_in_rollback_stmt2537); 
                            SAVEPOINT281_tree = (Object)adaptor.create(SAVEPOINT281);
                            adaptor.addChild(root_0, SAVEPOINT281_tree);


                            }
                            break;

                    }

                    pushFollow(FOLLOW_id_in_rollback_stmt2543);
                    savepoint_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, savepoint_name.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "rollback_stmt"

    public static class savepoint_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "savepoint_stmt"
    // sqljet/src/Sql.g:304:1: savepoint_stmt : SAVEPOINT savepoint_name= id ;
    public final SqlParser.savepoint_stmt_return savepoint_stmt() throws RecognitionException {
        SqlParser.savepoint_stmt_return retval = new SqlParser.savepoint_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token SAVEPOINT282=null;
        SqlParser.id_return savepoint_name = null;


        Object SAVEPOINT282_tree=null;

        try {
            // sqljet/src/Sql.g:304:15: ( SAVEPOINT savepoint_name= id )
            // sqljet/src/Sql.g:304:17: SAVEPOINT savepoint_name= id
            {
            root_0 = (Object)adaptor.nil();

            SAVEPOINT282=(Token)match(input,SAVEPOINT,FOLLOW_SAVEPOINT_in_savepoint_stmt2553); 
            SAVEPOINT282_tree = (Object)adaptor.create(SAVEPOINT282);
            adaptor.addChild(root_0, SAVEPOINT282_tree);

            pushFollow(FOLLOW_id_in_savepoint_stmt2557);
            savepoint_name=id();

            state._fsp--;

            adaptor.addChild(root_0, savepoint_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "savepoint_stmt"

    public static class release_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "release_stmt"
    // sqljet/src/Sql.g:307:1: release_stmt : RELEASE ( SAVEPOINT )? savepoint_name= id ;
    public final SqlParser.release_stmt_return release_stmt() throws RecognitionException {
        SqlParser.release_stmt_return retval = new SqlParser.release_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token RELEASE283=null;
        Token SAVEPOINT284=null;
        SqlParser.id_return savepoint_name = null;


        Object RELEASE283_tree=null;
        Object SAVEPOINT284_tree=null;

        try {
            // sqljet/src/Sql.g:307:13: ( RELEASE ( SAVEPOINT )? savepoint_name= id )
            // sqljet/src/Sql.g:307:15: RELEASE ( SAVEPOINT )? savepoint_name= id
            {
            root_0 = (Object)adaptor.nil();

            RELEASE283=(Token)match(input,RELEASE,FOLLOW_RELEASE_in_release_stmt2565); 
            RELEASE283_tree = (Object)adaptor.create(RELEASE283);
            adaptor.addChild(root_0, RELEASE283_tree);

            // sqljet/src/Sql.g:307:23: ( SAVEPOINT )?
            int alt109=2;
            int LA109_0 = input.LA(1);

            if ( (LA109_0==SAVEPOINT) ) {
                int LA109_1 = input.LA(2);

                if ( ((LA109_1>=EXPLAIN && LA109_1<=PLAN)||(LA109_1>=INDEXED && LA109_1<=BY)||(LA109_1>=OR && LA109_1<=ESCAPE)||(LA109_1>=IS && LA109_1<=BETWEEN)||(LA109_1>=COLLATE && LA109_1<=THEN)||(LA109_1>=CURRENT_TIME && LA109_1<=CURRENT_TIMESTAMP)||(LA109_1>=RAISE && LA109_1<=ROW)) ) {
                    alt109=1;
                }
            }
            switch (alt109) {
                case 1 :
                    // sqljet/src/Sql.g:307:24: SAVEPOINT
                    {
                    SAVEPOINT284=(Token)match(input,SAVEPOINT,FOLLOW_SAVEPOINT_in_release_stmt2568); 
                    SAVEPOINT284_tree = (Object)adaptor.create(SAVEPOINT284);
                    adaptor.addChild(root_0, SAVEPOINT284_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_release_stmt2574);
            savepoint_name=id();

            state._fsp--;

            adaptor.addChild(root_0, savepoint_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "release_stmt"

    public static class table_conflict_clause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "table_conflict_clause"
    // sqljet/src/Sql.g:314:1: table_conflict_clause : ON CONFLICT ( ROLLBACK | ABORT | FAIL | IGNORE | REPLACE ) ;
    public final SqlParser.table_conflict_clause_return table_conflict_clause() throws RecognitionException {
        SqlParser.table_conflict_clause_return retval = new SqlParser.table_conflict_clause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ON285=null;
        Token CONFLICT286=null;
        Token set287=null;

        Object ON285_tree=null;
        Object CONFLICT286_tree=null;
        Object set287_tree=null;

        try {
            // sqljet/src/Sql.g:314:22: ( ON CONFLICT ( ROLLBACK | ABORT | FAIL | IGNORE | REPLACE ) )
            // sqljet/src/Sql.g:314:24: ON CONFLICT ( ROLLBACK | ABORT | FAIL | IGNORE | REPLACE )
            {
            root_0 = (Object)adaptor.nil();

            ON285=(Token)match(input,ON,FOLLOW_ON_in_table_conflict_clause2586); 
            CONFLICT286=(Token)match(input,CONFLICT,FOLLOW_CONFLICT_in_table_conflict_clause2589); 
            CONFLICT286_tree = (Object)adaptor.create(CONFLICT286);
            root_0 = (Object)adaptor.becomeRoot(CONFLICT286_tree, root_0);

            set287=(Token)input.LT(1);
            if ( (input.LA(1)>=IGNORE && input.LA(1)<=FAIL)||input.LA(1)==REPLACE ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set287));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "table_conflict_clause"

    public static class create_virtual_table_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "create_virtual_table_stmt"
    // sqljet/src/Sql.g:318:1: create_virtual_table_stmt : CREATE VIRTUAL TABLE (database_name= id DOT )? table_name= id USING module_name= id ( LPAREN column_def ( COMMA column_def )* RPAREN )? ;
    public final SqlParser.create_virtual_table_stmt_return create_virtual_table_stmt() throws RecognitionException {
        SqlParser.create_virtual_table_stmt_return retval = new SqlParser.create_virtual_table_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CREATE288=null;
        Token VIRTUAL289=null;
        Token TABLE290=null;
        Token DOT291=null;
        Token USING292=null;
        Token LPAREN293=null;
        Token COMMA295=null;
        Token RPAREN297=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.id_return module_name = null;

        SqlParser.column_def_return column_def294 = null;

        SqlParser.column_def_return column_def296 = null;


        Object CREATE288_tree=null;
        Object VIRTUAL289_tree=null;
        Object TABLE290_tree=null;
        Object DOT291_tree=null;
        Object USING292_tree=null;
        Object LPAREN293_tree=null;
        Object COMMA295_tree=null;
        Object RPAREN297_tree=null;

        try {
            // sqljet/src/Sql.g:318:26: ( CREATE VIRTUAL TABLE (database_name= id DOT )? table_name= id USING module_name= id ( LPAREN column_def ( COMMA column_def )* RPAREN )? )
            // sqljet/src/Sql.g:318:28: CREATE VIRTUAL TABLE (database_name= id DOT )? table_name= id USING module_name= id ( LPAREN column_def ( COMMA column_def )* RPAREN )?
            {
            root_0 = (Object)adaptor.nil();

            CREATE288=(Token)match(input,CREATE,FOLLOW_CREATE_in_create_virtual_table_stmt2619); 
            CREATE288_tree = (Object)adaptor.create(CREATE288);
            adaptor.addChild(root_0, CREATE288_tree);

            VIRTUAL289=(Token)match(input,VIRTUAL,FOLLOW_VIRTUAL_in_create_virtual_table_stmt2621); 
            VIRTUAL289_tree = (Object)adaptor.create(VIRTUAL289);
            adaptor.addChild(root_0, VIRTUAL289_tree);

            TABLE290=(Token)match(input,TABLE,FOLLOW_TABLE_in_create_virtual_table_stmt2623); 
            TABLE290_tree = (Object)adaptor.create(TABLE290);
            adaptor.addChild(root_0, TABLE290_tree);

            // sqljet/src/Sql.g:318:49: (database_name= id DOT )?
            int alt110=2;
            int LA110_0 = input.LA(1);

            if ( (LA110_0==ID) ) {
                int LA110_1 = input.LA(2);

                if ( (LA110_1==DOT) ) {
                    alt110=1;
                }
            }
            else if ( ((LA110_0>=EXPLAIN && LA110_0<=PLAN)||(LA110_0>=INDEXED && LA110_0<=BY)||(LA110_0>=OR && LA110_0<=ESCAPE)||(LA110_0>=IS && LA110_0<=BETWEEN)||LA110_0==COLLATE||(LA110_0>=DISTINCT && LA110_0<=THEN)||(LA110_0>=CURRENT_TIME && LA110_0<=CURRENT_TIMESTAMP)||(LA110_0>=RAISE && LA110_0<=ROW)) ) {
                int LA110_2 = input.LA(2);

                if ( (LA110_2==DOT) ) {
                    alt110=1;
                }
            }
            switch (alt110) {
                case 1 :
                    // sqljet/src/Sql.g:318:50: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_create_virtual_table_stmt2628);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT291=(Token)match(input,DOT,FOLLOW_DOT_in_create_virtual_table_stmt2630); 
                    DOT291_tree = (Object)adaptor.create(DOT291);
                    adaptor.addChild(root_0, DOT291_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_create_virtual_table_stmt2636);
            table_name=id();

            state._fsp--;

            adaptor.addChild(root_0, table_name.getTree());
            USING292=(Token)match(input,USING,FOLLOW_USING_in_create_virtual_table_stmt2640); 
            USING292_tree = (Object)adaptor.create(USING292);
            adaptor.addChild(root_0, USING292_tree);

            pushFollow(FOLLOW_id_in_create_virtual_table_stmt2644);
            module_name=id();

            state._fsp--;

            adaptor.addChild(root_0, module_name.getTree());
            // sqljet/src/Sql.g:319:24: ( LPAREN column_def ( COMMA column_def )* RPAREN )?
            int alt112=2;
            int LA112_0 = input.LA(1);

            if ( (LA112_0==LPAREN) ) {
                alt112=1;
            }
            switch (alt112) {
                case 1 :
                    // sqljet/src/Sql.g:319:25: LPAREN column_def ( COMMA column_def )* RPAREN
                    {
                    LPAREN293=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_create_virtual_table_stmt2647); 
                    LPAREN293_tree = (Object)adaptor.create(LPAREN293);
                    adaptor.addChild(root_0, LPAREN293_tree);

                    pushFollow(FOLLOW_column_def_in_create_virtual_table_stmt2649);
                    column_def294=column_def();

                    state._fsp--;

                    adaptor.addChild(root_0, column_def294.getTree());
                    // sqljet/src/Sql.g:319:43: ( COMMA column_def )*
                    loop111:
                    do {
                        int alt111=2;
                        int LA111_0 = input.LA(1);

                        if ( (LA111_0==COMMA) ) {
                            alt111=1;
                        }


                        switch (alt111) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:319:44: COMMA column_def
                    	    {
                    	    COMMA295=(Token)match(input,COMMA,FOLLOW_COMMA_in_create_virtual_table_stmt2652); 
                    	    COMMA295_tree = (Object)adaptor.create(COMMA295);
                    	    adaptor.addChild(root_0, COMMA295_tree);

                    	    pushFollow(FOLLOW_column_def_in_create_virtual_table_stmt2654);
                    	    column_def296=column_def();

                    	    state._fsp--;

                    	    adaptor.addChild(root_0, column_def296.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop111;
                        }
                    } while (true);

                    RPAREN297=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_create_virtual_table_stmt2658); 
                    RPAREN297_tree = (Object)adaptor.create(RPAREN297);
                    adaptor.addChild(root_0, RPAREN297_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "create_virtual_table_stmt"

    public static class create_table_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "create_table_stmt"
    // sqljet/src/Sql.g:322:1: create_table_stmt : CREATE ( TEMPORARY )? TABLE ( IF NOT EXISTS )? (database_name= id DOT )? table_name= id ( LPAREN column_def ( COMMA column_def )* ( COMMA table_constraint )* RPAREN | AS select_stmt ) -> ^( CREATE_TABLE ^( OPTIONS ( TEMPORARY )? ( EXISTS )? ) ^( $table_name ( $database_name)? ) ( ^( COLUMNS ( column_def )+ ) )? ( ^( CONSTRAINTS ( table_constraint )* ) )? ( select_stmt )? ) ;
    public final SqlParser.create_table_stmt_return create_table_stmt() throws RecognitionException {
        SqlParser.create_table_stmt_return retval = new SqlParser.create_table_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CREATE298=null;
        Token TEMPORARY299=null;
        Token TABLE300=null;
        Token IF301=null;
        Token NOT302=null;
        Token EXISTS303=null;
        Token DOT304=null;
        Token LPAREN305=null;
        Token COMMA307=null;
        Token COMMA309=null;
        Token RPAREN311=null;
        Token AS312=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.column_def_return column_def306 = null;

        SqlParser.column_def_return column_def308 = null;

        SqlParser.table_constraint_return table_constraint310 = null;

        SqlParser.select_stmt_return select_stmt313 = null;


        Object CREATE298_tree=null;
        Object TEMPORARY299_tree=null;
        Object TABLE300_tree=null;
        Object IF301_tree=null;
        Object NOT302_tree=null;
        Object EXISTS303_tree=null;
        Object DOT304_tree=null;
        Object LPAREN305_tree=null;
        Object COMMA307_tree=null;
        Object COMMA309_tree=null;
        Object RPAREN311_tree=null;
        Object AS312_tree=null;
        RewriteRuleTokenStream stream_EXISTS=new RewriteRuleTokenStream(adaptor,"token EXISTS");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_AS=new RewriteRuleTokenStream(adaptor,"token AS");
        RewriteRuleTokenStream stream_TABLE=new RewriteRuleTokenStream(adaptor,"token TABLE");
        RewriteRuleTokenStream stream_IF=new RewriteRuleTokenStream(adaptor,"token IF");
        RewriteRuleTokenStream stream_NOT=new RewriteRuleTokenStream(adaptor,"token NOT");
        RewriteRuleTokenStream stream_TEMPORARY=new RewriteRuleTokenStream(adaptor,"token TEMPORARY");
        RewriteRuleTokenStream stream_CREATE=new RewriteRuleTokenStream(adaptor,"token CREATE");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_column_def=new RewriteRuleSubtreeStream(adaptor,"rule column_def");
        RewriteRuleSubtreeStream stream_table_constraint=new RewriteRuleSubtreeStream(adaptor,"rule table_constraint");
        RewriteRuleSubtreeStream stream_select_stmt=new RewriteRuleSubtreeStream(adaptor,"rule select_stmt");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:322:18: ( CREATE ( TEMPORARY )? TABLE ( IF NOT EXISTS )? (database_name= id DOT )? table_name= id ( LPAREN column_def ( COMMA column_def )* ( COMMA table_constraint )* RPAREN | AS select_stmt ) -> ^( CREATE_TABLE ^( OPTIONS ( TEMPORARY )? ( EXISTS )? ) ^( $table_name ( $database_name)? ) ( ^( COLUMNS ( column_def )+ ) )? ( ^( CONSTRAINTS ( table_constraint )* ) )? ( select_stmt )? ) )
            // sqljet/src/Sql.g:322:20: CREATE ( TEMPORARY )? TABLE ( IF NOT EXISTS )? (database_name= id DOT )? table_name= id ( LPAREN column_def ( COMMA column_def )* ( COMMA table_constraint )* RPAREN | AS select_stmt )
            {
            CREATE298=(Token)match(input,CREATE,FOLLOW_CREATE_in_create_table_stmt2668);  
            stream_CREATE.add(CREATE298);

            // sqljet/src/Sql.g:322:27: ( TEMPORARY )?
            int alt113=2;
            int LA113_0 = input.LA(1);

            if ( (LA113_0==TEMPORARY) ) {
                alt113=1;
            }
            switch (alt113) {
                case 1 :
                    // sqljet/src/Sql.g:322:27: TEMPORARY
                    {
                    TEMPORARY299=(Token)match(input,TEMPORARY,FOLLOW_TEMPORARY_in_create_table_stmt2670);  
                    stream_TEMPORARY.add(TEMPORARY299);


                    }
                    break;

            }

            TABLE300=(Token)match(input,TABLE,FOLLOW_TABLE_in_create_table_stmt2673);  
            stream_TABLE.add(TABLE300);

            // sqljet/src/Sql.g:322:44: ( IF NOT EXISTS )?
            int alt114=2;
            int LA114_0 = input.LA(1);

            if ( (LA114_0==IF) ) {
                int LA114_1 = input.LA(2);

                if ( (LA114_1==NOT) ) {
                    alt114=1;
                }
            }
            switch (alt114) {
                case 1 :
                    // sqljet/src/Sql.g:322:45: IF NOT EXISTS
                    {
                    IF301=(Token)match(input,IF,FOLLOW_IF_in_create_table_stmt2676);  
                    stream_IF.add(IF301);

                    NOT302=(Token)match(input,NOT,FOLLOW_NOT_in_create_table_stmt2678);  
                    stream_NOT.add(NOT302);

                    EXISTS303=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_create_table_stmt2680);  
                    stream_EXISTS.add(EXISTS303);


                    }
                    break;

            }

            // sqljet/src/Sql.g:322:61: (database_name= id DOT )?
            int alt115=2;
            int LA115_0 = input.LA(1);

            if ( (LA115_0==ID) ) {
                int LA115_1 = input.LA(2);

                if ( (LA115_1==DOT) ) {
                    alt115=1;
                }
            }
            else if ( ((LA115_0>=EXPLAIN && LA115_0<=PLAN)||(LA115_0>=INDEXED && LA115_0<=BY)||(LA115_0>=OR && LA115_0<=ESCAPE)||(LA115_0>=IS && LA115_0<=BETWEEN)||LA115_0==COLLATE||(LA115_0>=DISTINCT && LA115_0<=THEN)||(LA115_0>=CURRENT_TIME && LA115_0<=CURRENT_TIMESTAMP)||(LA115_0>=RAISE && LA115_0<=ROW)) ) {
                int LA115_2 = input.LA(2);

                if ( (LA115_2==DOT) ) {
                    alt115=1;
                }
            }
            switch (alt115) {
                case 1 :
                    // sqljet/src/Sql.g:322:62: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_create_table_stmt2687);
                    database_name=id();

                    state._fsp--;

                    stream_id.add(database_name.getTree());
                    DOT304=(Token)match(input,DOT,FOLLOW_DOT_in_create_table_stmt2689);  
                    stream_DOT.add(DOT304);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_create_table_stmt2695);
            table_name=id();

            state._fsp--;

            stream_id.add(table_name.getTree());
            // sqljet/src/Sql.g:323:3: ( LPAREN column_def ( COMMA column_def )* ( COMMA table_constraint )* RPAREN | AS select_stmt )
            int alt118=2;
            int LA118_0 = input.LA(1);

            if ( (LA118_0==LPAREN) ) {
                alt118=1;
            }
            else if ( (LA118_0==AS) ) {
                alt118=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 118, 0, input);

                throw nvae;
            }
            switch (alt118) {
                case 1 :
                    // sqljet/src/Sql.g:323:5: LPAREN column_def ( COMMA column_def )* ( COMMA table_constraint )* RPAREN
                    {
                    LPAREN305=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_create_table_stmt2701);  
                    stream_LPAREN.add(LPAREN305);

                    pushFollow(FOLLOW_column_def_in_create_table_stmt2703);
                    column_def306=column_def();

                    state._fsp--;

                    stream_column_def.add(column_def306.getTree());
                    // sqljet/src/Sql.g:323:23: ( COMMA column_def )*
                    loop116:
                    do {
                        int alt116=2;
                        alt116 = dfa116.predict(input);
                        switch (alt116) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:323:24: COMMA column_def
                    	    {
                    	    COMMA307=(Token)match(input,COMMA,FOLLOW_COMMA_in_create_table_stmt2706);  
                    	    stream_COMMA.add(COMMA307);

                    	    pushFollow(FOLLOW_column_def_in_create_table_stmt2708);
                    	    column_def308=column_def();

                    	    state._fsp--;

                    	    stream_column_def.add(column_def308.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop116;
                        }
                    } while (true);

                    // sqljet/src/Sql.g:323:43: ( COMMA table_constraint )*
                    loop117:
                    do {
                        int alt117=2;
                        int LA117_0 = input.LA(1);

                        if ( (LA117_0==COMMA) ) {
                            alt117=1;
                        }


                        switch (alt117) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:323:44: COMMA table_constraint
                    	    {
                    	    COMMA309=(Token)match(input,COMMA,FOLLOW_COMMA_in_create_table_stmt2713);  
                    	    stream_COMMA.add(COMMA309);

                    	    pushFollow(FOLLOW_table_constraint_in_create_table_stmt2715);
                    	    table_constraint310=table_constraint();

                    	    state._fsp--;

                    	    stream_table_constraint.add(table_constraint310.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop117;
                        }
                    } while (true);

                    RPAREN311=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_create_table_stmt2719);  
                    stream_RPAREN.add(RPAREN311);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:324:5: AS select_stmt
                    {
                    AS312=(Token)match(input,AS,FOLLOW_AS_in_create_table_stmt2725);  
                    stream_AS.add(AS312);

                    pushFollow(FOLLOW_select_stmt_in_create_table_stmt2727);
                    select_stmt313=select_stmt();

                    state._fsp--;

                    stream_select_stmt.add(select_stmt313.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: EXISTS, table_name, TEMPORARY, select_stmt, table_constraint, column_def, database_name
            // token labels: 
            // rule labels: database_name, retval, table_name
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_table_name=new RewriteRuleSubtreeStream(adaptor,"rule table_name",table_name!=null?table_name.tree:null);

            root_0 = (Object)adaptor.nil();
            // 325:1: -> ^( CREATE_TABLE ^( OPTIONS ( TEMPORARY )? ( EXISTS )? ) ^( $table_name ( $database_name)? ) ( ^( COLUMNS ( column_def )+ ) )? ( ^( CONSTRAINTS ( table_constraint )* ) )? ( select_stmt )? )
            {
                // sqljet/src/Sql.g:325:4: ^( CREATE_TABLE ^( OPTIONS ( TEMPORARY )? ( EXISTS )? ) ^( $table_name ( $database_name)? ) ( ^( COLUMNS ( column_def )+ ) )? ( ^( CONSTRAINTS ( table_constraint )* ) )? ( select_stmt )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(CREATE_TABLE, "CREATE_TABLE"), root_1);

                // sqljet/src/Sql.g:325:19: ^( OPTIONS ( TEMPORARY )? ( EXISTS )? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(OPTIONS, "OPTIONS"), root_2);

                // sqljet/src/Sql.g:325:29: ( TEMPORARY )?
                if ( stream_TEMPORARY.hasNext() ) {
                    adaptor.addChild(root_2, stream_TEMPORARY.nextNode());

                }
                stream_TEMPORARY.reset();
                // sqljet/src/Sql.g:325:40: ( EXISTS )?
                if ( stream_EXISTS.hasNext() ) {
                    adaptor.addChild(root_2, stream_EXISTS.nextNode());

                }
                stream_EXISTS.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:325:49: ^( $table_name ( $database_name)? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot(stream_table_name.nextNode(), root_2);

                // sqljet/src/Sql.g:325:63: ( $database_name)?
                if ( stream_database_name.hasNext() ) {
                    adaptor.addChild(root_2, stream_database_name.nextTree());

                }
                stream_database_name.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:326:3: ( ^( COLUMNS ( column_def )+ ) )?
                if ( stream_column_def.hasNext() ) {
                    // sqljet/src/Sql.g:326:3: ^( COLUMNS ( column_def )+ )
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMNS, "COLUMNS"), root_2);

                    if ( !(stream_column_def.hasNext()) ) {
                        throw new RewriteEarlyExitException();
                    }
                    while ( stream_column_def.hasNext() ) {
                        adaptor.addChild(root_2, stream_column_def.nextTree());

                    }
                    stream_column_def.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_column_def.reset();
                // sqljet/src/Sql.g:326:27: ( ^( CONSTRAINTS ( table_constraint )* ) )?
                if ( stream_table_constraint.hasNext() ) {
                    // sqljet/src/Sql.g:326:27: ^( CONSTRAINTS ( table_constraint )* )
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(CONSTRAINTS, "CONSTRAINTS"), root_2);

                    // sqljet/src/Sql.g:326:41: ( table_constraint )*
                    while ( stream_table_constraint.hasNext() ) {
                        adaptor.addChild(root_2, stream_table_constraint.nextTree());

                    }
                    stream_table_constraint.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_table_constraint.reset();
                // sqljet/src/Sql.g:326:61: ( select_stmt )?
                if ( stream_select_stmt.hasNext() ) {
                    adaptor.addChild(root_1, stream_select_stmt.nextTree());

                }
                stream_select_stmt.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "create_table_stmt"

    public static class column_def_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_def"
    // sqljet/src/Sql.g:328:1: column_def : name= id_column_def ( type_name )? ( column_constraint )* -> ^( $name ^( CONSTRAINTS ( column_constraint )* ) ( type_name )? ) ;
    public final SqlParser.column_def_return column_def() throws RecognitionException {
        SqlParser.column_def_return retval = new SqlParser.column_def_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        SqlParser.id_column_def_return name = null;

        SqlParser.type_name_return type_name314 = null;

        SqlParser.column_constraint_return column_constraint315 = null;


        RewriteRuleSubtreeStream stream_type_name=new RewriteRuleSubtreeStream(adaptor,"rule type_name");
        RewriteRuleSubtreeStream stream_column_constraint=new RewriteRuleSubtreeStream(adaptor,"rule column_constraint");
        RewriteRuleSubtreeStream stream_id_column_def=new RewriteRuleSubtreeStream(adaptor,"rule id_column_def");
        try {
            // sqljet/src/Sql.g:328:11: (name= id_column_def ( type_name )? ( column_constraint )* -> ^( $name ^( CONSTRAINTS ( column_constraint )* ) ( type_name )? ) )
            // sqljet/src/Sql.g:328:13: name= id_column_def ( type_name )? ( column_constraint )*
            {
            pushFollow(FOLLOW_id_column_def_in_column_def2783);
            name=id_column_def();

            state._fsp--;

            stream_id_column_def.add(name.getTree());
            // sqljet/src/Sql.g:328:32: ( type_name )?
            int alt119=2;
            alt119 = dfa119.predict(input);
            switch (alt119) {
                case 1 :
                    // sqljet/src/Sql.g:328:32: type_name
                    {
                    pushFollow(FOLLOW_type_name_in_column_def2785);
                    type_name314=type_name();

                    state._fsp--;

                    stream_type_name.add(type_name314.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:328:43: ( column_constraint )*
            loop120:
            do {
                int alt120=2;
                alt120 = dfa120.predict(input);
                switch (alt120) {
            	case 1 :
            	    // sqljet/src/Sql.g:328:43: column_constraint
            	    {
            	    pushFollow(FOLLOW_column_constraint_in_column_def2788);
            	    column_constraint315=column_constraint();

            	    state._fsp--;

            	    stream_column_constraint.add(column_constraint315.getTree());

            	    }
            	    break;

            	default :
            	    break loop120;
                }
            } while (true);



            // AST REWRITE
            // elements: name, type_name, column_constraint
            // token labels: 
            // rule labels: retval, name
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name",name!=null?name.tree:null);

            root_0 = (Object)adaptor.nil();
            // 329:1: -> ^( $name ^( CONSTRAINTS ( column_constraint )* ) ( type_name )? )
            {
                // sqljet/src/Sql.g:329:4: ^( $name ^( CONSTRAINTS ( column_constraint )* ) ( type_name )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_name.nextNode(), root_1);

                // sqljet/src/Sql.g:329:12: ^( CONSTRAINTS ( column_constraint )* )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(CONSTRAINTS, "CONSTRAINTS"), root_2);

                // sqljet/src/Sql.g:329:26: ( column_constraint )*
                while ( stream_column_constraint.hasNext() ) {
                    adaptor.addChild(root_2, stream_column_constraint.nextTree());

                }
                stream_column_constraint.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:329:46: ( type_name )?
                if ( stream_type_name.hasNext() ) {
                    adaptor.addChild(root_1, stream_type_name.nextTree());

                }
                stream_type_name.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_def"

    public static class column_constraint_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_constraint"
    // sqljet/src/Sql.g:331:1: column_constraint : ( CONSTRAINT name= id )? ( column_constraint_pk | column_constraint_not_null | column_constraint_unique | column_constraint_check | column_constraint_default | column_constraint_collate | fk_clause ) -> ^( COLUMN_CONSTRAINT ( column_constraint_pk )? ( column_constraint_not_null )? ( column_constraint_unique )? ( column_constraint_check )? ( column_constraint_default )? ( column_constraint_collate )? ( fk_clause )? ( $name)? ) ;
    public final SqlParser.column_constraint_return column_constraint() throws RecognitionException {
        SqlParser.column_constraint_return retval = new SqlParser.column_constraint_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CONSTRAINT316=null;
        SqlParser.id_return name = null;

        SqlParser.column_constraint_pk_return column_constraint_pk317 = null;

        SqlParser.column_constraint_not_null_return column_constraint_not_null318 = null;

        SqlParser.column_constraint_unique_return column_constraint_unique319 = null;

        SqlParser.column_constraint_check_return column_constraint_check320 = null;

        SqlParser.column_constraint_default_return column_constraint_default321 = null;

        SqlParser.column_constraint_collate_return column_constraint_collate322 = null;

        SqlParser.fk_clause_return fk_clause323 = null;


        Object CONSTRAINT316_tree=null;
        RewriteRuleTokenStream stream_CONSTRAINT=new RewriteRuleTokenStream(adaptor,"token CONSTRAINT");
        RewriteRuleSubtreeStream stream_column_constraint_not_null=new RewriteRuleSubtreeStream(adaptor,"rule column_constraint_not_null");
        RewriteRuleSubtreeStream stream_column_constraint_unique=new RewriteRuleSubtreeStream(adaptor,"rule column_constraint_unique");
        RewriteRuleSubtreeStream stream_column_constraint_check=new RewriteRuleSubtreeStream(adaptor,"rule column_constraint_check");
        RewriteRuleSubtreeStream stream_fk_clause=new RewriteRuleSubtreeStream(adaptor,"rule fk_clause");
        RewriteRuleSubtreeStream stream_column_constraint_pk=new RewriteRuleSubtreeStream(adaptor,"rule column_constraint_pk");
        RewriteRuleSubtreeStream stream_column_constraint_collate=new RewriteRuleSubtreeStream(adaptor,"rule column_constraint_collate");
        RewriteRuleSubtreeStream stream_column_constraint_default=new RewriteRuleSubtreeStream(adaptor,"rule column_constraint_default");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:331:18: ( ( CONSTRAINT name= id )? ( column_constraint_pk | column_constraint_not_null | column_constraint_unique | column_constraint_check | column_constraint_default | column_constraint_collate | fk_clause ) -> ^( COLUMN_CONSTRAINT ( column_constraint_pk )? ( column_constraint_not_null )? ( column_constraint_unique )? ( column_constraint_check )? ( column_constraint_default )? ( column_constraint_collate )? ( fk_clause )? ( $name)? ) )
            // sqljet/src/Sql.g:331:20: ( CONSTRAINT name= id )? ( column_constraint_pk | column_constraint_not_null | column_constraint_unique | column_constraint_check | column_constraint_default | column_constraint_collate | fk_clause )
            {
            // sqljet/src/Sql.g:331:20: ( CONSTRAINT name= id )?
            int alt121=2;
            int LA121_0 = input.LA(1);

            if ( (LA121_0==CONSTRAINT) ) {
                alt121=1;
            }
            switch (alt121) {
                case 1 :
                    // sqljet/src/Sql.g:331:21: CONSTRAINT name= id
                    {
                    CONSTRAINT316=(Token)match(input,CONSTRAINT,FOLLOW_CONSTRAINT_in_column_constraint2814);  
                    stream_CONSTRAINT.add(CONSTRAINT316);

                    pushFollow(FOLLOW_id_in_column_constraint2818);
                    name=id();

                    state._fsp--;

                    stream_id.add(name.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:332:3: ( column_constraint_pk | column_constraint_not_null | column_constraint_unique | column_constraint_check | column_constraint_default | column_constraint_collate | fk_clause )
            int alt122=7;
            switch ( input.LA(1) ) {
            case PRIMARY:
                {
                alt122=1;
                }
                break;
            case NOT:
                {
                alt122=2;
                }
                break;
            case UNIQUE:
                {
                alt122=3;
                }
                break;
            case CHECK:
                {
                alt122=4;
                }
                break;
            case DEFAULT:
                {
                alt122=5;
                }
                break;
            case COLLATE:
                {
                alt122=6;
                }
                break;
            case REFERENCES:
                {
                alt122=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 122, 0, input);

                throw nvae;
            }

            switch (alt122) {
                case 1 :
                    // sqljet/src/Sql.g:332:5: column_constraint_pk
                    {
                    pushFollow(FOLLOW_column_constraint_pk_in_column_constraint2826);
                    column_constraint_pk317=column_constraint_pk();

                    state._fsp--;

                    stream_column_constraint_pk.add(column_constraint_pk317.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:333:5: column_constraint_not_null
                    {
                    pushFollow(FOLLOW_column_constraint_not_null_in_column_constraint2832);
                    column_constraint_not_null318=column_constraint_not_null();

                    state._fsp--;

                    stream_column_constraint_not_null.add(column_constraint_not_null318.getTree());

                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:334:5: column_constraint_unique
                    {
                    pushFollow(FOLLOW_column_constraint_unique_in_column_constraint2838);
                    column_constraint_unique319=column_constraint_unique();

                    state._fsp--;

                    stream_column_constraint_unique.add(column_constraint_unique319.getTree());

                    }
                    break;
                case 4 :
                    // sqljet/src/Sql.g:335:5: column_constraint_check
                    {
                    pushFollow(FOLLOW_column_constraint_check_in_column_constraint2844);
                    column_constraint_check320=column_constraint_check();

                    state._fsp--;

                    stream_column_constraint_check.add(column_constraint_check320.getTree());

                    }
                    break;
                case 5 :
                    // sqljet/src/Sql.g:336:5: column_constraint_default
                    {
                    pushFollow(FOLLOW_column_constraint_default_in_column_constraint2850);
                    column_constraint_default321=column_constraint_default();

                    state._fsp--;

                    stream_column_constraint_default.add(column_constraint_default321.getTree());

                    }
                    break;
                case 6 :
                    // sqljet/src/Sql.g:337:5: column_constraint_collate
                    {
                    pushFollow(FOLLOW_column_constraint_collate_in_column_constraint2856);
                    column_constraint_collate322=column_constraint_collate();

                    state._fsp--;

                    stream_column_constraint_collate.add(column_constraint_collate322.getTree());

                    }
                    break;
                case 7 :
                    // sqljet/src/Sql.g:338:5: fk_clause
                    {
                    pushFollow(FOLLOW_fk_clause_in_column_constraint2862);
                    fk_clause323=fk_clause();

                    state._fsp--;

                    stream_fk_clause.add(fk_clause323.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: column_constraint_pk, column_constraint_not_null, column_constraint_collate, column_constraint_default, column_constraint_unique, name, column_constraint_check, fk_clause
            // token labels: 
            // rule labels: retval, name
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name",name!=null?name.tree:null);

            root_0 = (Object)adaptor.nil();
            // 339:1: -> ^( COLUMN_CONSTRAINT ( column_constraint_pk )? ( column_constraint_not_null )? ( column_constraint_unique )? ( column_constraint_check )? ( column_constraint_default )? ( column_constraint_collate )? ( fk_clause )? ( $name)? )
            {
                // sqljet/src/Sql.g:339:4: ^( COLUMN_CONSTRAINT ( column_constraint_pk )? ( column_constraint_not_null )? ( column_constraint_unique )? ( column_constraint_check )? ( column_constraint_default )? ( column_constraint_collate )? ( fk_clause )? ( $name)? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMN_CONSTRAINT, "COLUMN_CONSTRAINT"), root_1);

                // sqljet/src/Sql.g:340:3: ( column_constraint_pk )?
                if ( stream_column_constraint_pk.hasNext() ) {
                    adaptor.addChild(root_1, stream_column_constraint_pk.nextTree());

                }
                stream_column_constraint_pk.reset();
                // sqljet/src/Sql.g:341:3: ( column_constraint_not_null )?
                if ( stream_column_constraint_not_null.hasNext() ) {
                    adaptor.addChild(root_1, stream_column_constraint_not_null.nextTree());

                }
                stream_column_constraint_not_null.reset();
                // sqljet/src/Sql.g:342:3: ( column_constraint_unique )?
                if ( stream_column_constraint_unique.hasNext() ) {
                    adaptor.addChild(root_1, stream_column_constraint_unique.nextTree());

                }
                stream_column_constraint_unique.reset();
                // sqljet/src/Sql.g:343:3: ( column_constraint_check )?
                if ( stream_column_constraint_check.hasNext() ) {
                    adaptor.addChild(root_1, stream_column_constraint_check.nextTree());

                }
                stream_column_constraint_check.reset();
                // sqljet/src/Sql.g:344:3: ( column_constraint_default )?
                if ( stream_column_constraint_default.hasNext() ) {
                    adaptor.addChild(root_1, stream_column_constraint_default.nextTree());

                }
                stream_column_constraint_default.reset();
                // sqljet/src/Sql.g:345:3: ( column_constraint_collate )?
                if ( stream_column_constraint_collate.hasNext() ) {
                    adaptor.addChild(root_1, stream_column_constraint_collate.nextTree());

                }
                stream_column_constraint_collate.reset();
                // sqljet/src/Sql.g:346:3: ( fk_clause )?
                if ( stream_fk_clause.hasNext() ) {
                    adaptor.addChild(root_1, stream_fk_clause.nextTree());

                }
                stream_fk_clause.reset();
                // sqljet/src/Sql.g:347:3: ( $name)?
                if ( stream_name.hasNext() ) {
                    adaptor.addChild(root_1, stream_name.nextTree());

                }
                stream_name.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_constraint"

    public static class column_constraint_pk_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_constraint_pk"
    // sqljet/src/Sql.g:349:1: column_constraint_pk : PRIMARY KEY ( ASC | DESC )? ( table_conflict_clause )? ( AUTOINCREMENT )? ;
    public final SqlParser.column_constraint_pk_return column_constraint_pk() throws RecognitionException {
        SqlParser.column_constraint_pk_return retval = new SqlParser.column_constraint_pk_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PRIMARY324=null;
        Token KEY325=null;
        Token set326=null;
        Token AUTOINCREMENT328=null;
        SqlParser.table_conflict_clause_return table_conflict_clause327 = null;


        Object PRIMARY324_tree=null;
        Object KEY325_tree=null;
        Object set326_tree=null;
        Object AUTOINCREMENT328_tree=null;

        try {
            // sqljet/src/Sql.g:349:21: ( PRIMARY KEY ( ASC | DESC )? ( table_conflict_clause )? ( AUTOINCREMENT )? )
            // sqljet/src/Sql.g:349:23: PRIMARY KEY ( ASC | DESC )? ( table_conflict_clause )? ( AUTOINCREMENT )?
            {
            root_0 = (Object)adaptor.nil();

            PRIMARY324=(Token)match(input,PRIMARY,FOLLOW_PRIMARY_in_column_constraint_pk2917); 
            PRIMARY324_tree = (Object)adaptor.create(PRIMARY324);
            root_0 = (Object)adaptor.becomeRoot(PRIMARY324_tree, root_0);

            KEY325=(Token)match(input,KEY,FOLLOW_KEY_in_column_constraint_pk2920); 
            // sqljet/src/Sql.g:349:37: ( ASC | DESC )?
            int alt123=2;
            alt123 = dfa123.predict(input);
            switch (alt123) {
                case 1 :
                    // sqljet/src/Sql.g:
                    {
                    set326=(Token)input.LT(1);
                    if ( (input.LA(1)>=ASC && input.LA(1)<=DESC) ) {
                        input.consume();
                        adaptor.addChild(root_0, (Object)adaptor.create(set326));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            // sqljet/src/Sql.g:349:51: ( table_conflict_clause )?
            int alt124=2;
            alt124 = dfa124.predict(input);
            switch (alt124) {
                case 1 :
                    // sqljet/src/Sql.g:349:51: table_conflict_clause
                    {
                    pushFollow(FOLLOW_table_conflict_clause_in_column_constraint_pk2932);
                    table_conflict_clause327=table_conflict_clause();

                    state._fsp--;

                    adaptor.addChild(root_0, table_conflict_clause327.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:349:74: ( AUTOINCREMENT )?
            int alt125=2;
            alt125 = dfa125.predict(input);
            switch (alt125) {
                case 1 :
                    // sqljet/src/Sql.g:349:75: AUTOINCREMENT
                    {
                    AUTOINCREMENT328=(Token)match(input,AUTOINCREMENT,FOLLOW_AUTOINCREMENT_in_column_constraint_pk2936); 
                    AUTOINCREMENT328_tree = (Object)adaptor.create(AUTOINCREMENT328);
                    adaptor.addChild(root_0, AUTOINCREMENT328_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_constraint_pk"

    public static class column_constraint_not_null_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_constraint_not_null"
    // sqljet/src/Sql.g:351:1: column_constraint_not_null : NOT NULL ( table_conflict_clause )? -> ^( NOT_NULL ( table_conflict_clause )? ) ;
    public final SqlParser.column_constraint_not_null_return column_constraint_not_null() throws RecognitionException {
        SqlParser.column_constraint_not_null_return retval = new SqlParser.column_constraint_not_null_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token NOT329=null;
        Token NULL330=null;
        SqlParser.table_conflict_clause_return table_conflict_clause331 = null;


        Object NOT329_tree=null;
        Object NULL330_tree=null;
        RewriteRuleTokenStream stream_NOT=new RewriteRuleTokenStream(adaptor,"token NOT");
        RewriteRuleTokenStream stream_NULL=new RewriteRuleTokenStream(adaptor,"token NULL");
        RewriteRuleSubtreeStream stream_table_conflict_clause=new RewriteRuleSubtreeStream(adaptor,"rule table_conflict_clause");
        try {
            // sqljet/src/Sql.g:351:27: ( NOT NULL ( table_conflict_clause )? -> ^( NOT_NULL ( table_conflict_clause )? ) )
            // sqljet/src/Sql.g:351:29: NOT NULL ( table_conflict_clause )?
            {
            NOT329=(Token)match(input,NOT,FOLLOW_NOT_in_column_constraint_not_null2945);  
            stream_NOT.add(NOT329);

            NULL330=(Token)match(input,NULL,FOLLOW_NULL_in_column_constraint_not_null2947);  
            stream_NULL.add(NULL330);

            // sqljet/src/Sql.g:351:38: ( table_conflict_clause )?
            int alt126=2;
            alt126 = dfa126.predict(input);
            switch (alt126) {
                case 1 :
                    // sqljet/src/Sql.g:351:38: table_conflict_clause
                    {
                    pushFollow(FOLLOW_table_conflict_clause_in_column_constraint_not_null2949);
                    table_conflict_clause331=table_conflict_clause();

                    state._fsp--;

                    stream_table_conflict_clause.add(table_conflict_clause331.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: table_conflict_clause
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 351:61: -> ^( NOT_NULL ( table_conflict_clause )? )
            {
                // sqljet/src/Sql.g:351:64: ^( NOT_NULL ( table_conflict_clause )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(NOT_NULL, "NOT_NULL"), root_1);

                // sqljet/src/Sql.g:351:75: ( table_conflict_clause )?
                if ( stream_table_conflict_clause.hasNext() ) {
                    adaptor.addChild(root_1, stream_table_conflict_clause.nextTree());

                }
                stream_table_conflict_clause.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_constraint_not_null"

    public static class column_constraint_unique_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_constraint_unique"
    // sqljet/src/Sql.g:353:1: column_constraint_unique : UNIQUE ( table_conflict_clause )? ;
    public final SqlParser.column_constraint_unique_return column_constraint_unique() throws RecognitionException {
        SqlParser.column_constraint_unique_return retval = new SqlParser.column_constraint_unique_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token UNIQUE332=null;
        SqlParser.table_conflict_clause_return table_conflict_clause333 = null;


        Object UNIQUE332_tree=null;

        try {
            // sqljet/src/Sql.g:353:25: ( UNIQUE ( table_conflict_clause )? )
            // sqljet/src/Sql.g:353:27: UNIQUE ( table_conflict_clause )?
            {
            root_0 = (Object)adaptor.nil();

            UNIQUE332=(Token)match(input,UNIQUE,FOLLOW_UNIQUE_in_column_constraint_unique2966); 
            UNIQUE332_tree = (Object)adaptor.create(UNIQUE332);
            root_0 = (Object)adaptor.becomeRoot(UNIQUE332_tree, root_0);

            // sqljet/src/Sql.g:353:35: ( table_conflict_clause )?
            int alt127=2;
            alt127 = dfa127.predict(input);
            switch (alt127) {
                case 1 :
                    // sqljet/src/Sql.g:353:35: table_conflict_clause
                    {
                    pushFollow(FOLLOW_table_conflict_clause_in_column_constraint_unique2969);
                    table_conflict_clause333=table_conflict_clause();

                    state._fsp--;

                    adaptor.addChild(root_0, table_conflict_clause333.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_constraint_unique"

    public static class column_constraint_check_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_constraint_check"
    // sqljet/src/Sql.g:355:1: column_constraint_check : CHECK LPAREN expr RPAREN ;
    public final SqlParser.column_constraint_check_return column_constraint_check() throws RecognitionException {
        SqlParser.column_constraint_check_return retval = new SqlParser.column_constraint_check_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CHECK334=null;
        Token LPAREN335=null;
        Token RPAREN337=null;
        SqlParser.expr_return expr336 = null;


        Object CHECK334_tree=null;
        Object LPAREN335_tree=null;
        Object RPAREN337_tree=null;

        try {
            // sqljet/src/Sql.g:355:24: ( CHECK LPAREN expr RPAREN )
            // sqljet/src/Sql.g:355:26: CHECK LPAREN expr RPAREN
            {
            root_0 = (Object)adaptor.nil();

            CHECK334=(Token)match(input,CHECK,FOLLOW_CHECK_in_column_constraint_check2977); 
            CHECK334_tree = (Object)adaptor.create(CHECK334);
            root_0 = (Object)adaptor.becomeRoot(CHECK334_tree, root_0);

            LPAREN335=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_column_constraint_check2980); 
            pushFollow(FOLLOW_expr_in_column_constraint_check2983);
            expr336=expr();

            state._fsp--;

            adaptor.addChild(root_0, expr336.getTree());
            RPAREN337=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_column_constraint_check2985); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_constraint_check"

    public static class numeric_literal_value_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "numeric_literal_value"
    // sqljet/src/Sql.g:357:1: numeric_literal_value : ( INTEGER -> ^( INTEGER_LITERAL INTEGER ) | FLOAT -> ^( FLOAT_LITERAL FLOAT ) );
    public final SqlParser.numeric_literal_value_return numeric_literal_value() throws RecognitionException {
        SqlParser.numeric_literal_value_return retval = new SqlParser.numeric_literal_value_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token INTEGER338=null;
        Token FLOAT339=null;

        Object INTEGER338_tree=null;
        Object FLOAT339_tree=null;
        RewriteRuleTokenStream stream_INTEGER=new RewriteRuleTokenStream(adaptor,"token INTEGER");
        RewriteRuleTokenStream stream_FLOAT=new RewriteRuleTokenStream(adaptor,"token FLOAT");

        try {
            // sqljet/src/Sql.g:358:3: ( INTEGER -> ^( INTEGER_LITERAL INTEGER ) | FLOAT -> ^( FLOAT_LITERAL FLOAT ) )
            int alt128=2;
            int LA128_0 = input.LA(1);

            if ( (LA128_0==INTEGER) ) {
                alt128=1;
            }
            else if ( (LA128_0==FLOAT) ) {
                alt128=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 128, 0, input);

                throw nvae;
            }
            switch (alt128) {
                case 1 :
                    // sqljet/src/Sql.g:358:5: INTEGER
                    {
                    INTEGER338=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_numeric_literal_value2996);  
                    stream_INTEGER.add(INTEGER338);



                    // AST REWRITE
                    // elements: INTEGER
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 358:13: -> ^( INTEGER_LITERAL INTEGER )
                    {
                        // sqljet/src/Sql.g:358:16: ^( INTEGER_LITERAL INTEGER )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(INTEGER_LITERAL, "INTEGER_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_INTEGER.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:359:5: FLOAT
                    {
                    FLOAT339=(Token)match(input,FLOAT,FOLLOW_FLOAT_in_numeric_literal_value3010);  
                    stream_FLOAT.add(FLOAT339);



                    // AST REWRITE
                    // elements: FLOAT
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 359:11: -> ^( FLOAT_LITERAL FLOAT )
                    {
                        // sqljet/src/Sql.g:359:14: ^( FLOAT_LITERAL FLOAT )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(FLOAT_LITERAL, "FLOAT_LITERAL"), root_1);

                        adaptor.addChild(root_1, stream_FLOAT.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "numeric_literal_value"

    public static class signed_default_number_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "signed_default_number"
    // sqljet/src/Sql.g:362:1: signed_default_number : ( PLUS | MINUS ) numeric_literal_value ;
    public final SqlParser.signed_default_number_return signed_default_number() throws RecognitionException {
        SqlParser.signed_default_number_return retval = new SqlParser.signed_default_number_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set340=null;
        SqlParser.numeric_literal_value_return numeric_literal_value341 = null;


        Object set340_tree=null;

        try {
            // sqljet/src/Sql.g:362:22: ( ( PLUS | MINUS ) numeric_literal_value )
            // sqljet/src/Sql.g:362:24: ( PLUS | MINUS ) numeric_literal_value
            {
            root_0 = (Object)adaptor.nil();

            set340=(Token)input.LT(1);
            set340=(Token)input.LT(1);
            if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
                input.consume();
                root_0 = (Object)adaptor.becomeRoot((Object)adaptor.create(set340), root_0);
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            pushFollow(FOLLOW_numeric_literal_value_in_signed_default_number3037);
            numeric_literal_value341=numeric_literal_value();

            state._fsp--;

            adaptor.addChild(root_0, numeric_literal_value341.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "signed_default_number"

    public static class column_constraint_default_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_constraint_default"
    // sqljet/src/Sql.g:365:1: column_constraint_default : DEFAULT ( signed_default_number | literal_value | LPAREN expr RPAREN ) ;
    public final SqlParser.column_constraint_default_return column_constraint_default() throws RecognitionException {
        SqlParser.column_constraint_default_return retval = new SqlParser.column_constraint_default_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DEFAULT342=null;
        Token LPAREN345=null;
        Token RPAREN347=null;
        SqlParser.signed_default_number_return signed_default_number343 = null;

        SqlParser.literal_value_return literal_value344 = null;

        SqlParser.expr_return expr346 = null;


        Object DEFAULT342_tree=null;
        Object LPAREN345_tree=null;
        Object RPAREN347_tree=null;

        try {
            // sqljet/src/Sql.g:365:26: ( DEFAULT ( signed_default_number | literal_value | LPAREN expr RPAREN ) )
            // sqljet/src/Sql.g:365:28: DEFAULT ( signed_default_number | literal_value | LPAREN expr RPAREN )
            {
            root_0 = (Object)adaptor.nil();

            DEFAULT342=(Token)match(input,DEFAULT,FOLLOW_DEFAULT_in_column_constraint_default3045); 
            DEFAULT342_tree = (Object)adaptor.create(DEFAULT342);
            root_0 = (Object)adaptor.becomeRoot(DEFAULT342_tree, root_0);

            // sqljet/src/Sql.g:365:37: ( signed_default_number | literal_value | LPAREN expr RPAREN )
            int alt129=3;
            alt129 = dfa129.predict(input);
            switch (alt129) {
                case 1 :
                    // sqljet/src/Sql.g:365:38: signed_default_number
                    {
                    pushFollow(FOLLOW_signed_default_number_in_column_constraint_default3049);
                    signed_default_number343=signed_default_number();

                    state._fsp--;

                    adaptor.addChild(root_0, signed_default_number343.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:365:62: literal_value
                    {
                    pushFollow(FOLLOW_literal_value_in_column_constraint_default3053);
                    literal_value344=literal_value();

                    state._fsp--;

                    adaptor.addChild(root_0, literal_value344.getTree());

                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:365:78: LPAREN expr RPAREN
                    {
                    LPAREN345=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_column_constraint_default3057); 
                    pushFollow(FOLLOW_expr_in_column_constraint_default3060);
                    expr346=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr346.getTree());
                    RPAREN347=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_column_constraint_default3062); 

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_constraint_default"

    public static class column_constraint_collate_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "column_constraint_collate"
    // sqljet/src/Sql.g:367:1: column_constraint_collate : COLLATE collation_name= id ;
    public final SqlParser.column_constraint_collate_return column_constraint_collate() throws RecognitionException {
        SqlParser.column_constraint_collate_return retval = new SqlParser.column_constraint_collate_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token COLLATE348=null;
        SqlParser.id_return collation_name = null;


        Object COLLATE348_tree=null;

        try {
            // sqljet/src/Sql.g:367:26: ( COLLATE collation_name= id )
            // sqljet/src/Sql.g:367:28: COLLATE collation_name= id
            {
            root_0 = (Object)adaptor.nil();

            COLLATE348=(Token)match(input,COLLATE,FOLLOW_COLLATE_in_column_constraint_collate3071); 
            COLLATE348_tree = (Object)adaptor.create(COLLATE348);
            root_0 = (Object)adaptor.becomeRoot(COLLATE348_tree, root_0);

            pushFollow(FOLLOW_id_in_column_constraint_collate3076);
            collation_name=id();

            state._fsp--;

            adaptor.addChild(root_0, collation_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "column_constraint_collate"

    public static class table_constraint_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "table_constraint"
    // sqljet/src/Sql.g:369:1: table_constraint : ( CONSTRAINT name= id )? ( table_constraint_pk | table_constraint_unique | table_constraint_check | table_constraint_fk ) -> ^( TABLE_CONSTRAINT ( table_constraint_pk )? ( table_constraint_unique )? ( table_constraint_check )? ( table_constraint_fk )? ( $name)? ) ;
    public final SqlParser.table_constraint_return table_constraint() throws RecognitionException {
        SqlParser.table_constraint_return retval = new SqlParser.table_constraint_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CONSTRAINT349=null;
        SqlParser.id_return name = null;

        SqlParser.table_constraint_pk_return table_constraint_pk350 = null;

        SqlParser.table_constraint_unique_return table_constraint_unique351 = null;

        SqlParser.table_constraint_check_return table_constraint_check352 = null;

        SqlParser.table_constraint_fk_return table_constraint_fk353 = null;


        Object CONSTRAINT349_tree=null;
        RewriteRuleTokenStream stream_CONSTRAINT=new RewriteRuleTokenStream(adaptor,"token CONSTRAINT");
        RewriteRuleSubtreeStream stream_table_constraint_pk=new RewriteRuleSubtreeStream(adaptor,"rule table_constraint_pk");
        RewriteRuleSubtreeStream stream_table_constraint_fk=new RewriteRuleSubtreeStream(adaptor,"rule table_constraint_fk");
        RewriteRuleSubtreeStream stream_table_constraint_check=new RewriteRuleSubtreeStream(adaptor,"rule table_constraint_check");
        RewriteRuleSubtreeStream stream_table_constraint_unique=new RewriteRuleSubtreeStream(adaptor,"rule table_constraint_unique");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:369:17: ( ( CONSTRAINT name= id )? ( table_constraint_pk | table_constraint_unique | table_constraint_check | table_constraint_fk ) -> ^( TABLE_CONSTRAINT ( table_constraint_pk )? ( table_constraint_unique )? ( table_constraint_check )? ( table_constraint_fk )? ( $name)? ) )
            // sqljet/src/Sql.g:369:19: ( CONSTRAINT name= id )? ( table_constraint_pk | table_constraint_unique | table_constraint_check | table_constraint_fk )
            {
            // sqljet/src/Sql.g:369:19: ( CONSTRAINT name= id )?
            int alt130=2;
            int LA130_0 = input.LA(1);

            if ( (LA130_0==CONSTRAINT) ) {
                alt130=1;
            }
            switch (alt130) {
                case 1 :
                    // sqljet/src/Sql.g:369:20: CONSTRAINT name= id
                    {
                    CONSTRAINT349=(Token)match(input,CONSTRAINT,FOLLOW_CONSTRAINT_in_table_constraint3085);  
                    stream_CONSTRAINT.add(CONSTRAINT349);

                    pushFollow(FOLLOW_id_in_table_constraint3089);
                    name=id();

                    state._fsp--;

                    stream_id.add(name.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:370:3: ( table_constraint_pk | table_constraint_unique | table_constraint_check | table_constraint_fk )
            int alt131=4;
            switch ( input.LA(1) ) {
            case PRIMARY:
                {
                alt131=1;
                }
                break;
            case UNIQUE:
                {
                alt131=2;
                }
                break;
            case CHECK:
                {
                alt131=3;
                }
                break;
            case FOREIGN:
                {
                alt131=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 131, 0, input);

                throw nvae;
            }

            switch (alt131) {
                case 1 :
                    // sqljet/src/Sql.g:370:5: table_constraint_pk
                    {
                    pushFollow(FOLLOW_table_constraint_pk_in_table_constraint3097);
                    table_constraint_pk350=table_constraint_pk();

                    state._fsp--;

                    stream_table_constraint_pk.add(table_constraint_pk350.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:371:5: table_constraint_unique
                    {
                    pushFollow(FOLLOW_table_constraint_unique_in_table_constraint3103);
                    table_constraint_unique351=table_constraint_unique();

                    state._fsp--;

                    stream_table_constraint_unique.add(table_constraint_unique351.getTree());

                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:372:5: table_constraint_check
                    {
                    pushFollow(FOLLOW_table_constraint_check_in_table_constraint3109);
                    table_constraint_check352=table_constraint_check();

                    state._fsp--;

                    stream_table_constraint_check.add(table_constraint_check352.getTree());

                    }
                    break;
                case 4 :
                    // sqljet/src/Sql.g:373:5: table_constraint_fk
                    {
                    pushFollow(FOLLOW_table_constraint_fk_in_table_constraint3115);
                    table_constraint_fk353=table_constraint_fk();

                    state._fsp--;

                    stream_table_constraint_fk.add(table_constraint_fk353.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: name, table_constraint_unique, table_constraint_fk, table_constraint_check, table_constraint_pk
            // token labels: 
            // rule labels: retval, name
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name",name!=null?name.tree:null);

            root_0 = (Object)adaptor.nil();
            // 374:1: -> ^( TABLE_CONSTRAINT ( table_constraint_pk )? ( table_constraint_unique )? ( table_constraint_check )? ( table_constraint_fk )? ( $name)? )
            {
                // sqljet/src/Sql.g:374:4: ^( TABLE_CONSTRAINT ( table_constraint_pk )? ( table_constraint_unique )? ( table_constraint_check )? ( table_constraint_fk )? ( $name)? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(TABLE_CONSTRAINT, "TABLE_CONSTRAINT"), root_1);

                // sqljet/src/Sql.g:375:3: ( table_constraint_pk )?
                if ( stream_table_constraint_pk.hasNext() ) {
                    adaptor.addChild(root_1, stream_table_constraint_pk.nextTree());

                }
                stream_table_constraint_pk.reset();
                // sqljet/src/Sql.g:376:3: ( table_constraint_unique )?
                if ( stream_table_constraint_unique.hasNext() ) {
                    adaptor.addChild(root_1, stream_table_constraint_unique.nextTree());

                }
                stream_table_constraint_unique.reset();
                // sqljet/src/Sql.g:377:3: ( table_constraint_check )?
                if ( stream_table_constraint_check.hasNext() ) {
                    adaptor.addChild(root_1, stream_table_constraint_check.nextTree());

                }
                stream_table_constraint_check.reset();
                // sqljet/src/Sql.g:378:3: ( table_constraint_fk )?
                if ( stream_table_constraint_fk.hasNext() ) {
                    adaptor.addChild(root_1, stream_table_constraint_fk.nextTree());

                }
                stream_table_constraint_fk.reset();
                // sqljet/src/Sql.g:379:3: ( $name)?
                if ( stream_name.hasNext() ) {
                    adaptor.addChild(root_1, stream_name.nextTree());

                }
                stream_name.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "table_constraint"

    public static class table_constraint_pk_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "table_constraint_pk"
    // sqljet/src/Sql.g:381:1: table_constraint_pk : PRIMARY KEY LPAREN indexed_columns+= id ( COMMA indexed_columns+= id )* RPAREN ( table_conflict_clause )? -> ^( PRIMARY ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? ) ;
    public final SqlParser.table_constraint_pk_return table_constraint_pk() throws RecognitionException {
        SqlParser.table_constraint_pk_return retval = new SqlParser.table_constraint_pk_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PRIMARY354=null;
        Token KEY355=null;
        Token LPAREN356=null;
        Token COMMA357=null;
        Token RPAREN358=null;
        List list_indexed_columns=null;
        SqlParser.table_conflict_clause_return table_conflict_clause359 = null;

        SqlParser.id_return indexed_columns = null;
         indexed_columns = null;
        Object PRIMARY354_tree=null;
        Object KEY355_tree=null;
        Object LPAREN356_tree=null;
        Object COMMA357_tree=null;
        Object RPAREN358_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_PRIMARY=new RewriteRuleTokenStream(adaptor,"token PRIMARY");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_KEY=new RewriteRuleTokenStream(adaptor,"token KEY");
        RewriteRuleSubtreeStream stream_table_conflict_clause=new RewriteRuleSubtreeStream(adaptor,"rule table_conflict_clause");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:381:20: ( PRIMARY KEY LPAREN indexed_columns+= id ( COMMA indexed_columns+= id )* RPAREN ( table_conflict_clause )? -> ^( PRIMARY ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? ) )
            // sqljet/src/Sql.g:381:22: PRIMARY KEY LPAREN indexed_columns+= id ( COMMA indexed_columns+= id )* RPAREN ( table_conflict_clause )?
            {
            PRIMARY354=(Token)match(input,PRIMARY,FOLLOW_PRIMARY_in_table_constraint_pk3155);  
            stream_PRIMARY.add(PRIMARY354);

            KEY355=(Token)match(input,KEY,FOLLOW_KEY_in_table_constraint_pk3157);  
            stream_KEY.add(KEY355);

            LPAREN356=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_table_constraint_pk3161);  
            stream_LPAREN.add(LPAREN356);

            pushFollow(FOLLOW_id_in_table_constraint_pk3165);
            indexed_columns=id();

            state._fsp--;

            stream_id.add(indexed_columns.getTree());
            if (list_indexed_columns==null) list_indexed_columns=new ArrayList();
            list_indexed_columns.add(indexed_columns.getTree());

            // sqljet/src/Sql.g:382:30: ( COMMA indexed_columns+= id )*
            loop132:
            do {
                int alt132=2;
                int LA132_0 = input.LA(1);

                if ( (LA132_0==COMMA) ) {
                    alt132=1;
                }


                switch (alt132) {
            	case 1 :
            	    // sqljet/src/Sql.g:382:31: COMMA indexed_columns+= id
            	    {
            	    COMMA357=(Token)match(input,COMMA,FOLLOW_COMMA_in_table_constraint_pk3168);  
            	    stream_COMMA.add(COMMA357);

            	    pushFollow(FOLLOW_id_in_table_constraint_pk3172);
            	    indexed_columns=id();

            	    state._fsp--;

            	    stream_id.add(indexed_columns.getTree());
            	    if (list_indexed_columns==null) list_indexed_columns=new ArrayList();
            	    list_indexed_columns.add(indexed_columns.getTree());


            	    }
            	    break;

            	default :
            	    break loop132;
                }
            } while (true);

            RPAREN358=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_table_constraint_pk3176);  
            stream_RPAREN.add(RPAREN358);

            // sqljet/src/Sql.g:382:66: ( table_conflict_clause )?
            int alt133=2;
            int LA133_0 = input.LA(1);

            if ( (LA133_0==ON) ) {
                alt133=1;
            }
            switch (alt133) {
                case 1 :
                    // sqljet/src/Sql.g:382:66: table_conflict_clause
                    {
                    pushFollow(FOLLOW_table_conflict_clause_in_table_constraint_pk3178);
                    table_conflict_clause359=table_conflict_clause();

                    state._fsp--;

                    stream_table_conflict_clause.add(table_conflict_clause359.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: PRIMARY, table_conflict_clause, indexed_columns
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: indexed_columns
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_indexed_columns=new RewriteRuleSubtreeStream(adaptor,"token indexed_columns",list_indexed_columns);
            root_0 = (Object)adaptor.nil();
            // 383:1: -> ^( PRIMARY ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? )
            {
                // sqljet/src/Sql.g:383:4: ^( PRIMARY ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_PRIMARY.nextNode(), root_1);

                // sqljet/src/Sql.g:383:14: ^( COLUMNS ( $indexed_columns)+ )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMNS, "COLUMNS"), root_2);

                if ( !(stream_indexed_columns.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_indexed_columns.hasNext() ) {
                    adaptor.addChild(root_2, stream_indexed_columns.nextTree());

                }
                stream_indexed_columns.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:383:43: ( table_conflict_clause )?
                if ( stream_table_conflict_clause.hasNext() ) {
                    adaptor.addChild(root_1, stream_table_conflict_clause.nextTree());

                }
                stream_table_conflict_clause.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "table_constraint_pk"

    public static class table_constraint_unique_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "table_constraint_unique"
    // sqljet/src/Sql.g:385:1: table_constraint_unique : UNIQUE LPAREN indexed_columns+= id ( COMMA indexed_columns+= id )* RPAREN ( table_conflict_clause )? -> ^( UNIQUE ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? ) ;
    public final SqlParser.table_constraint_unique_return table_constraint_unique() throws RecognitionException {
        SqlParser.table_constraint_unique_return retval = new SqlParser.table_constraint_unique_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token UNIQUE360=null;
        Token LPAREN361=null;
        Token COMMA362=null;
        Token RPAREN363=null;
        List list_indexed_columns=null;
        SqlParser.table_conflict_clause_return table_conflict_clause364 = null;

        SqlParser.id_return indexed_columns = null;
         indexed_columns = null;
        Object UNIQUE360_tree=null;
        Object LPAREN361_tree=null;
        Object COMMA362_tree=null;
        Object RPAREN363_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_UNIQUE=new RewriteRuleTokenStream(adaptor,"token UNIQUE");
        RewriteRuleSubtreeStream stream_table_conflict_clause=new RewriteRuleSubtreeStream(adaptor,"rule table_conflict_clause");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:385:24: ( UNIQUE LPAREN indexed_columns+= id ( COMMA indexed_columns+= id )* RPAREN ( table_conflict_clause )? -> ^( UNIQUE ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? ) )
            // sqljet/src/Sql.g:385:26: UNIQUE LPAREN indexed_columns+= id ( COMMA indexed_columns+= id )* RPAREN ( table_conflict_clause )?
            {
            UNIQUE360=(Token)match(input,UNIQUE,FOLLOW_UNIQUE_in_table_constraint_unique3203);  
            stream_UNIQUE.add(UNIQUE360);

            LPAREN361=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_table_constraint_unique3207);  
            stream_LPAREN.add(LPAREN361);

            pushFollow(FOLLOW_id_in_table_constraint_unique3211);
            indexed_columns=id();

            state._fsp--;

            stream_id.add(indexed_columns.getTree());
            if (list_indexed_columns==null) list_indexed_columns=new ArrayList();
            list_indexed_columns.add(indexed_columns.getTree());

            // sqljet/src/Sql.g:386:30: ( COMMA indexed_columns+= id )*
            loop134:
            do {
                int alt134=2;
                int LA134_0 = input.LA(1);

                if ( (LA134_0==COMMA) ) {
                    alt134=1;
                }


                switch (alt134) {
            	case 1 :
            	    // sqljet/src/Sql.g:386:31: COMMA indexed_columns+= id
            	    {
            	    COMMA362=(Token)match(input,COMMA,FOLLOW_COMMA_in_table_constraint_unique3214);  
            	    stream_COMMA.add(COMMA362);

            	    pushFollow(FOLLOW_id_in_table_constraint_unique3218);
            	    indexed_columns=id();

            	    state._fsp--;

            	    stream_id.add(indexed_columns.getTree());
            	    if (list_indexed_columns==null) list_indexed_columns=new ArrayList();
            	    list_indexed_columns.add(indexed_columns.getTree());


            	    }
            	    break;

            	default :
            	    break loop134;
                }
            } while (true);

            RPAREN363=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_table_constraint_unique3222);  
            stream_RPAREN.add(RPAREN363);

            // sqljet/src/Sql.g:386:66: ( table_conflict_clause )?
            int alt135=2;
            int LA135_0 = input.LA(1);

            if ( (LA135_0==ON) ) {
                alt135=1;
            }
            switch (alt135) {
                case 1 :
                    // sqljet/src/Sql.g:386:66: table_conflict_clause
                    {
                    pushFollow(FOLLOW_table_conflict_clause_in_table_constraint_unique3224);
                    table_conflict_clause364=table_conflict_clause();

                    state._fsp--;

                    stream_table_conflict_clause.add(table_conflict_clause364.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: indexed_columns, table_conflict_clause, UNIQUE
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: indexed_columns
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_indexed_columns=new RewriteRuleSubtreeStream(adaptor,"token indexed_columns",list_indexed_columns);
            root_0 = (Object)adaptor.nil();
            // 387:1: -> ^( UNIQUE ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? )
            {
                // sqljet/src/Sql.g:387:4: ^( UNIQUE ^( COLUMNS ( $indexed_columns)+ ) ( table_conflict_clause )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_UNIQUE.nextNode(), root_1);

                // sqljet/src/Sql.g:387:13: ^( COLUMNS ( $indexed_columns)+ )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMNS, "COLUMNS"), root_2);

                if ( !(stream_indexed_columns.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_indexed_columns.hasNext() ) {
                    adaptor.addChild(root_2, stream_indexed_columns.nextTree());

                }
                stream_indexed_columns.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:387:42: ( table_conflict_clause )?
                if ( stream_table_conflict_clause.hasNext() ) {
                    adaptor.addChild(root_1, stream_table_conflict_clause.nextTree());

                }
                stream_table_conflict_clause.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "table_constraint_unique"

    public static class table_constraint_check_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "table_constraint_check"
    // sqljet/src/Sql.g:389:1: table_constraint_check : CHECK LPAREN expr RPAREN ;
    public final SqlParser.table_constraint_check_return table_constraint_check() throws RecognitionException {
        SqlParser.table_constraint_check_return retval = new SqlParser.table_constraint_check_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CHECK365=null;
        Token LPAREN366=null;
        Token RPAREN368=null;
        SqlParser.expr_return expr367 = null;


        Object CHECK365_tree=null;
        Object LPAREN366_tree=null;
        Object RPAREN368_tree=null;

        try {
            // sqljet/src/Sql.g:389:23: ( CHECK LPAREN expr RPAREN )
            // sqljet/src/Sql.g:389:25: CHECK LPAREN expr RPAREN
            {
            root_0 = (Object)adaptor.nil();

            CHECK365=(Token)match(input,CHECK,FOLLOW_CHECK_in_table_constraint_check3249); 
            CHECK365_tree = (Object)adaptor.create(CHECK365);
            root_0 = (Object)adaptor.becomeRoot(CHECK365_tree, root_0);

            LPAREN366=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_table_constraint_check3252); 
            pushFollow(FOLLOW_expr_in_table_constraint_check3255);
            expr367=expr();

            state._fsp--;

            adaptor.addChild(root_0, expr367.getTree());
            RPAREN368=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_table_constraint_check3257); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "table_constraint_check"

    public static class table_constraint_fk_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "table_constraint_fk"
    // sqljet/src/Sql.g:391:1: table_constraint_fk : FOREIGN KEY LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN fk_clause -> ^( FOREIGN ^( COLUMNS ( $column_names)+ ) fk_clause ) ;
    public final SqlParser.table_constraint_fk_return table_constraint_fk() throws RecognitionException {
        SqlParser.table_constraint_fk_return retval = new SqlParser.table_constraint_fk_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token FOREIGN369=null;
        Token KEY370=null;
        Token LPAREN371=null;
        Token COMMA372=null;
        Token RPAREN373=null;
        List list_column_names=null;
        SqlParser.fk_clause_return fk_clause374 = null;

        SqlParser.id_return column_names = null;
         column_names = null;
        Object FOREIGN369_tree=null;
        Object KEY370_tree=null;
        Object LPAREN371_tree=null;
        Object COMMA372_tree=null;
        Object RPAREN373_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_FOREIGN=new RewriteRuleTokenStream(adaptor,"token FOREIGN");
        RewriteRuleTokenStream stream_KEY=new RewriteRuleTokenStream(adaptor,"token KEY");
        RewriteRuleSubtreeStream stream_fk_clause=new RewriteRuleSubtreeStream(adaptor,"rule fk_clause");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:391:20: ( FOREIGN KEY LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN fk_clause -> ^( FOREIGN ^( COLUMNS ( $column_names)+ ) fk_clause ) )
            // sqljet/src/Sql.g:391:22: FOREIGN KEY LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN fk_clause
            {
            FOREIGN369=(Token)match(input,FOREIGN,FOLLOW_FOREIGN_in_table_constraint_fk3265);  
            stream_FOREIGN.add(FOREIGN369);

            KEY370=(Token)match(input,KEY,FOLLOW_KEY_in_table_constraint_fk3267);  
            stream_KEY.add(KEY370);

            LPAREN371=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_table_constraint_fk3269);  
            stream_LPAREN.add(LPAREN371);

            pushFollow(FOLLOW_id_in_table_constraint_fk3273);
            column_names=id();

            state._fsp--;

            stream_id.add(column_names.getTree());
            if (list_column_names==null) list_column_names=new ArrayList();
            list_column_names.add(column_names.getTree());

            // sqljet/src/Sql.g:391:58: ( COMMA column_names+= id )*
            loop136:
            do {
                int alt136=2;
                int LA136_0 = input.LA(1);

                if ( (LA136_0==COMMA) ) {
                    alt136=1;
                }


                switch (alt136) {
            	case 1 :
            	    // sqljet/src/Sql.g:391:59: COMMA column_names+= id
            	    {
            	    COMMA372=(Token)match(input,COMMA,FOLLOW_COMMA_in_table_constraint_fk3276);  
            	    stream_COMMA.add(COMMA372);

            	    pushFollow(FOLLOW_id_in_table_constraint_fk3280);
            	    column_names=id();

            	    state._fsp--;

            	    stream_id.add(column_names.getTree());
            	    if (list_column_names==null) list_column_names=new ArrayList();
            	    list_column_names.add(column_names.getTree());


            	    }
            	    break;

            	default :
            	    break loop136;
                }
            } while (true);

            RPAREN373=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_table_constraint_fk3284);  
            stream_RPAREN.add(RPAREN373);

            pushFollow(FOLLOW_fk_clause_in_table_constraint_fk3286);
            fk_clause374=fk_clause();

            state._fsp--;

            stream_fk_clause.add(fk_clause374.getTree());


            // AST REWRITE
            // elements: FOREIGN, fk_clause, column_names
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: column_names
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_column_names=new RewriteRuleSubtreeStream(adaptor,"token column_names",list_column_names);
            root_0 = (Object)adaptor.nil();
            // 392:1: -> ^( FOREIGN ^( COLUMNS ( $column_names)+ ) fk_clause )
            {
                // sqljet/src/Sql.g:392:4: ^( FOREIGN ^( COLUMNS ( $column_names)+ ) fk_clause )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_FOREIGN.nextNode(), root_1);

                // sqljet/src/Sql.g:392:14: ^( COLUMNS ( $column_names)+ )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMNS, "COLUMNS"), root_2);

                if ( !(stream_column_names.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_column_names.hasNext() ) {
                    adaptor.addChild(root_2, stream_column_names.nextTree());

                }
                stream_column_names.reset();

                adaptor.addChild(root_1, root_2);
                }
                adaptor.addChild(root_1, stream_fk_clause.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "table_constraint_fk"

    public static class fk_clause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fk_clause"
    // sqljet/src/Sql.g:394:1: fk_clause : REFERENCES foreign_table= id ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( fk_clause_action )* ( fk_clause_deferrable )? -> ^( REFERENCES $foreign_table ^( COLUMNS ( $column_names)+ ) ( fk_clause_action )* ( fk_clause_deferrable )? ) ;
    public final SqlParser.fk_clause_return fk_clause() throws RecognitionException {
        SqlParser.fk_clause_return retval = new SqlParser.fk_clause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token REFERENCES375=null;
        Token LPAREN376=null;
        Token COMMA377=null;
        Token RPAREN378=null;
        List list_column_names=null;
        SqlParser.id_return foreign_table = null;

        SqlParser.fk_clause_action_return fk_clause_action379 = null;

        SqlParser.fk_clause_deferrable_return fk_clause_deferrable380 = null;

        SqlParser.id_return column_names = null;
         column_names = null;
        Object REFERENCES375_tree=null;
        Object LPAREN376_tree=null;
        Object COMMA377_tree=null;
        Object RPAREN378_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_REFERENCES=new RewriteRuleTokenStream(adaptor,"token REFERENCES");
        RewriteRuleSubtreeStream stream_fk_clause_deferrable=new RewriteRuleSubtreeStream(adaptor,"rule fk_clause_deferrable");
        RewriteRuleSubtreeStream stream_fk_clause_action=new RewriteRuleSubtreeStream(adaptor,"rule fk_clause_action");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:394:10: ( REFERENCES foreign_table= id ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( fk_clause_action )* ( fk_clause_deferrable )? -> ^( REFERENCES $foreign_table ^( COLUMNS ( $column_names)+ ) ( fk_clause_action )* ( fk_clause_deferrable )? ) )
            // sqljet/src/Sql.g:394:12: REFERENCES foreign_table= id ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )? ( fk_clause_action )* ( fk_clause_deferrable )?
            {
            REFERENCES375=(Token)match(input,REFERENCES,FOLLOW_REFERENCES_in_fk_clause3309);  
            stream_REFERENCES.add(REFERENCES375);

            pushFollow(FOLLOW_id_in_fk_clause3313);
            foreign_table=id();

            state._fsp--;

            stream_id.add(foreign_table.getTree());
            // sqljet/src/Sql.g:394:40: ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )?
            int alt138=2;
            alt138 = dfa138.predict(input);
            switch (alt138) {
                case 1 :
                    // sqljet/src/Sql.g:394:41: LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN
                    {
                    LPAREN376=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_fk_clause3316);  
                    stream_LPAREN.add(LPAREN376);

                    pushFollow(FOLLOW_id_in_fk_clause3320);
                    column_names=id();

                    state._fsp--;

                    stream_id.add(column_names.getTree());
                    if (list_column_names==null) list_column_names=new ArrayList();
                    list_column_names.add(column_names.getTree());

                    // sqljet/src/Sql.g:394:65: ( COMMA column_names+= id )*
                    loop137:
                    do {
                        int alt137=2;
                        int LA137_0 = input.LA(1);

                        if ( (LA137_0==COMMA) ) {
                            alt137=1;
                        }


                        switch (alt137) {
                    	case 1 :
                    	    // sqljet/src/Sql.g:394:66: COMMA column_names+= id
                    	    {
                    	    COMMA377=(Token)match(input,COMMA,FOLLOW_COMMA_in_fk_clause3323);  
                    	    stream_COMMA.add(COMMA377);

                    	    pushFollow(FOLLOW_id_in_fk_clause3327);
                    	    column_names=id();

                    	    state._fsp--;

                    	    stream_id.add(column_names.getTree());
                    	    if (list_column_names==null) list_column_names=new ArrayList();
                    	    list_column_names.add(column_names.getTree());


                    	    }
                    	    break;

                    	default :
                    	    break loop137;
                        }
                    } while (true);

                    RPAREN378=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_fk_clause3331);  
                    stream_RPAREN.add(RPAREN378);


                    }
                    break;

            }

            // sqljet/src/Sql.g:395:3: ( fk_clause_action )*
            loop139:
            do {
                int alt139=2;
                alt139 = dfa139.predict(input);
                switch (alt139) {
            	case 1 :
            	    // sqljet/src/Sql.g:395:3: fk_clause_action
            	    {
            	    pushFollow(FOLLOW_fk_clause_action_in_fk_clause3337);
            	    fk_clause_action379=fk_clause_action();

            	    state._fsp--;

            	    stream_fk_clause_action.add(fk_clause_action379.getTree());

            	    }
            	    break;

            	default :
            	    break loop139;
                }
            } while (true);

            // sqljet/src/Sql.g:395:21: ( fk_clause_deferrable )?
            int alt140=2;
            alt140 = dfa140.predict(input);
            switch (alt140) {
                case 1 :
                    // sqljet/src/Sql.g:395:21: fk_clause_deferrable
                    {
                    pushFollow(FOLLOW_fk_clause_deferrable_in_fk_clause3340);
                    fk_clause_deferrable380=fk_clause_deferrable();

                    state._fsp--;

                    stream_fk_clause_deferrable.add(fk_clause_deferrable380.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: column_names, fk_clause_action, foreign_table, fk_clause_deferrable, REFERENCES
            // token labels: 
            // rule labels: foreign_table, retval
            // token list labels: 
            // rule list labels: column_names
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_foreign_table=new RewriteRuleSubtreeStream(adaptor,"rule foreign_table",foreign_table!=null?foreign_table.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_column_names=new RewriteRuleSubtreeStream(adaptor,"token column_names",list_column_names);
            root_0 = (Object)adaptor.nil();
            // 396:1: -> ^( REFERENCES $foreign_table ^( COLUMNS ( $column_names)+ ) ( fk_clause_action )* ( fk_clause_deferrable )? )
            {
                // sqljet/src/Sql.g:396:4: ^( REFERENCES $foreign_table ^( COLUMNS ( $column_names)+ ) ( fk_clause_action )* ( fk_clause_deferrable )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_REFERENCES.nextNode(), root_1);

                adaptor.addChild(root_1, stream_foreign_table.nextTree());
                // sqljet/src/Sql.g:396:32: ^( COLUMNS ( $column_names)+ )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMNS, "COLUMNS"), root_2);

                if ( !(stream_column_names.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_column_names.hasNext() ) {
                    adaptor.addChild(root_2, stream_column_names.nextTree());

                }
                stream_column_names.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:396:58: ( fk_clause_action )*
                while ( stream_fk_clause_action.hasNext() ) {
                    adaptor.addChild(root_1, stream_fk_clause_action.nextTree());

                }
                stream_fk_clause_action.reset();
                // sqljet/src/Sql.g:396:76: ( fk_clause_deferrable )?
                if ( stream_fk_clause_deferrable.hasNext() ) {
                    adaptor.addChild(root_1, stream_fk_clause_deferrable.nextTree());

                }
                stream_fk_clause_deferrable.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fk_clause"

    public static class fk_clause_action_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fk_clause_action"
    // sqljet/src/Sql.g:398:1: fk_clause_action : ( ON ( DELETE | UPDATE | INSERT ) ( SET NULL | SET DEFAULT | CASCADE | RESTRICT ) | MATCH id );
    public final SqlParser.fk_clause_action_return fk_clause_action() throws RecognitionException {
        SqlParser.fk_clause_action_return retval = new SqlParser.fk_clause_action_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ON381=null;
        Token set382=null;
        Token SET383=null;
        Token NULL384=null;
        Token SET385=null;
        Token DEFAULT386=null;
        Token CASCADE387=null;
        Token RESTRICT388=null;
        Token MATCH389=null;
        SqlParser.id_return id390 = null;


        Object ON381_tree=null;
        Object set382_tree=null;
        Object SET383_tree=null;
        Object NULL384_tree=null;
        Object SET385_tree=null;
        Object DEFAULT386_tree=null;
        Object CASCADE387_tree=null;
        Object RESTRICT388_tree=null;
        Object MATCH389_tree=null;

        try {
            // sqljet/src/Sql.g:399:3: ( ON ( DELETE | UPDATE | INSERT ) ( SET NULL | SET DEFAULT | CASCADE | RESTRICT ) | MATCH id )
            int alt142=2;
            int LA142_0 = input.LA(1);

            if ( (LA142_0==ON) ) {
                alt142=1;
            }
            else if ( (LA142_0==MATCH) ) {
                alt142=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 142, 0, input);

                throw nvae;
            }
            switch (alt142) {
                case 1 :
                    // sqljet/src/Sql.g:399:5: ON ( DELETE | UPDATE | INSERT ) ( SET NULL | SET DEFAULT | CASCADE | RESTRICT )
                    {
                    root_0 = (Object)adaptor.nil();

                    ON381=(Token)match(input,ON,FOLLOW_ON_in_fk_clause_action3374); 
                    ON381_tree = (Object)adaptor.create(ON381);
                    root_0 = (Object)adaptor.becomeRoot(ON381_tree, root_0);

                    set382=(Token)input.LT(1);
                    if ( input.LA(1)==INSERT||input.LA(1)==UPDATE||input.LA(1)==DELETE ) {
                        input.consume();
                        adaptor.addChild(root_0, (Object)adaptor.create(set382));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }

                    // sqljet/src/Sql.g:399:36: ( SET NULL | SET DEFAULT | CASCADE | RESTRICT )
                    int alt141=4;
                    switch ( input.LA(1) ) {
                    case SET:
                        {
                        int LA141_1 = input.LA(2);

                        if ( (LA141_1==NULL) ) {
                            alt141=1;
                        }
                        else if ( (LA141_1==DEFAULT) ) {
                            alt141=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 141, 1, input);

                            throw nvae;
                        }
                        }
                        break;
                    case CASCADE:
                        {
                        alt141=3;
                        }
                        break;
                    case RESTRICT:
                        {
                        alt141=4;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 141, 0, input);

                        throw nvae;
                    }

                    switch (alt141) {
                        case 1 :
                            // sqljet/src/Sql.g:399:37: SET NULL
                            {
                            SET383=(Token)match(input,SET,FOLLOW_SET_in_fk_clause_action3390); 
                            NULL384=(Token)match(input,NULL,FOLLOW_NULL_in_fk_clause_action3393); 
                            NULL384_tree = (Object)adaptor.create(NULL384);
                            adaptor.addChild(root_0, NULL384_tree);


                            }
                            break;
                        case 2 :
                            // sqljet/src/Sql.g:399:49: SET DEFAULT
                            {
                            SET385=(Token)match(input,SET,FOLLOW_SET_in_fk_clause_action3397); 
                            DEFAULT386=(Token)match(input,DEFAULT,FOLLOW_DEFAULT_in_fk_clause_action3400); 
                            DEFAULT386_tree = (Object)adaptor.create(DEFAULT386);
                            adaptor.addChild(root_0, DEFAULT386_tree);


                            }
                            break;
                        case 3 :
                            // sqljet/src/Sql.g:399:64: CASCADE
                            {
                            CASCADE387=(Token)match(input,CASCADE,FOLLOW_CASCADE_in_fk_clause_action3404); 
                            CASCADE387_tree = (Object)adaptor.create(CASCADE387);
                            adaptor.addChild(root_0, CASCADE387_tree);


                            }
                            break;
                        case 4 :
                            // sqljet/src/Sql.g:399:74: RESTRICT
                            {
                            RESTRICT388=(Token)match(input,RESTRICT,FOLLOW_RESTRICT_in_fk_clause_action3408); 
                            RESTRICT388_tree = (Object)adaptor.create(RESTRICT388);
                            adaptor.addChild(root_0, RESTRICT388_tree);


                            }
                            break;

                    }


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:400:5: MATCH id
                    {
                    root_0 = (Object)adaptor.nil();

                    MATCH389=(Token)match(input,MATCH,FOLLOW_MATCH_in_fk_clause_action3415); 
                    MATCH389_tree = (Object)adaptor.create(MATCH389);
                    root_0 = (Object)adaptor.becomeRoot(MATCH389_tree, root_0);

                    pushFollow(FOLLOW_id_in_fk_clause_action3418);
                    id390=id();

                    state._fsp--;

                    adaptor.addChild(root_0, id390.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fk_clause_action"

    public static class fk_clause_deferrable_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fk_clause_deferrable"
    // sqljet/src/Sql.g:402:1: fk_clause_deferrable : ( NOT )? DEFERRABLE ( INITIALLY DEFERRED | INITIALLY IMMEDIATE )? ;
    public final SqlParser.fk_clause_deferrable_return fk_clause_deferrable() throws RecognitionException {
        SqlParser.fk_clause_deferrable_return retval = new SqlParser.fk_clause_deferrable_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token NOT391=null;
        Token DEFERRABLE392=null;
        Token INITIALLY393=null;
        Token DEFERRED394=null;
        Token INITIALLY395=null;
        Token IMMEDIATE396=null;

        Object NOT391_tree=null;
        Object DEFERRABLE392_tree=null;
        Object INITIALLY393_tree=null;
        Object DEFERRED394_tree=null;
        Object INITIALLY395_tree=null;
        Object IMMEDIATE396_tree=null;

        try {
            // sqljet/src/Sql.g:402:21: ( ( NOT )? DEFERRABLE ( INITIALLY DEFERRED | INITIALLY IMMEDIATE )? )
            // sqljet/src/Sql.g:402:23: ( NOT )? DEFERRABLE ( INITIALLY DEFERRED | INITIALLY IMMEDIATE )?
            {
            root_0 = (Object)adaptor.nil();

            // sqljet/src/Sql.g:402:23: ( NOT )?
            int alt143=2;
            int LA143_0 = input.LA(1);

            if ( (LA143_0==NOT) ) {
                alt143=1;
            }
            switch (alt143) {
                case 1 :
                    // sqljet/src/Sql.g:402:24: NOT
                    {
                    NOT391=(Token)match(input,NOT,FOLLOW_NOT_in_fk_clause_deferrable3426); 
                    NOT391_tree = (Object)adaptor.create(NOT391);
                    adaptor.addChild(root_0, NOT391_tree);


                    }
                    break;

            }

            DEFERRABLE392=(Token)match(input,DEFERRABLE,FOLLOW_DEFERRABLE_in_fk_clause_deferrable3430); 
            DEFERRABLE392_tree = (Object)adaptor.create(DEFERRABLE392);
            root_0 = (Object)adaptor.becomeRoot(DEFERRABLE392_tree, root_0);

            // sqljet/src/Sql.g:402:42: ( INITIALLY DEFERRED | INITIALLY IMMEDIATE )?
            int alt144=3;
            alt144 = dfa144.predict(input);
            switch (alt144) {
                case 1 :
                    // sqljet/src/Sql.g:402:43: INITIALLY DEFERRED
                    {
                    INITIALLY393=(Token)match(input,INITIALLY,FOLLOW_INITIALLY_in_fk_clause_deferrable3434); 
                    DEFERRED394=(Token)match(input,DEFERRED,FOLLOW_DEFERRED_in_fk_clause_deferrable3437); 
                    DEFERRED394_tree = (Object)adaptor.create(DEFERRED394);
                    adaptor.addChild(root_0, DEFERRED394_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:402:65: INITIALLY IMMEDIATE
                    {
                    INITIALLY395=(Token)match(input,INITIALLY,FOLLOW_INITIALLY_in_fk_clause_deferrable3441); 
                    IMMEDIATE396=(Token)match(input,IMMEDIATE,FOLLOW_IMMEDIATE_in_fk_clause_deferrable3444); 
                    IMMEDIATE396_tree = (Object)adaptor.create(IMMEDIATE396);
                    adaptor.addChild(root_0, IMMEDIATE396_tree);


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fk_clause_deferrable"

    public static class drop_table_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "drop_table_stmt"
    // sqljet/src/Sql.g:405:1: drop_table_stmt : DROP TABLE ( IF EXISTS )? (database_name= id DOT )? table_name= id -> ^( DROP_TABLE ^( OPTIONS ( EXISTS )? ) ^( $table_name ( $database_name)? ) ) ;
    public final SqlParser.drop_table_stmt_return drop_table_stmt() throws RecognitionException {
        SqlParser.drop_table_stmt_return retval = new SqlParser.drop_table_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DROP397=null;
        Token TABLE398=null;
        Token IF399=null;
        Token EXISTS400=null;
        Token DOT401=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;


        Object DROP397_tree=null;
        Object TABLE398_tree=null;
        Object IF399_tree=null;
        Object EXISTS400_tree=null;
        Object DOT401_tree=null;
        RewriteRuleTokenStream stream_EXISTS=new RewriteRuleTokenStream(adaptor,"token EXISTS");
        RewriteRuleTokenStream stream_DROP=new RewriteRuleTokenStream(adaptor,"token DROP");
        RewriteRuleTokenStream stream_TABLE=new RewriteRuleTokenStream(adaptor,"token TABLE");
        RewriteRuleTokenStream stream_IF=new RewriteRuleTokenStream(adaptor,"token IF");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:405:16: ( DROP TABLE ( IF EXISTS )? (database_name= id DOT )? table_name= id -> ^( DROP_TABLE ^( OPTIONS ( EXISTS )? ) ^( $table_name ( $database_name)? ) ) )
            // sqljet/src/Sql.g:405:18: DROP TABLE ( IF EXISTS )? (database_name= id DOT )? table_name= id
            {
            DROP397=(Token)match(input,DROP,FOLLOW_DROP_in_drop_table_stmt3454);  
            stream_DROP.add(DROP397);

            TABLE398=(Token)match(input,TABLE,FOLLOW_TABLE_in_drop_table_stmt3456);  
            stream_TABLE.add(TABLE398);

            // sqljet/src/Sql.g:405:29: ( IF EXISTS )?
            int alt145=2;
            int LA145_0 = input.LA(1);

            if ( (LA145_0==IF) ) {
                int LA145_1 = input.LA(2);

                if ( (LA145_1==EXISTS) ) {
                    alt145=1;
                }
            }
            switch (alt145) {
                case 1 :
                    // sqljet/src/Sql.g:405:30: IF EXISTS
                    {
                    IF399=(Token)match(input,IF,FOLLOW_IF_in_drop_table_stmt3459);  
                    stream_IF.add(IF399);

                    EXISTS400=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_drop_table_stmt3461);  
                    stream_EXISTS.add(EXISTS400);


                    }
                    break;

            }

            // sqljet/src/Sql.g:405:42: (database_name= id DOT )?
            int alt146=2;
            int LA146_0 = input.LA(1);

            if ( (LA146_0==ID) ) {
                int LA146_1 = input.LA(2);

                if ( (LA146_1==DOT) ) {
                    alt146=1;
                }
            }
            else if ( ((LA146_0>=EXPLAIN && LA146_0<=PLAN)||(LA146_0>=INDEXED && LA146_0<=BY)||(LA146_0>=OR && LA146_0<=ESCAPE)||(LA146_0>=IS && LA146_0<=BETWEEN)||LA146_0==COLLATE||(LA146_0>=DISTINCT && LA146_0<=THEN)||(LA146_0>=CURRENT_TIME && LA146_0<=CURRENT_TIMESTAMP)||(LA146_0>=RAISE && LA146_0<=ROW)) ) {
                int LA146_2 = input.LA(2);

                if ( (LA146_2==DOT) ) {
                    alt146=1;
                }
            }
            switch (alt146) {
                case 1 :
                    // sqljet/src/Sql.g:405:43: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_drop_table_stmt3468);
                    database_name=id();

                    state._fsp--;

                    stream_id.add(database_name.getTree());
                    DOT401=(Token)match(input,DOT,FOLLOW_DOT_in_drop_table_stmt3470);  
                    stream_DOT.add(DOT401);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_drop_table_stmt3476);
            table_name=id();

            state._fsp--;

            stream_id.add(table_name.getTree());


            // AST REWRITE
            // elements: EXISTS, database_name, table_name
            // token labels: 
            // rule labels: database_name, retval, table_name
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_table_name=new RewriteRuleSubtreeStream(adaptor,"rule table_name",table_name!=null?table_name.tree:null);

            root_0 = (Object)adaptor.nil();
            // 406:1: -> ^( DROP_TABLE ^( OPTIONS ( EXISTS )? ) ^( $table_name ( $database_name)? ) )
            {
                // sqljet/src/Sql.g:406:4: ^( DROP_TABLE ^( OPTIONS ( EXISTS )? ) ^( $table_name ( $database_name)? ) )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(DROP_TABLE, "DROP_TABLE"), root_1);

                // sqljet/src/Sql.g:406:17: ^( OPTIONS ( EXISTS )? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(OPTIONS, "OPTIONS"), root_2);

                // sqljet/src/Sql.g:406:27: ( EXISTS )?
                if ( stream_EXISTS.hasNext() ) {
                    adaptor.addChild(root_2, stream_EXISTS.nextNode());

                }
                stream_EXISTS.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:406:36: ^( $table_name ( $database_name)? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot(stream_table_name.nextNode(), root_2);

                // sqljet/src/Sql.g:406:50: ( $database_name)?
                if ( stream_database_name.hasNext() ) {
                    adaptor.addChild(root_2, stream_database_name.nextTree());

                }
                stream_database_name.reset();

                adaptor.addChild(root_1, root_2);
                }

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "drop_table_stmt"

    public static class alter_table_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "alter_table_stmt"
    // sqljet/src/Sql.g:409:1: alter_table_stmt : ALTER TABLE (database_name= id DOT )? table_name= id ( RENAME TO new_table_name= id | ADD ( COLUMN )? column_def ) ;
    public final SqlParser.alter_table_stmt_return alter_table_stmt() throws RecognitionException {
        SqlParser.alter_table_stmt_return retval = new SqlParser.alter_table_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ALTER402=null;
        Token TABLE403=null;
        Token DOT404=null;
        Token RENAME405=null;
        Token TO406=null;
        Token ADD407=null;
        Token COLUMN408=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.id_return new_table_name = null;

        SqlParser.column_def_return column_def409 = null;


        Object ALTER402_tree=null;
        Object TABLE403_tree=null;
        Object DOT404_tree=null;
        Object RENAME405_tree=null;
        Object TO406_tree=null;
        Object ADD407_tree=null;
        Object COLUMN408_tree=null;

        try {
            // sqljet/src/Sql.g:409:17: ( ALTER TABLE (database_name= id DOT )? table_name= id ( RENAME TO new_table_name= id | ADD ( COLUMN )? column_def ) )
            // sqljet/src/Sql.g:409:19: ALTER TABLE (database_name= id DOT )? table_name= id ( RENAME TO new_table_name= id | ADD ( COLUMN )? column_def )
            {
            root_0 = (Object)adaptor.nil();

            ALTER402=(Token)match(input,ALTER,FOLLOW_ALTER_in_alter_table_stmt3506); 
            ALTER402_tree = (Object)adaptor.create(ALTER402);
            adaptor.addChild(root_0, ALTER402_tree);

            TABLE403=(Token)match(input,TABLE,FOLLOW_TABLE_in_alter_table_stmt3508); 
            TABLE403_tree = (Object)adaptor.create(TABLE403);
            adaptor.addChild(root_0, TABLE403_tree);

            // sqljet/src/Sql.g:409:31: (database_name= id DOT )?
            int alt147=2;
            int LA147_0 = input.LA(1);

            if ( (LA147_0==ID) ) {
                int LA147_1 = input.LA(2);

                if ( (LA147_1==DOT) ) {
                    alt147=1;
                }
            }
            else if ( ((LA147_0>=EXPLAIN && LA147_0<=PLAN)||(LA147_0>=INDEXED && LA147_0<=BY)||(LA147_0>=OR && LA147_0<=ESCAPE)||(LA147_0>=IS && LA147_0<=BETWEEN)||LA147_0==COLLATE||(LA147_0>=DISTINCT && LA147_0<=THEN)||(LA147_0>=CURRENT_TIME && LA147_0<=CURRENT_TIMESTAMP)||(LA147_0>=RAISE && LA147_0<=ROW)) ) {
                int LA147_2 = input.LA(2);

                if ( (LA147_2==DOT) ) {
                    alt147=1;
                }
            }
            switch (alt147) {
                case 1 :
                    // sqljet/src/Sql.g:409:32: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_alter_table_stmt3513);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT404=(Token)match(input,DOT,FOLLOW_DOT_in_alter_table_stmt3515); 
                    DOT404_tree = (Object)adaptor.create(DOT404);
                    adaptor.addChild(root_0, DOT404_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_alter_table_stmt3521);
            table_name=id();

            state._fsp--;

            adaptor.addChild(root_0, table_name.getTree());
            // sqljet/src/Sql.g:409:69: ( RENAME TO new_table_name= id | ADD ( COLUMN )? column_def )
            int alt149=2;
            int LA149_0 = input.LA(1);

            if ( (LA149_0==RENAME) ) {
                alt149=1;
            }
            else if ( (LA149_0==ADD) ) {
                alt149=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 149, 0, input);

                throw nvae;
            }
            switch (alt149) {
                case 1 :
                    // sqljet/src/Sql.g:409:70: RENAME TO new_table_name= id
                    {
                    RENAME405=(Token)match(input,RENAME,FOLLOW_RENAME_in_alter_table_stmt3524); 
                    RENAME405_tree = (Object)adaptor.create(RENAME405);
                    adaptor.addChild(root_0, RENAME405_tree);

                    TO406=(Token)match(input,TO,FOLLOW_TO_in_alter_table_stmt3526); 
                    TO406_tree = (Object)adaptor.create(TO406);
                    adaptor.addChild(root_0, TO406_tree);

                    pushFollow(FOLLOW_id_in_alter_table_stmt3530);
                    new_table_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, new_table_name.getTree());

                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:409:100: ADD ( COLUMN )? column_def
                    {
                    ADD407=(Token)match(input,ADD,FOLLOW_ADD_in_alter_table_stmt3534); 
                    ADD407_tree = (Object)adaptor.create(ADD407);
                    adaptor.addChild(root_0, ADD407_tree);

                    // sqljet/src/Sql.g:409:104: ( COLUMN )?
                    int alt148=2;
                    int LA148_0 = input.LA(1);

                    if ( (LA148_0==COLUMN) ) {
                        alt148=1;
                    }
                    switch (alt148) {
                        case 1 :
                            // sqljet/src/Sql.g:409:105: COLUMN
                            {
                            COLUMN408=(Token)match(input,COLUMN,FOLLOW_COLUMN_in_alter_table_stmt3537); 
                            COLUMN408_tree = (Object)adaptor.create(COLUMN408);
                            adaptor.addChild(root_0, COLUMN408_tree);


                            }
                            break;

                    }

                    pushFollow(FOLLOW_column_def_in_alter_table_stmt3541);
                    column_def409=column_def();

                    state._fsp--;

                    adaptor.addChild(root_0, column_def409.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "alter_table_stmt"

    public static class create_view_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "create_view_stmt"
    // sqljet/src/Sql.g:412:1: create_view_stmt : CREATE ( TEMPORARY )? VIEW ( IF NOT EXISTS )? (database_name= id DOT )? view_name= id AS select_stmt ;
    public final SqlParser.create_view_stmt_return create_view_stmt() throws RecognitionException {
        SqlParser.create_view_stmt_return retval = new SqlParser.create_view_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CREATE410=null;
        Token TEMPORARY411=null;
        Token VIEW412=null;
        Token IF413=null;
        Token NOT414=null;
        Token EXISTS415=null;
        Token DOT416=null;
        Token AS417=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return view_name = null;

        SqlParser.select_stmt_return select_stmt418 = null;


        Object CREATE410_tree=null;
        Object TEMPORARY411_tree=null;
        Object VIEW412_tree=null;
        Object IF413_tree=null;
        Object NOT414_tree=null;
        Object EXISTS415_tree=null;
        Object DOT416_tree=null;
        Object AS417_tree=null;

        try {
            // sqljet/src/Sql.g:412:17: ( CREATE ( TEMPORARY )? VIEW ( IF NOT EXISTS )? (database_name= id DOT )? view_name= id AS select_stmt )
            // sqljet/src/Sql.g:412:19: CREATE ( TEMPORARY )? VIEW ( IF NOT EXISTS )? (database_name= id DOT )? view_name= id AS select_stmt
            {
            root_0 = (Object)adaptor.nil();

            CREATE410=(Token)match(input,CREATE,FOLLOW_CREATE_in_create_view_stmt3550); 
            CREATE410_tree = (Object)adaptor.create(CREATE410);
            adaptor.addChild(root_0, CREATE410_tree);

            // sqljet/src/Sql.g:412:26: ( TEMPORARY )?
            int alt150=2;
            int LA150_0 = input.LA(1);

            if ( (LA150_0==TEMPORARY) ) {
                alt150=1;
            }
            switch (alt150) {
                case 1 :
                    // sqljet/src/Sql.g:412:26: TEMPORARY
                    {
                    TEMPORARY411=(Token)match(input,TEMPORARY,FOLLOW_TEMPORARY_in_create_view_stmt3552); 
                    TEMPORARY411_tree = (Object)adaptor.create(TEMPORARY411);
                    adaptor.addChild(root_0, TEMPORARY411_tree);


                    }
                    break;

            }

            VIEW412=(Token)match(input,VIEW,FOLLOW_VIEW_in_create_view_stmt3555); 
            VIEW412_tree = (Object)adaptor.create(VIEW412);
            adaptor.addChild(root_0, VIEW412_tree);

            // sqljet/src/Sql.g:412:42: ( IF NOT EXISTS )?
            int alt151=2;
            int LA151_0 = input.LA(1);

            if ( (LA151_0==IF) ) {
                int LA151_1 = input.LA(2);

                if ( (LA151_1==NOT) ) {
                    alt151=1;
                }
            }
            switch (alt151) {
                case 1 :
                    // sqljet/src/Sql.g:412:43: IF NOT EXISTS
                    {
                    IF413=(Token)match(input,IF,FOLLOW_IF_in_create_view_stmt3558); 
                    IF413_tree = (Object)adaptor.create(IF413);
                    adaptor.addChild(root_0, IF413_tree);

                    NOT414=(Token)match(input,NOT,FOLLOW_NOT_in_create_view_stmt3560); 
                    NOT414_tree = (Object)adaptor.create(NOT414);
                    adaptor.addChild(root_0, NOT414_tree);

                    EXISTS415=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_create_view_stmt3562); 
                    EXISTS415_tree = (Object)adaptor.create(EXISTS415);
                    adaptor.addChild(root_0, EXISTS415_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:412:59: (database_name= id DOT )?
            int alt152=2;
            int LA152_0 = input.LA(1);

            if ( (LA152_0==ID) ) {
                int LA152_1 = input.LA(2);

                if ( (LA152_1==DOT) ) {
                    alt152=1;
                }
            }
            else if ( ((LA152_0>=EXPLAIN && LA152_0<=PLAN)||(LA152_0>=INDEXED && LA152_0<=BY)||(LA152_0>=OR && LA152_0<=ESCAPE)||(LA152_0>=IS && LA152_0<=BETWEEN)||LA152_0==COLLATE||(LA152_0>=DISTINCT && LA152_0<=THEN)||(LA152_0>=CURRENT_TIME && LA152_0<=CURRENT_TIMESTAMP)||(LA152_0>=RAISE && LA152_0<=ROW)) ) {
                int LA152_2 = input.LA(2);

                if ( (LA152_2==DOT) ) {
                    alt152=1;
                }
            }
            switch (alt152) {
                case 1 :
                    // sqljet/src/Sql.g:412:60: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_create_view_stmt3569);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT416=(Token)match(input,DOT,FOLLOW_DOT_in_create_view_stmt3571); 
                    DOT416_tree = (Object)adaptor.create(DOT416);
                    adaptor.addChild(root_0, DOT416_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_create_view_stmt3577);
            view_name=id();

            state._fsp--;

            adaptor.addChild(root_0, view_name.getTree());
            AS417=(Token)match(input,AS,FOLLOW_AS_in_create_view_stmt3579); 
            AS417_tree = (Object)adaptor.create(AS417);
            adaptor.addChild(root_0, AS417_tree);

            pushFollow(FOLLOW_select_stmt_in_create_view_stmt3581);
            select_stmt418=select_stmt();

            state._fsp--;

            adaptor.addChild(root_0, select_stmt418.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "create_view_stmt"

    public static class drop_view_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "drop_view_stmt"
    // sqljet/src/Sql.g:415:1: drop_view_stmt : DROP VIEW ( IF EXISTS )? (database_name= id DOT )? view_name= id ;
    public final SqlParser.drop_view_stmt_return drop_view_stmt() throws RecognitionException {
        SqlParser.drop_view_stmt_return retval = new SqlParser.drop_view_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DROP419=null;
        Token VIEW420=null;
        Token IF421=null;
        Token EXISTS422=null;
        Token DOT423=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return view_name = null;


        Object DROP419_tree=null;
        Object VIEW420_tree=null;
        Object IF421_tree=null;
        Object EXISTS422_tree=null;
        Object DOT423_tree=null;

        try {
            // sqljet/src/Sql.g:415:15: ( DROP VIEW ( IF EXISTS )? (database_name= id DOT )? view_name= id )
            // sqljet/src/Sql.g:415:17: DROP VIEW ( IF EXISTS )? (database_name= id DOT )? view_name= id
            {
            root_0 = (Object)adaptor.nil();

            DROP419=(Token)match(input,DROP,FOLLOW_DROP_in_drop_view_stmt3589); 
            DROP419_tree = (Object)adaptor.create(DROP419);
            adaptor.addChild(root_0, DROP419_tree);

            VIEW420=(Token)match(input,VIEW,FOLLOW_VIEW_in_drop_view_stmt3591); 
            VIEW420_tree = (Object)adaptor.create(VIEW420);
            adaptor.addChild(root_0, VIEW420_tree);

            // sqljet/src/Sql.g:415:27: ( IF EXISTS )?
            int alt153=2;
            int LA153_0 = input.LA(1);

            if ( (LA153_0==IF) ) {
                int LA153_1 = input.LA(2);

                if ( (LA153_1==EXISTS) ) {
                    alt153=1;
                }
            }
            switch (alt153) {
                case 1 :
                    // sqljet/src/Sql.g:415:28: IF EXISTS
                    {
                    IF421=(Token)match(input,IF,FOLLOW_IF_in_drop_view_stmt3594); 
                    IF421_tree = (Object)adaptor.create(IF421);
                    adaptor.addChild(root_0, IF421_tree);

                    EXISTS422=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_drop_view_stmt3596); 
                    EXISTS422_tree = (Object)adaptor.create(EXISTS422);
                    adaptor.addChild(root_0, EXISTS422_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:415:40: (database_name= id DOT )?
            int alt154=2;
            int LA154_0 = input.LA(1);

            if ( (LA154_0==ID) ) {
                int LA154_1 = input.LA(2);

                if ( (LA154_1==DOT) ) {
                    alt154=1;
                }
            }
            else if ( ((LA154_0>=EXPLAIN && LA154_0<=PLAN)||(LA154_0>=INDEXED && LA154_0<=BY)||(LA154_0>=OR && LA154_0<=ESCAPE)||(LA154_0>=IS && LA154_0<=BETWEEN)||LA154_0==COLLATE||(LA154_0>=DISTINCT && LA154_0<=THEN)||(LA154_0>=CURRENT_TIME && LA154_0<=CURRENT_TIMESTAMP)||(LA154_0>=RAISE && LA154_0<=ROW)) ) {
                int LA154_2 = input.LA(2);

                if ( (LA154_2==DOT) ) {
                    alt154=1;
                }
            }
            switch (alt154) {
                case 1 :
                    // sqljet/src/Sql.g:415:41: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_drop_view_stmt3603);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT423=(Token)match(input,DOT,FOLLOW_DOT_in_drop_view_stmt3605); 
                    DOT423_tree = (Object)adaptor.create(DOT423);
                    adaptor.addChild(root_0, DOT423_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_drop_view_stmt3611);
            view_name=id();

            state._fsp--;

            adaptor.addChild(root_0, view_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "drop_view_stmt"

    public static class create_index_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "create_index_stmt"
    // sqljet/src/Sql.g:418:1: create_index_stmt : CREATE ( UNIQUE )? INDEX ( IF NOT EXISTS )? (database_name= id DOT )? index_name= id ON table_name= id LPAREN columns+= indexed_column ( COMMA columns+= indexed_column )* RPAREN -> ^( CREATE_INDEX ^( OPTIONS ( UNIQUE )? ( EXISTS )? ) ^( $index_name ( $database_name)? ) $table_name ( ^( COLUMNS ( $columns)+ ) )? ) ;
    public final SqlParser.create_index_stmt_return create_index_stmt() throws RecognitionException {
        SqlParser.create_index_stmt_return retval = new SqlParser.create_index_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CREATE424=null;
        Token UNIQUE425=null;
        Token INDEX426=null;
        Token IF427=null;
        Token NOT428=null;
        Token EXISTS429=null;
        Token DOT430=null;
        Token ON431=null;
        Token LPAREN432=null;
        Token COMMA433=null;
        Token RPAREN434=null;
        List list_columns=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return index_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.indexed_column_return columns = null;
         columns = null;
        Object CREATE424_tree=null;
        Object UNIQUE425_tree=null;
        Object INDEX426_tree=null;
        Object IF427_tree=null;
        Object NOT428_tree=null;
        Object EXISTS429_tree=null;
        Object DOT430_tree=null;
        Object ON431_tree=null;
        Object LPAREN432_tree=null;
        Object COMMA433_tree=null;
        Object RPAREN434_tree=null;
        RewriteRuleTokenStream stream_INDEX=new RewriteRuleTokenStream(adaptor,"token INDEX");
        RewriteRuleTokenStream stream_EXISTS=new RewriteRuleTokenStream(adaptor,"token EXISTS");
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_IF=new RewriteRuleTokenStream(adaptor,"token IF");
        RewriteRuleTokenStream stream_NOT=new RewriteRuleTokenStream(adaptor,"token NOT");
        RewriteRuleTokenStream stream_UNIQUE=new RewriteRuleTokenStream(adaptor,"token UNIQUE");
        RewriteRuleTokenStream stream_ON=new RewriteRuleTokenStream(adaptor,"token ON");
        RewriteRuleTokenStream stream_CREATE=new RewriteRuleTokenStream(adaptor,"token CREATE");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_indexed_column=new RewriteRuleSubtreeStream(adaptor,"rule indexed_column");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:418:18: ( CREATE ( UNIQUE )? INDEX ( IF NOT EXISTS )? (database_name= id DOT )? index_name= id ON table_name= id LPAREN columns+= indexed_column ( COMMA columns+= indexed_column )* RPAREN -> ^( CREATE_INDEX ^( OPTIONS ( UNIQUE )? ( EXISTS )? ) ^( $index_name ( $database_name)? ) $table_name ( ^( COLUMNS ( $columns)+ ) )? ) )
            // sqljet/src/Sql.g:418:20: CREATE ( UNIQUE )? INDEX ( IF NOT EXISTS )? (database_name= id DOT )? index_name= id ON table_name= id LPAREN columns+= indexed_column ( COMMA columns+= indexed_column )* RPAREN
            {
            CREATE424=(Token)match(input,CREATE,FOLLOW_CREATE_in_create_index_stmt3619);  
            stream_CREATE.add(CREATE424);

            // sqljet/src/Sql.g:418:27: ( UNIQUE )?
            int alt155=2;
            int LA155_0 = input.LA(1);

            if ( (LA155_0==UNIQUE) ) {
                alt155=1;
            }
            switch (alt155) {
                case 1 :
                    // sqljet/src/Sql.g:418:28: UNIQUE
                    {
                    UNIQUE425=(Token)match(input,UNIQUE,FOLLOW_UNIQUE_in_create_index_stmt3622);  
                    stream_UNIQUE.add(UNIQUE425);


                    }
                    break;

            }

            INDEX426=(Token)match(input,INDEX,FOLLOW_INDEX_in_create_index_stmt3626);  
            stream_INDEX.add(INDEX426);

            // sqljet/src/Sql.g:418:43: ( IF NOT EXISTS )?
            int alt156=2;
            int LA156_0 = input.LA(1);

            if ( (LA156_0==IF) ) {
                int LA156_1 = input.LA(2);

                if ( (LA156_1==NOT) ) {
                    alt156=1;
                }
            }
            switch (alt156) {
                case 1 :
                    // sqljet/src/Sql.g:418:44: IF NOT EXISTS
                    {
                    IF427=(Token)match(input,IF,FOLLOW_IF_in_create_index_stmt3629);  
                    stream_IF.add(IF427);

                    NOT428=(Token)match(input,NOT,FOLLOW_NOT_in_create_index_stmt3631);  
                    stream_NOT.add(NOT428);

                    EXISTS429=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_create_index_stmt3633);  
                    stream_EXISTS.add(EXISTS429);


                    }
                    break;

            }

            // sqljet/src/Sql.g:418:60: (database_name= id DOT )?
            int alt157=2;
            int LA157_0 = input.LA(1);

            if ( (LA157_0==ID) ) {
                int LA157_1 = input.LA(2);

                if ( (LA157_1==DOT) ) {
                    alt157=1;
                }
            }
            else if ( ((LA157_0>=EXPLAIN && LA157_0<=PLAN)||(LA157_0>=INDEXED && LA157_0<=BY)||(LA157_0>=OR && LA157_0<=ESCAPE)||(LA157_0>=IS && LA157_0<=BETWEEN)||LA157_0==COLLATE||(LA157_0>=DISTINCT && LA157_0<=THEN)||(LA157_0>=CURRENT_TIME && LA157_0<=CURRENT_TIMESTAMP)||(LA157_0>=RAISE && LA157_0<=ROW)) ) {
                int LA157_2 = input.LA(2);

                if ( (LA157_2==DOT) ) {
                    alt157=1;
                }
            }
            switch (alt157) {
                case 1 :
                    // sqljet/src/Sql.g:418:61: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_create_index_stmt3640);
                    database_name=id();

                    state._fsp--;

                    stream_id.add(database_name.getTree());
                    DOT430=(Token)match(input,DOT,FOLLOW_DOT_in_create_index_stmt3642);  
                    stream_DOT.add(DOT430);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_create_index_stmt3648);
            index_name=id();

            state._fsp--;

            stream_id.add(index_name.getTree());
            ON431=(Token)match(input,ON,FOLLOW_ON_in_create_index_stmt3652);  
            stream_ON.add(ON431);

            pushFollow(FOLLOW_id_in_create_index_stmt3656);
            table_name=id();

            state._fsp--;

            stream_id.add(table_name.getTree());
            LPAREN432=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_create_index_stmt3658);  
            stream_LPAREN.add(LPAREN432);

            pushFollow(FOLLOW_indexed_column_in_create_index_stmt3662);
            columns=indexed_column();

            state._fsp--;

            stream_indexed_column.add(columns.getTree());
            if (list_columns==null) list_columns=new ArrayList();
            list_columns.add(columns.getTree());

            // sqljet/src/Sql.g:419:51: ( COMMA columns+= indexed_column )*
            loop158:
            do {
                int alt158=2;
                int LA158_0 = input.LA(1);

                if ( (LA158_0==COMMA) ) {
                    alt158=1;
                }


                switch (alt158) {
            	case 1 :
            	    // sqljet/src/Sql.g:419:52: COMMA columns+= indexed_column
            	    {
            	    COMMA433=(Token)match(input,COMMA,FOLLOW_COMMA_in_create_index_stmt3665);  
            	    stream_COMMA.add(COMMA433);

            	    pushFollow(FOLLOW_indexed_column_in_create_index_stmt3669);
            	    columns=indexed_column();

            	    state._fsp--;

            	    stream_indexed_column.add(columns.getTree());
            	    if (list_columns==null) list_columns=new ArrayList();
            	    list_columns.add(columns.getTree());


            	    }
            	    break;

            	default :
            	    break loop158;
                }
            } while (true);

            RPAREN434=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_create_index_stmt3673);  
            stream_RPAREN.add(RPAREN434);



            // AST REWRITE
            // elements: columns, index_name, table_name, database_name, EXISTS, UNIQUE
            // token labels: 
            // rule labels: database_name, index_name, retval, table_name
            // token list labels: 
            // rule list labels: columns
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
            RewriteRuleSubtreeStream stream_index_name=new RewriteRuleSubtreeStream(adaptor,"rule index_name",index_name!=null?index_name.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_table_name=new RewriteRuleSubtreeStream(adaptor,"rule table_name",table_name!=null?table_name.tree:null);
            RewriteRuleSubtreeStream stream_columns=new RewriteRuleSubtreeStream(adaptor,"token columns",list_columns);
            root_0 = (Object)adaptor.nil();
            // 420:1: -> ^( CREATE_INDEX ^( OPTIONS ( UNIQUE )? ( EXISTS )? ) ^( $index_name ( $database_name)? ) $table_name ( ^( COLUMNS ( $columns)+ ) )? )
            {
                // sqljet/src/Sql.g:420:4: ^( CREATE_INDEX ^( OPTIONS ( UNIQUE )? ( EXISTS )? ) ^( $index_name ( $database_name)? ) $table_name ( ^( COLUMNS ( $columns)+ ) )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(CREATE_INDEX, "CREATE_INDEX"), root_1);

                // sqljet/src/Sql.g:420:19: ^( OPTIONS ( UNIQUE )? ( EXISTS )? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(OPTIONS, "OPTIONS"), root_2);

                // sqljet/src/Sql.g:420:29: ( UNIQUE )?
                if ( stream_UNIQUE.hasNext() ) {
                    adaptor.addChild(root_2, stream_UNIQUE.nextNode());

                }
                stream_UNIQUE.reset();
                // sqljet/src/Sql.g:420:37: ( EXISTS )?
                if ( stream_EXISTS.hasNext() ) {
                    adaptor.addChild(root_2, stream_EXISTS.nextNode());

                }
                stream_EXISTS.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:420:46: ^( $index_name ( $database_name)? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot(stream_index_name.nextNode(), root_2);

                // sqljet/src/Sql.g:420:60: ( $database_name)?
                if ( stream_database_name.hasNext() ) {
                    adaptor.addChild(root_2, stream_database_name.nextTree());

                }
                stream_database_name.reset();

                adaptor.addChild(root_1, root_2);
                }
                adaptor.addChild(root_1, stream_table_name.nextTree());
                // sqljet/src/Sql.g:420:89: ( ^( COLUMNS ( $columns)+ ) )?
                if ( stream_columns.hasNext() ) {
                    // sqljet/src/Sql.g:420:89: ^( COLUMNS ( $columns)+ )
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(COLUMNS, "COLUMNS"), root_2);

                    if ( !(stream_columns.hasNext()) ) {
                        throw new RewriteEarlyExitException();
                    }
                    while ( stream_columns.hasNext() ) {
                        adaptor.addChild(root_2, stream_columns.nextTree());

                    }
                    stream_columns.reset();

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_columns.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "create_index_stmt"

    public static class indexed_column_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "indexed_column"
    // sqljet/src/Sql.g:422:1: indexed_column : column_name= id ( COLLATE collation_name= id )? ( ASC | DESC )? -> ^( $column_name ( ^( COLLATE $collation_name) )? ( ASC )? ( DESC )? ) ;
    public final SqlParser.indexed_column_return indexed_column() throws RecognitionException {
        SqlParser.indexed_column_return retval = new SqlParser.indexed_column_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token COLLATE435=null;
        Token ASC436=null;
        Token DESC437=null;
        SqlParser.id_return column_name = null;

        SqlParser.id_return collation_name = null;


        Object COLLATE435_tree=null;
        Object ASC436_tree=null;
        Object DESC437_tree=null;
        RewriteRuleTokenStream stream_DESC=new RewriteRuleTokenStream(adaptor,"token DESC");
        RewriteRuleTokenStream stream_COLLATE=new RewriteRuleTokenStream(adaptor,"token COLLATE");
        RewriteRuleTokenStream stream_ASC=new RewriteRuleTokenStream(adaptor,"token ASC");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:422:15: (column_name= id ( COLLATE collation_name= id )? ( ASC | DESC )? -> ^( $column_name ( ^( COLLATE $collation_name) )? ( ASC )? ( DESC )? ) )
            // sqljet/src/Sql.g:422:17: column_name= id ( COLLATE collation_name= id )? ( ASC | DESC )?
            {
            pushFollow(FOLLOW_id_in_indexed_column3719);
            column_name=id();

            state._fsp--;

            stream_id.add(column_name.getTree());
            // sqljet/src/Sql.g:422:32: ( COLLATE collation_name= id )?
            int alt159=2;
            int LA159_0 = input.LA(1);

            if ( (LA159_0==COLLATE) ) {
                alt159=1;
            }
            switch (alt159) {
                case 1 :
                    // sqljet/src/Sql.g:422:33: COLLATE collation_name= id
                    {
                    COLLATE435=(Token)match(input,COLLATE,FOLLOW_COLLATE_in_indexed_column3722);  
                    stream_COLLATE.add(COLLATE435);

                    pushFollow(FOLLOW_id_in_indexed_column3726);
                    collation_name=id();

                    state._fsp--;

                    stream_id.add(collation_name.getTree());

                    }
                    break;

            }

            // sqljet/src/Sql.g:422:61: ( ASC | DESC )?
            int alt160=3;
            int LA160_0 = input.LA(1);

            if ( (LA160_0==ASC) ) {
                alt160=1;
            }
            else if ( (LA160_0==DESC) ) {
                alt160=2;
            }
            switch (alt160) {
                case 1 :
                    // sqljet/src/Sql.g:422:62: ASC
                    {
                    ASC436=(Token)match(input,ASC,FOLLOW_ASC_in_indexed_column3731);  
                    stream_ASC.add(ASC436);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:422:68: DESC
                    {
                    DESC437=(Token)match(input,DESC,FOLLOW_DESC_in_indexed_column3735);  
                    stream_DESC.add(DESC437);


                    }
                    break;

            }



            // AST REWRITE
            // elements: DESC, ASC, COLLATE, column_name, collation_name
            // token labels: 
            // rule labels: collation_name, column_name, retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_collation_name=new RewriteRuleSubtreeStream(adaptor,"rule collation_name",collation_name!=null?collation_name.tree:null);
            RewriteRuleSubtreeStream stream_column_name=new RewriteRuleSubtreeStream(adaptor,"rule column_name",column_name!=null?column_name.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 423:1: -> ^( $column_name ( ^( COLLATE $collation_name) )? ( ASC )? ( DESC )? )
            {
                // sqljet/src/Sql.g:423:4: ^( $column_name ( ^( COLLATE $collation_name) )? ( ASC )? ( DESC )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_column_name.nextNode(), root_1);

                // sqljet/src/Sql.g:423:19: ( ^( COLLATE $collation_name) )?
                if ( stream_COLLATE.hasNext()||stream_collation_name.hasNext() ) {
                    // sqljet/src/Sql.g:423:19: ^( COLLATE $collation_name)
                    {
                    Object root_2 = (Object)adaptor.nil();
                    root_2 = (Object)adaptor.becomeRoot(stream_COLLATE.nextNode(), root_2);

                    adaptor.addChild(root_2, stream_collation_name.nextTree());

                    adaptor.addChild(root_1, root_2);
                    }

                }
                stream_COLLATE.reset();
                stream_collation_name.reset();
                // sqljet/src/Sql.g:423:47: ( ASC )?
                if ( stream_ASC.hasNext() ) {
                    adaptor.addChild(root_1, stream_ASC.nextNode());

                }
                stream_ASC.reset();
                // sqljet/src/Sql.g:423:52: ( DESC )?
                if ( stream_DESC.hasNext() ) {
                    adaptor.addChild(root_1, stream_DESC.nextNode());

                }
                stream_DESC.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "indexed_column"

    public static class drop_index_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "drop_index_stmt"
    // sqljet/src/Sql.g:426:1: drop_index_stmt : DROP INDEX ( IF EXISTS )? (database_name= id DOT )? index_name= id -> ^( DROP_INDEX ^( OPTIONS ( EXISTS )? ) ^( $index_name ( $database_name)? ) ) ;
    public final SqlParser.drop_index_stmt_return drop_index_stmt() throws RecognitionException {
        SqlParser.drop_index_stmt_return retval = new SqlParser.drop_index_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DROP438=null;
        Token INDEX439=null;
        Token IF440=null;
        Token EXISTS441=null;
        Token DOT442=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return index_name = null;


        Object DROP438_tree=null;
        Object INDEX439_tree=null;
        Object IF440_tree=null;
        Object EXISTS441_tree=null;
        Object DOT442_tree=null;
        RewriteRuleTokenStream stream_INDEX=new RewriteRuleTokenStream(adaptor,"token INDEX");
        RewriteRuleTokenStream stream_EXISTS=new RewriteRuleTokenStream(adaptor,"token EXISTS");
        RewriteRuleTokenStream stream_DROP=new RewriteRuleTokenStream(adaptor,"token DROP");
        RewriteRuleTokenStream stream_IF=new RewriteRuleTokenStream(adaptor,"token IF");
        RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
        RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id");
        try {
            // sqljet/src/Sql.g:426:16: ( DROP INDEX ( IF EXISTS )? (database_name= id DOT )? index_name= id -> ^( DROP_INDEX ^( OPTIONS ( EXISTS )? ) ^( $index_name ( $database_name)? ) ) )
            // sqljet/src/Sql.g:426:18: DROP INDEX ( IF EXISTS )? (database_name= id DOT )? index_name= id
            {
            DROP438=(Token)match(input,DROP,FOLLOW_DROP_in_drop_index_stmt3766);  
            stream_DROP.add(DROP438);

            INDEX439=(Token)match(input,INDEX,FOLLOW_INDEX_in_drop_index_stmt3768);  
            stream_INDEX.add(INDEX439);

            // sqljet/src/Sql.g:426:29: ( IF EXISTS )?
            int alt161=2;
            int LA161_0 = input.LA(1);

            if ( (LA161_0==IF) ) {
                int LA161_1 = input.LA(2);

                if ( (LA161_1==EXISTS) ) {
                    alt161=1;
                }
            }
            switch (alt161) {
                case 1 :
                    // sqljet/src/Sql.g:426:30: IF EXISTS
                    {
                    IF440=(Token)match(input,IF,FOLLOW_IF_in_drop_index_stmt3771);  
                    stream_IF.add(IF440);

                    EXISTS441=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_drop_index_stmt3773);  
                    stream_EXISTS.add(EXISTS441);


                    }
                    break;

            }

            // sqljet/src/Sql.g:426:42: (database_name= id DOT )?
            int alt162=2;
            int LA162_0 = input.LA(1);

            if ( (LA162_0==ID) ) {
                int LA162_1 = input.LA(2);

                if ( (LA162_1==DOT) ) {
                    alt162=1;
                }
            }
            else if ( ((LA162_0>=EXPLAIN && LA162_0<=PLAN)||(LA162_0>=INDEXED && LA162_0<=BY)||(LA162_0>=OR && LA162_0<=ESCAPE)||(LA162_0>=IS && LA162_0<=BETWEEN)||LA162_0==COLLATE||(LA162_0>=DISTINCT && LA162_0<=THEN)||(LA162_0>=CURRENT_TIME && LA162_0<=CURRENT_TIMESTAMP)||(LA162_0>=RAISE && LA162_0<=ROW)) ) {
                int LA162_2 = input.LA(2);

                if ( (LA162_2==DOT) ) {
                    alt162=1;
                }
            }
            switch (alt162) {
                case 1 :
                    // sqljet/src/Sql.g:426:43: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_drop_index_stmt3780);
                    database_name=id();

                    state._fsp--;

                    stream_id.add(database_name.getTree());
                    DOT442=(Token)match(input,DOT,FOLLOW_DOT_in_drop_index_stmt3782);  
                    stream_DOT.add(DOT442);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_drop_index_stmt3788);
            index_name=id();

            state._fsp--;

            stream_id.add(index_name.getTree());


            // AST REWRITE
            // elements: EXISTS, database_name, index_name
            // token labels: 
            // rule labels: index_name, database_name, retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_index_name=new RewriteRuleSubtreeStream(adaptor,"rule index_name",index_name!=null?index_name.tree:null);
            RewriteRuleSubtreeStream stream_database_name=new RewriteRuleSubtreeStream(adaptor,"rule database_name",database_name!=null?database_name.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 427:1: -> ^( DROP_INDEX ^( OPTIONS ( EXISTS )? ) ^( $index_name ( $database_name)? ) )
            {
                // sqljet/src/Sql.g:427:4: ^( DROP_INDEX ^( OPTIONS ( EXISTS )? ) ^( $index_name ( $database_name)? ) )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(DROP_INDEX, "DROP_INDEX"), root_1);

                // sqljet/src/Sql.g:427:17: ^( OPTIONS ( EXISTS )? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot((Object)adaptor.create(OPTIONS, "OPTIONS"), root_2);

                // sqljet/src/Sql.g:427:27: ( EXISTS )?
                if ( stream_EXISTS.hasNext() ) {
                    adaptor.addChild(root_2, stream_EXISTS.nextNode());

                }
                stream_EXISTS.reset();

                adaptor.addChild(root_1, root_2);
                }
                // sqljet/src/Sql.g:427:36: ^( $index_name ( $database_name)? )
                {
                Object root_2 = (Object)adaptor.nil();
                root_2 = (Object)adaptor.becomeRoot(stream_index_name.nextNode(), root_2);

                // sqljet/src/Sql.g:427:50: ( $database_name)?
                if ( stream_database_name.hasNext() ) {
                    adaptor.addChild(root_2, stream_database_name.nextTree());

                }
                stream_database_name.reset();

                adaptor.addChild(root_1, root_2);
                }

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "drop_index_stmt"

    public static class create_trigger_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "create_trigger_stmt"
    // sqljet/src/Sql.g:430:1: create_trigger_stmt : CREATE ( TEMPORARY )? TRIGGER ( IF NOT EXISTS )? (database_name= id DOT )? trigger_name= id ( BEFORE | AFTER | INSTEAD OF )? ( DELETE | INSERT | UPDATE ( OF column_names+= id ( COMMA column_names+= id )* )? ) ON table_name= id ( FOR EACH ROW )? ( WHEN expr )? BEGIN ( ( update_stmt | insert_stmt | delete_stmt | select_stmt ) SEMI )+ END ;
    public final SqlParser.create_trigger_stmt_return create_trigger_stmt() throws RecognitionException {
        SqlParser.create_trigger_stmt_return retval = new SqlParser.create_trigger_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token CREATE443=null;
        Token TEMPORARY444=null;
        Token TRIGGER445=null;
        Token IF446=null;
        Token NOT447=null;
        Token EXISTS448=null;
        Token DOT449=null;
        Token BEFORE450=null;
        Token AFTER451=null;
        Token INSTEAD452=null;
        Token OF453=null;
        Token DELETE454=null;
        Token INSERT455=null;
        Token UPDATE456=null;
        Token OF457=null;
        Token COMMA458=null;
        Token ON459=null;
        Token FOR460=null;
        Token EACH461=null;
        Token ROW462=null;
        Token WHEN463=null;
        Token BEGIN465=null;
        Token SEMI470=null;
        Token END471=null;
        List list_column_names=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return trigger_name = null;

        SqlParser.id_return table_name = null;

        SqlParser.expr_return expr464 = null;

        SqlParser.update_stmt_return update_stmt466 = null;

        SqlParser.insert_stmt_return insert_stmt467 = null;

        SqlParser.delete_stmt_return delete_stmt468 = null;

        SqlParser.select_stmt_return select_stmt469 = null;

        SqlParser.id_return column_names = null;
         column_names = null;
        Object CREATE443_tree=null;
        Object TEMPORARY444_tree=null;
        Object TRIGGER445_tree=null;
        Object IF446_tree=null;
        Object NOT447_tree=null;
        Object EXISTS448_tree=null;
        Object DOT449_tree=null;
        Object BEFORE450_tree=null;
        Object AFTER451_tree=null;
        Object INSTEAD452_tree=null;
        Object OF453_tree=null;
        Object DELETE454_tree=null;
        Object INSERT455_tree=null;
        Object UPDATE456_tree=null;
        Object OF457_tree=null;
        Object COMMA458_tree=null;
        Object ON459_tree=null;
        Object FOR460_tree=null;
        Object EACH461_tree=null;
        Object ROW462_tree=null;
        Object WHEN463_tree=null;
        Object BEGIN465_tree=null;
        Object SEMI470_tree=null;
        Object END471_tree=null;

        try {
            // sqljet/src/Sql.g:430:20: ( CREATE ( TEMPORARY )? TRIGGER ( IF NOT EXISTS )? (database_name= id DOT )? trigger_name= id ( BEFORE | AFTER | INSTEAD OF )? ( DELETE | INSERT | UPDATE ( OF column_names+= id ( COMMA column_names+= id )* )? ) ON table_name= id ( FOR EACH ROW )? ( WHEN expr )? BEGIN ( ( update_stmt | insert_stmt | delete_stmt | select_stmt ) SEMI )+ END )
            // sqljet/src/Sql.g:430:22: CREATE ( TEMPORARY )? TRIGGER ( IF NOT EXISTS )? (database_name= id DOT )? trigger_name= id ( BEFORE | AFTER | INSTEAD OF )? ( DELETE | INSERT | UPDATE ( OF column_names+= id ( COMMA column_names+= id )* )? ) ON table_name= id ( FOR EACH ROW )? ( WHEN expr )? BEGIN ( ( update_stmt | insert_stmt | delete_stmt | select_stmt ) SEMI )+ END
            {
            root_0 = (Object)adaptor.nil();

            CREATE443=(Token)match(input,CREATE,FOLLOW_CREATE_in_create_trigger_stmt3818); 
            CREATE443_tree = (Object)adaptor.create(CREATE443);
            adaptor.addChild(root_0, CREATE443_tree);

            // sqljet/src/Sql.g:430:29: ( TEMPORARY )?
            int alt163=2;
            int LA163_0 = input.LA(1);

            if ( (LA163_0==TEMPORARY) ) {
                alt163=1;
            }
            switch (alt163) {
                case 1 :
                    // sqljet/src/Sql.g:430:29: TEMPORARY
                    {
                    TEMPORARY444=(Token)match(input,TEMPORARY,FOLLOW_TEMPORARY_in_create_trigger_stmt3820); 
                    TEMPORARY444_tree = (Object)adaptor.create(TEMPORARY444);
                    adaptor.addChild(root_0, TEMPORARY444_tree);


                    }
                    break;

            }

            TRIGGER445=(Token)match(input,TRIGGER,FOLLOW_TRIGGER_in_create_trigger_stmt3823); 
            TRIGGER445_tree = (Object)adaptor.create(TRIGGER445);
            adaptor.addChild(root_0, TRIGGER445_tree);

            // sqljet/src/Sql.g:430:48: ( IF NOT EXISTS )?
            int alt164=2;
            alt164 = dfa164.predict(input);
            switch (alt164) {
                case 1 :
                    // sqljet/src/Sql.g:430:49: IF NOT EXISTS
                    {
                    IF446=(Token)match(input,IF,FOLLOW_IF_in_create_trigger_stmt3826); 
                    IF446_tree = (Object)adaptor.create(IF446);
                    adaptor.addChild(root_0, IF446_tree);

                    NOT447=(Token)match(input,NOT,FOLLOW_NOT_in_create_trigger_stmt3828); 
                    NOT447_tree = (Object)adaptor.create(NOT447);
                    adaptor.addChild(root_0, NOT447_tree);

                    EXISTS448=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_create_trigger_stmt3830); 
                    EXISTS448_tree = (Object)adaptor.create(EXISTS448);
                    adaptor.addChild(root_0, EXISTS448_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:430:65: (database_name= id DOT )?
            int alt165=2;
            alt165 = dfa165.predict(input);
            switch (alt165) {
                case 1 :
                    // sqljet/src/Sql.g:430:66: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_create_trigger_stmt3837);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT449=(Token)match(input,DOT,FOLLOW_DOT_in_create_trigger_stmt3839); 
                    DOT449_tree = (Object)adaptor.create(DOT449);
                    adaptor.addChild(root_0, DOT449_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_create_trigger_stmt3845);
            trigger_name=id();

            state._fsp--;

            adaptor.addChild(root_0, trigger_name.getTree());
            // sqljet/src/Sql.g:431:3: ( BEFORE | AFTER | INSTEAD OF )?
            int alt166=4;
            switch ( input.LA(1) ) {
                case BEFORE:
                    {
                    alt166=1;
                    }
                    break;
                case AFTER:
                    {
                    alt166=2;
                    }
                    break;
                case INSTEAD:
                    {
                    alt166=3;
                    }
                    break;
            }

            switch (alt166) {
                case 1 :
                    // sqljet/src/Sql.g:431:4: BEFORE
                    {
                    BEFORE450=(Token)match(input,BEFORE,FOLLOW_BEFORE_in_create_trigger_stmt3850); 
                    BEFORE450_tree = (Object)adaptor.create(BEFORE450);
                    adaptor.addChild(root_0, BEFORE450_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:431:13: AFTER
                    {
                    AFTER451=(Token)match(input,AFTER,FOLLOW_AFTER_in_create_trigger_stmt3854); 
                    AFTER451_tree = (Object)adaptor.create(AFTER451);
                    adaptor.addChild(root_0, AFTER451_tree);


                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:431:21: INSTEAD OF
                    {
                    INSTEAD452=(Token)match(input,INSTEAD,FOLLOW_INSTEAD_in_create_trigger_stmt3858); 
                    INSTEAD452_tree = (Object)adaptor.create(INSTEAD452);
                    adaptor.addChild(root_0, INSTEAD452_tree);

                    OF453=(Token)match(input,OF,FOLLOW_OF_in_create_trigger_stmt3860); 
                    OF453_tree = (Object)adaptor.create(OF453);
                    adaptor.addChild(root_0, OF453_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:431:34: ( DELETE | INSERT | UPDATE ( OF column_names+= id ( COMMA column_names+= id )* )? )
            int alt169=3;
            switch ( input.LA(1) ) {
            case DELETE:
                {
                alt169=1;
                }
                break;
            case INSERT:
                {
                alt169=2;
                }
                break;
            case UPDATE:
                {
                alt169=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 169, 0, input);

                throw nvae;
            }

            switch (alt169) {
                case 1 :
                    // sqljet/src/Sql.g:431:35: DELETE
                    {
                    DELETE454=(Token)match(input,DELETE,FOLLOW_DELETE_in_create_trigger_stmt3865); 
                    DELETE454_tree = (Object)adaptor.create(DELETE454);
                    adaptor.addChild(root_0, DELETE454_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:431:44: INSERT
                    {
                    INSERT455=(Token)match(input,INSERT,FOLLOW_INSERT_in_create_trigger_stmt3869); 
                    INSERT455_tree = (Object)adaptor.create(INSERT455);
                    adaptor.addChild(root_0, INSERT455_tree);


                    }
                    break;
                case 3 :
                    // sqljet/src/Sql.g:431:53: UPDATE ( OF column_names+= id ( COMMA column_names+= id )* )?
                    {
                    UPDATE456=(Token)match(input,UPDATE,FOLLOW_UPDATE_in_create_trigger_stmt3873); 
                    UPDATE456_tree = (Object)adaptor.create(UPDATE456);
                    adaptor.addChild(root_0, UPDATE456_tree);

                    // sqljet/src/Sql.g:431:60: ( OF column_names+= id ( COMMA column_names+= id )* )?
                    int alt168=2;
                    int LA168_0 = input.LA(1);

                    if ( (LA168_0==OF) ) {
                        alt168=1;
                    }
                    switch (alt168) {
                        case 1 :
                            // sqljet/src/Sql.g:431:61: OF column_names+= id ( COMMA column_names+= id )*
                            {
                            OF457=(Token)match(input,OF,FOLLOW_OF_in_create_trigger_stmt3876); 
                            OF457_tree = (Object)adaptor.create(OF457);
                            adaptor.addChild(root_0, OF457_tree);

                            pushFollow(FOLLOW_id_in_create_trigger_stmt3880);
                            column_names=id();

                            state._fsp--;

                            adaptor.addChild(root_0, column_names.getTree());
                            if (list_column_names==null) list_column_names=new ArrayList();
                            list_column_names.add(column_names.getTree());

                            // sqljet/src/Sql.g:431:81: ( COMMA column_names+= id )*
                            loop167:
                            do {
                                int alt167=2;
                                int LA167_0 = input.LA(1);

                                if ( (LA167_0==COMMA) ) {
                                    alt167=1;
                                }


                                switch (alt167) {
                            	case 1 :
                            	    // sqljet/src/Sql.g:431:82: COMMA column_names+= id
                            	    {
                            	    COMMA458=(Token)match(input,COMMA,FOLLOW_COMMA_in_create_trigger_stmt3883); 
                            	    COMMA458_tree = (Object)adaptor.create(COMMA458);
                            	    adaptor.addChild(root_0, COMMA458_tree);

                            	    pushFollow(FOLLOW_id_in_create_trigger_stmt3887);
                            	    column_names=id();

                            	    state._fsp--;

                            	    adaptor.addChild(root_0, column_names.getTree());
                            	    if (list_column_names==null) list_column_names=new ArrayList();
                            	    list_column_names.add(column_names.getTree());


                            	    }
                            	    break;

                            	default :
                            	    break loop167;
                                }
                            } while (true);


                            }
                            break;

                    }


                    }
                    break;

            }

            ON459=(Token)match(input,ON,FOLLOW_ON_in_create_trigger_stmt3896); 
            ON459_tree = (Object)adaptor.create(ON459);
            adaptor.addChild(root_0, ON459_tree);

            pushFollow(FOLLOW_id_in_create_trigger_stmt3900);
            table_name=id();

            state._fsp--;

            adaptor.addChild(root_0, table_name.getTree());
            // sqljet/src/Sql.g:432:20: ( FOR EACH ROW )?
            int alt170=2;
            int LA170_0 = input.LA(1);

            if ( (LA170_0==FOR) ) {
                alt170=1;
            }
            switch (alt170) {
                case 1 :
                    // sqljet/src/Sql.g:432:21: FOR EACH ROW
                    {
                    FOR460=(Token)match(input,FOR,FOLLOW_FOR_in_create_trigger_stmt3903); 
                    FOR460_tree = (Object)adaptor.create(FOR460);
                    adaptor.addChild(root_0, FOR460_tree);

                    EACH461=(Token)match(input,EACH,FOLLOW_EACH_in_create_trigger_stmt3905); 
                    EACH461_tree = (Object)adaptor.create(EACH461);
                    adaptor.addChild(root_0, EACH461_tree);

                    ROW462=(Token)match(input,ROW,FOLLOW_ROW_in_create_trigger_stmt3907); 
                    ROW462_tree = (Object)adaptor.create(ROW462);
                    adaptor.addChild(root_0, ROW462_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:432:36: ( WHEN expr )?
            int alt171=2;
            int LA171_0 = input.LA(1);

            if ( (LA171_0==WHEN) ) {
                alt171=1;
            }
            switch (alt171) {
                case 1 :
                    // sqljet/src/Sql.g:432:37: WHEN expr
                    {
                    WHEN463=(Token)match(input,WHEN,FOLLOW_WHEN_in_create_trigger_stmt3912); 
                    WHEN463_tree = (Object)adaptor.create(WHEN463);
                    adaptor.addChild(root_0, WHEN463_tree);

                    pushFollow(FOLLOW_expr_in_create_trigger_stmt3914);
                    expr464=expr();

                    state._fsp--;

                    adaptor.addChild(root_0, expr464.getTree());

                    }
                    break;

            }

            BEGIN465=(Token)match(input,BEGIN,FOLLOW_BEGIN_in_create_trigger_stmt3920); 
            BEGIN465_tree = (Object)adaptor.create(BEGIN465);
            adaptor.addChild(root_0, BEGIN465_tree);

            // sqljet/src/Sql.g:433:9: ( ( update_stmt | insert_stmt | delete_stmt | select_stmt ) SEMI )+
            int cnt173=0;
            loop173:
            do {
                int alt173=2;
                int LA173_0 = input.LA(1);

                if ( (LA173_0==REPLACE||LA173_0==SELECT||LA173_0==INSERT||LA173_0==UPDATE||LA173_0==DELETE) ) {
                    alt173=1;
                }


                switch (alt173) {
            	case 1 :
            	    // sqljet/src/Sql.g:433:10: ( update_stmt | insert_stmt | delete_stmt | select_stmt ) SEMI
            	    {
            	    // sqljet/src/Sql.g:433:10: ( update_stmt | insert_stmt | delete_stmt | select_stmt )
            	    int alt172=4;
            	    switch ( input.LA(1) ) {
            	    case UPDATE:
            	        {
            	        alt172=1;
            	        }
            	        break;
            	    case REPLACE:
            	    case INSERT:
            	        {
            	        alt172=2;
            	        }
            	        break;
            	    case DELETE:
            	        {
            	        alt172=3;
            	        }
            	        break;
            	    case SELECT:
            	        {
            	        alt172=4;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 172, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt172) {
            	        case 1 :
            	            // sqljet/src/Sql.g:433:11: update_stmt
            	            {
            	            pushFollow(FOLLOW_update_stmt_in_create_trigger_stmt3924);
            	            update_stmt466=update_stmt();

            	            state._fsp--;

            	            adaptor.addChild(root_0, update_stmt466.getTree());

            	            }
            	            break;
            	        case 2 :
            	            // sqljet/src/Sql.g:433:25: insert_stmt
            	            {
            	            pushFollow(FOLLOW_insert_stmt_in_create_trigger_stmt3928);
            	            insert_stmt467=insert_stmt();

            	            state._fsp--;

            	            adaptor.addChild(root_0, insert_stmt467.getTree());

            	            }
            	            break;
            	        case 3 :
            	            // sqljet/src/Sql.g:433:39: delete_stmt
            	            {
            	            pushFollow(FOLLOW_delete_stmt_in_create_trigger_stmt3932);
            	            delete_stmt468=delete_stmt();

            	            state._fsp--;

            	            adaptor.addChild(root_0, delete_stmt468.getTree());

            	            }
            	            break;
            	        case 4 :
            	            // sqljet/src/Sql.g:433:53: select_stmt
            	            {
            	            pushFollow(FOLLOW_select_stmt_in_create_trigger_stmt3936);
            	            select_stmt469=select_stmt();

            	            state._fsp--;

            	            adaptor.addChild(root_0, select_stmt469.getTree());

            	            }
            	            break;

            	    }

            	    SEMI470=(Token)match(input,SEMI,FOLLOW_SEMI_in_create_trigger_stmt3939); 
            	    SEMI470_tree = (Object)adaptor.create(SEMI470);
            	    adaptor.addChild(root_0, SEMI470_tree);


            	    }
            	    break;

            	default :
            	    if ( cnt173 >= 1 ) break loop173;
                        EarlyExitException eee =
                            new EarlyExitException(173, input);
                        throw eee;
                }
                cnt173++;
            } while (true);

            END471=(Token)match(input,END,FOLLOW_END_in_create_trigger_stmt3943); 
            END471_tree = (Object)adaptor.create(END471);
            adaptor.addChild(root_0, END471_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "create_trigger_stmt"

    public static class drop_trigger_stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "drop_trigger_stmt"
    // sqljet/src/Sql.g:436:1: drop_trigger_stmt : DROP TRIGGER ( IF EXISTS )? (database_name= id DOT )? trigger_name= id ;
    public final SqlParser.drop_trigger_stmt_return drop_trigger_stmt() throws RecognitionException {
        SqlParser.drop_trigger_stmt_return retval = new SqlParser.drop_trigger_stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token DROP472=null;
        Token TRIGGER473=null;
        Token IF474=null;
        Token EXISTS475=null;
        Token DOT476=null;
        SqlParser.id_return database_name = null;

        SqlParser.id_return trigger_name = null;


        Object DROP472_tree=null;
        Object TRIGGER473_tree=null;
        Object IF474_tree=null;
        Object EXISTS475_tree=null;
        Object DOT476_tree=null;

        try {
            // sqljet/src/Sql.g:436:18: ( DROP TRIGGER ( IF EXISTS )? (database_name= id DOT )? trigger_name= id )
            // sqljet/src/Sql.g:436:20: DROP TRIGGER ( IF EXISTS )? (database_name= id DOT )? trigger_name= id
            {
            root_0 = (Object)adaptor.nil();

            DROP472=(Token)match(input,DROP,FOLLOW_DROP_in_drop_trigger_stmt3951); 
            DROP472_tree = (Object)adaptor.create(DROP472);
            adaptor.addChild(root_0, DROP472_tree);

            TRIGGER473=(Token)match(input,TRIGGER,FOLLOW_TRIGGER_in_drop_trigger_stmt3953); 
            TRIGGER473_tree = (Object)adaptor.create(TRIGGER473);
            adaptor.addChild(root_0, TRIGGER473_tree);

            // sqljet/src/Sql.g:436:33: ( IF EXISTS )?
            int alt174=2;
            int LA174_0 = input.LA(1);

            if ( (LA174_0==IF) ) {
                int LA174_1 = input.LA(2);

                if ( (LA174_1==EXISTS) ) {
                    alt174=1;
                }
            }
            switch (alt174) {
                case 1 :
                    // sqljet/src/Sql.g:436:34: IF EXISTS
                    {
                    IF474=(Token)match(input,IF,FOLLOW_IF_in_drop_trigger_stmt3956); 
                    IF474_tree = (Object)adaptor.create(IF474);
                    adaptor.addChild(root_0, IF474_tree);

                    EXISTS475=(Token)match(input,EXISTS,FOLLOW_EXISTS_in_drop_trigger_stmt3958); 
                    EXISTS475_tree = (Object)adaptor.create(EXISTS475);
                    adaptor.addChild(root_0, EXISTS475_tree);


                    }
                    break;

            }

            // sqljet/src/Sql.g:436:46: (database_name= id DOT )?
            int alt175=2;
            int LA175_0 = input.LA(1);

            if ( (LA175_0==ID) ) {
                int LA175_1 = input.LA(2);

                if ( (LA175_1==DOT) ) {
                    alt175=1;
                }
            }
            else if ( ((LA175_0>=EXPLAIN && LA175_0<=PLAN)||(LA175_0>=INDEXED && LA175_0<=BY)||(LA175_0>=OR && LA175_0<=ESCAPE)||(LA175_0>=IS && LA175_0<=BETWEEN)||LA175_0==COLLATE||(LA175_0>=DISTINCT && LA175_0<=THEN)||(LA175_0>=CURRENT_TIME && LA175_0<=CURRENT_TIMESTAMP)||(LA175_0>=RAISE && LA175_0<=ROW)) ) {
                int LA175_2 = input.LA(2);

                if ( (LA175_2==DOT) ) {
                    alt175=1;
                }
            }
            switch (alt175) {
                case 1 :
                    // sqljet/src/Sql.g:436:47: database_name= id DOT
                    {
                    pushFollow(FOLLOW_id_in_drop_trigger_stmt3965);
                    database_name=id();

                    state._fsp--;

                    adaptor.addChild(root_0, database_name.getTree());
                    DOT476=(Token)match(input,DOT,FOLLOW_DOT_in_drop_trigger_stmt3967); 
                    DOT476_tree = (Object)adaptor.create(DOT476);
                    adaptor.addChild(root_0, DOT476_tree);


                    }
                    break;

            }

            pushFollow(FOLLOW_id_in_drop_trigger_stmt3973);
            trigger_name=id();

            state._fsp--;

            adaptor.addChild(root_0, trigger_name.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "drop_trigger_stmt"

    public static class id_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "id"
    // sqljet/src/Sql.g:441:1: id : ( ID | keyword );
    public final SqlParser.id_return id() throws RecognitionException {
        SqlParser.id_return retval = new SqlParser.id_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ID477=null;
        SqlParser.keyword_return keyword478 = null;


        Object ID477_tree=null;

        try {
            // sqljet/src/Sql.g:441:3: ( ID | keyword )
            int alt176=2;
            int LA176_0 = input.LA(1);

            if ( (LA176_0==ID) ) {
                alt176=1;
            }
            else if ( ((LA176_0>=EXPLAIN && LA176_0<=PLAN)||(LA176_0>=INDEXED && LA176_0<=BY)||(LA176_0>=OR && LA176_0<=ESCAPE)||(LA176_0>=IS && LA176_0<=BETWEEN)||LA176_0==COLLATE||(LA176_0>=DISTINCT && LA176_0<=THEN)||(LA176_0>=CURRENT_TIME && LA176_0<=CURRENT_TIMESTAMP)||(LA176_0>=RAISE && LA176_0<=ROW)) ) {
                alt176=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 176, 0, input);

                throw nvae;
            }
            switch (alt176) {
                case 1 :
                    // sqljet/src/Sql.g:441:5: ID
                    {
                    root_0 = (Object)adaptor.nil();

                    ID477=(Token)match(input,ID,FOLLOW_ID_in_id3983); 
                    ID477_tree = (Object)adaptor.create(ID477);
                    adaptor.addChild(root_0, ID477_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:441:10: keyword
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_keyword_in_id3987);
                    keyword478=keyword();

                    state._fsp--;

                    adaptor.addChild(root_0, keyword478.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "id"

    public static class keyword_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "keyword"
    // sqljet/src/Sql.g:443:1: keyword : ( ABORT | ADD | AFTER | ALL | ALTER | ANALYZE | AND | AS | ASC | ATTACH | AUTOINCREMENT | BEFORE | BEGIN | BETWEEN | BY | CASCADE | CASE | CAST | CHECK | COLLATE | COLUMN | COMMIT | CONFLICT | CONSTRAINT | CREATE | CROSS | CURRENT_TIME | CURRENT_DATE | CURRENT_TIMESTAMP | DATABASE | DEFAULT | DEFERRABLE | DEFERRED | DELETE | DESC | DETACH | DISTINCT | DROP | EACH | ELSE | END | ESCAPE | EXCEPT | EXCLUSIVE | EXISTS | EXPLAIN | FAIL | FOR | FOREIGN | FROM | GROUP | HAVING | IF | IGNORE | IMMEDIATE | INDEX | INDEXED | INITIALLY | INNER | INSERT | INSTEAD | INTERSECT | INTO | IS | JOIN | KEY | LEFT | LIMIT | NATURAL | NULL | OF | OFFSET | ON | OR | ORDER | OUTER | PLAN | PRAGMA | PRIMARY | QUERY | RAISE | REFERENCES | REINDEX | RELEASE | RENAME | REPLACE | RESTRICT | ROLLBACK | ROW | SAVEPOINT | SELECT | SET | TABLE | TEMPORARY | THEN | TO | TRANSACTION | TRIGGER | UNION | UNIQUE | UPDATE | USING | VACUUM | VALUES | VIEW | VIRTUAL | WHEN | WHERE ) ;
    public final SqlParser.keyword_return keyword() throws RecognitionException {
        SqlParser.keyword_return retval = new SqlParser.keyword_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set479=null;

        Object set479_tree=null;

        try {
            // sqljet/src/Sql.g:443:8: ( ( ABORT | ADD | AFTER | ALL | ALTER | ANALYZE | AND | AS | ASC | ATTACH | AUTOINCREMENT | BEFORE | BEGIN | BETWEEN | BY | CASCADE | CASE | CAST | CHECK | COLLATE | COLUMN | COMMIT | CONFLICT | CONSTRAINT | CREATE | CROSS | CURRENT_TIME | CURRENT_DATE | CURRENT_TIMESTAMP | DATABASE | DEFAULT | DEFERRABLE | DEFERRED | DELETE | DESC | DETACH | DISTINCT | DROP | EACH | ELSE | END | ESCAPE | EXCEPT | EXCLUSIVE | EXISTS | EXPLAIN | FAIL | FOR | FOREIGN | FROM | GROUP | HAVING | IF | IGNORE | IMMEDIATE | INDEX | INDEXED | INITIALLY | INNER | INSERT | INSTEAD | INTERSECT | INTO | IS | JOIN | KEY | LEFT | LIMIT | NATURAL | NULL | OF | OFFSET | ON | OR | ORDER | OUTER | PLAN | PRAGMA | PRIMARY | QUERY | RAISE | REFERENCES | REINDEX | RELEASE | RENAME | REPLACE | RESTRICT | ROLLBACK | ROW | SAVEPOINT | SELECT | SET | TABLE | TEMPORARY | THEN | TO | TRANSACTION | TRIGGER | UNION | UNIQUE | UPDATE | USING | VACUUM | VALUES | VIEW | VIRTUAL | WHEN | WHERE ) )
            // sqljet/src/Sql.g:443:10: ( ABORT | ADD | AFTER | ALL | ALTER | ANALYZE | AND | AS | ASC | ATTACH | AUTOINCREMENT | BEFORE | BEGIN | BETWEEN | BY | CASCADE | CASE | CAST | CHECK | COLLATE | COLUMN | COMMIT | CONFLICT | CONSTRAINT | CREATE | CROSS | CURRENT_TIME | CURRENT_DATE | CURRENT_TIMESTAMP | DATABASE | DEFAULT | DEFERRABLE | DEFERRED | DELETE | DESC | DETACH | DISTINCT | DROP | EACH | ELSE | END | ESCAPE | EXCEPT | EXCLUSIVE | EXISTS | EXPLAIN | FAIL | FOR | FOREIGN | FROM | GROUP | HAVING | IF | IGNORE | IMMEDIATE | INDEX | INDEXED | INITIALLY | INNER | INSERT | INSTEAD | INTERSECT | INTO | IS | JOIN | KEY | LEFT | LIMIT | NATURAL | NULL | OF | OFFSET | ON | OR | ORDER | OUTER | PLAN | PRAGMA | PRIMARY | QUERY | RAISE | REFERENCES | REINDEX | RELEASE | RENAME | REPLACE | RESTRICT | ROLLBACK | ROW | SAVEPOINT | SELECT | SET | TABLE | TEMPORARY | THEN | TO | TRANSACTION | TRIGGER | UNION | UNIQUE | UPDATE | USING | VACUUM | VALUES | VIEW | VIRTUAL | WHEN | WHERE )
            {
            root_0 = (Object)adaptor.nil();

            set479=(Token)input.LT(1);
            if ( (input.LA(1)>=EXPLAIN && input.LA(1)<=PLAN)||(input.LA(1)>=INDEXED && input.LA(1)<=BY)||(input.LA(1)>=OR && input.LA(1)<=ESCAPE)||(input.LA(1)>=IS && input.LA(1)<=BETWEEN)||input.LA(1)==COLLATE||(input.LA(1)>=DISTINCT && input.LA(1)<=THEN)||(input.LA(1)>=CURRENT_TIME && input.LA(1)<=CURRENT_TIMESTAMP)||(input.LA(1)>=RAISE && input.LA(1)<=ROW) ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set479));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "keyword"

    public static class id_column_def_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "id_column_def"
    // sqljet/src/Sql.g:562:1: id_column_def : ( ID | keyword_column_def );
    public final SqlParser.id_column_def_return id_column_def() throws RecognitionException {
        SqlParser.id_column_def_return retval = new SqlParser.id_column_def_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ID480=null;
        SqlParser.keyword_column_def_return keyword_column_def481 = null;


        Object ID480_tree=null;

        try {
            // sqljet/src/Sql.g:562:14: ( ID | keyword_column_def )
            int alt177=2;
            int LA177_0 = input.LA(1);

            if ( (LA177_0==ID) ) {
                alt177=1;
            }
            else if ( ((LA177_0>=EXPLAIN && LA177_0<=PLAN)||(LA177_0>=INDEXED && LA177_0<=IN)||(LA177_0>=ISNULL && LA177_0<=BETWEEN)||(LA177_0>=LIKE && LA177_0<=MATCH)||LA177_0==COLLATE||(LA177_0>=DISTINCT && LA177_0<=THEN)||(LA177_0>=CURRENT_TIME && LA177_0<=CURRENT_TIMESTAMP)||(LA177_0>=RAISE && LA177_0<=EXISTS)||(LA177_0>=PRIMARY && LA177_0<=ADD)||(LA177_0>=VIEW && LA177_0<=ROW)) ) {
                alt177=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 177, 0, input);

                throw nvae;
            }
            switch (alt177) {
                case 1 :
                    // sqljet/src/Sql.g:562:16: ID
                    {
                    root_0 = (Object)adaptor.nil();

                    ID480=(Token)match(input,ID,FOLLOW_ID_in_id_column_def4661); 
                    ID480_tree = (Object)adaptor.create(ID480);
                    adaptor.addChild(root_0, ID480_tree);


                    }
                    break;
                case 2 :
                    // sqljet/src/Sql.g:562:21: keyword_column_def
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_keyword_column_def_in_id_column_def4665);
                    keyword_column_def481=keyword_column_def();

                    state._fsp--;

                    adaptor.addChild(root_0, keyword_column_def481.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "id_column_def"

    public static class keyword_column_def_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "keyword_column_def"
    // sqljet/src/Sql.g:564:1: keyword_column_def : ( ABORT | ADD | AFTER | ALL | ALTER | ANALYZE | AND | AS | ASC | ATTACH | AUTOINCREMENT | BEFORE | BEGIN | BETWEEN | BY | CASCADE | CASE | CAST | CHECK | COLLATE | COMMIT | CONFLICT | CREATE | CROSS | CURRENT_TIME | CURRENT_DATE | CURRENT_TIMESTAMP | DATABASE | DEFAULT | DEFERRABLE | DEFERRED | DELETE | DESC | DETACH | DISTINCT | DROP | EACH | ELSE | END | ESCAPE | EXCEPT | EXCLUSIVE | EXISTS | EXPLAIN | FAIL | FOR | FOREIGN | FROM | GLOB | GROUP | HAVING | IF | IGNORE | IMMEDIATE | IN | INDEX | INDEXED | INITIALLY | INNER | INSERT | INSTEAD | INTERSECT | INTO | IS | ISNULL | JOIN | KEY | LEFT | LIKE | LIMIT | MATCH | NATURAL | NOT | NOTNULL | NULL | OF | OFFSET | ON | OR | ORDER | OUTER | PLAN | PRAGMA | PRIMARY | QUERY | RAISE | REFERENCES | REGEXP | REINDEX | RELEASE | RENAME | REPLACE | RESTRICT | ROLLBACK | ROW | SAVEPOINT | SELECT | SET | TABLE | TEMPORARY | THEN | TO | TRANSACTION | TRIGGER | UNION | UNIQUE | UPDATE | USING | VACUUM | VALUES | VIEW | VIRTUAL | WHEN | WHERE ) ;
    public final SqlParser.keyword_column_def_return keyword_column_def() throws RecognitionException {
        SqlParser.keyword_column_def_return retval = new SqlParser.keyword_column_def_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set482=null;

        Object set482_tree=null;

        try {
            // sqljet/src/Sql.g:564:19: ( ( ABORT | ADD | AFTER | ALL | ALTER | ANALYZE | AND | AS | ASC | ATTACH | AUTOINCREMENT | BEFORE | BEGIN | BETWEEN | BY | CASCADE | CASE | CAST | CHECK | COLLATE | COMMIT | CONFLICT | CREATE | CROSS | CURRENT_TIME | CURRENT_DATE | CURRENT_TIMESTAMP | DATABASE | DEFAULT | DEFERRABLE | DEFERRED | DELETE | DESC | DETACH | DISTINCT | DROP | EACH | ELSE | END | ESCAPE | EXCEPT | EXCLUSIVE | EXISTS | EXPLAIN | FAIL | FOR | FOREIGN | FROM | GLOB | GROUP | HAVING | IF | IGNORE | IMMEDIATE | IN | INDEX | INDEXED | INITIALLY | INNER | INSERT | INSTEAD | INTERSECT | INTO | IS | ISNULL | JOIN | KEY | LEFT | LIKE | LIMIT | MATCH | NATURAL | NOT | NOTNULL | NULL | OF | OFFSET | ON | OR | ORDER | OUTER | PLAN | PRAGMA | PRIMARY | QUERY | RAISE | REFERENCES | REGEXP | REINDEX | RELEASE | RENAME | REPLACE | RESTRICT | ROLLBACK | ROW | SAVEPOINT | SELECT | SET | TABLE | TEMPORARY | THEN | TO | TRANSACTION | TRIGGER | UNION | UNIQUE | UPDATE | USING | VACUUM | VALUES | VIEW | VIRTUAL | WHEN | WHERE ) )
            // sqljet/src/Sql.g:564:21: ( ABORT | ADD | AFTER | ALL | ALTER | ANALYZE | AND | AS | ASC | ATTACH | AUTOINCREMENT | BEFORE | BEGIN | BETWEEN | BY | CASCADE | CASE | CAST | CHECK | COLLATE | COMMIT | CONFLICT | CREATE | CROSS | CURRENT_TIME | CURRENT_DATE | CURRENT_TIMESTAMP | DATABASE | DEFAULT | DEFERRABLE | DEFERRED | DELETE | DESC | DETACH | DISTINCT | DROP | EACH | ELSE | END | ESCAPE | EXCEPT | EXCLUSIVE | EXISTS | EXPLAIN | FAIL | FOR | FOREIGN | FROM | GLOB | GROUP | HAVING | IF | IGNORE | IMMEDIATE | IN | INDEX | INDEXED | INITIALLY | INNER | INSERT | INSTEAD | INTERSECT | INTO | IS | ISNULL | JOIN | KEY | LEFT | LIKE | LIMIT | MATCH | NATURAL | NOT | NOTNULL | NULL | OF | OFFSET | ON | OR | ORDER | OUTER | PLAN | PRAGMA | PRIMARY | QUERY | RAISE | REFERENCES | REGEXP | REINDEX | RELEASE | RENAME | REPLACE | RESTRICT | ROLLBACK | ROW | SAVEPOINT | SELECT | SET | TABLE | TEMPORARY | THEN | TO | TRANSACTION | TRIGGER | UNION | UNIQUE | UPDATE | USING | VACUUM | VALUES | VIEW | VIRTUAL | WHEN | WHERE )
            {
            root_0 = (Object)adaptor.nil();

            set482=(Token)input.LT(1);
            if ( (input.LA(1)>=EXPLAIN && input.LA(1)<=PLAN)||(input.LA(1)>=INDEXED && input.LA(1)<=IN)||(input.LA(1)>=ISNULL && input.LA(1)<=BETWEEN)||(input.LA(1)>=LIKE && input.LA(1)<=MATCH)||input.LA(1)==COLLATE||(input.LA(1)>=DISTINCT && input.LA(1)<=THEN)||(input.LA(1)>=CURRENT_TIME && input.LA(1)<=CURRENT_TIMESTAMP)||(input.LA(1)>=RAISE && input.LA(1)<=EXISTS)||(input.LA(1)>=PRIMARY && input.LA(1)<=ADD)||(input.LA(1)>=VIEW && input.LA(1)<=ROW) ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set482));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "keyword_column_def"

    // Delegated rules


    protected DFA1 dfa1 = new DFA1(this);
    protected DFA3 dfa3 = new DFA3(this);
    protected DFA2 dfa2 = new DFA2(this);
    protected DFA4 dfa4 = new DFA4(this);
    protected DFA5 dfa5 = new DFA5(this);
    protected DFA7 dfa7 = new DFA7(this);
    protected DFA8 dfa8 = new DFA8(this);
    protected DFA9 dfa9 = new DFA9(this);
    protected DFA19 dfa19 = new DFA19(this);
    protected DFA11 dfa11 = new DFA11(this);
    protected DFA15 dfa15 = new DFA15(this);
    protected DFA18 dfa18 = new DFA18(this);
    protected DFA20 dfa20 = new DFA20(this);
    protected DFA21 dfa21 = new DFA21(this);
    protected DFA22 dfa22 = new DFA22(this);
    protected DFA23 dfa23 = new DFA23(this);
    protected DFA24 dfa24 = new DFA24(this);
    protected DFA25 dfa25 = new DFA25(this);
    protected DFA26 dfa26 = new DFA26(this);
    protected DFA35 dfa35 = new DFA35(this);
    protected DFA28 dfa28 = new DFA28(this);
    protected DFA27 dfa27 = new DFA27(this);
    protected DFA31 dfa31 = new DFA31(this);
    protected DFA29 dfa29 = new DFA29(this);
    protected DFA32 dfa32 = new DFA32(this);
    protected DFA37 dfa37 = new DFA37(this);
    protected DFA39 dfa39 = new DFA39(this);
    protected DFA41 dfa41 = new DFA41(this);
    protected DFA43 dfa43 = new DFA43(this);
    protected DFA46 dfa46 = new DFA46(this);
    protected DFA51 dfa51 = new DFA51(this);
    protected DFA63 dfa63 = new DFA63(this);
    protected DFA64 dfa64 = new DFA64(this);
    protected DFA65 dfa65 = new DFA65(this);
    protected DFA66 dfa66 = new DFA66(this);
    protected DFA67 dfa67 = new DFA67(this);
    protected DFA72 dfa72 = new DFA72(this);
    protected DFA71 dfa71 = new DFA71(this);
    protected DFA70 dfa70 = new DFA70(this);
    protected DFA74 dfa74 = new DFA74(this);
    protected DFA73 dfa73 = new DFA73(this);
    protected DFA81 dfa81 = new DFA81(this);
    protected DFA75 dfa75 = new DFA75(this);
    protected DFA77 dfa77 = new DFA77(this);
    protected DFA78 dfa78 = new DFA78(this);
    protected DFA80 dfa80 = new DFA80(this);
    protected DFA91 dfa91 = new DFA91(this);
    protected DFA116 dfa116 = new DFA116(this);
    protected DFA119 dfa119 = new DFA119(this);
    protected DFA120 dfa120 = new DFA120(this);
    protected DFA123 dfa123 = new DFA123(this);
    protected DFA124 dfa124 = new DFA124(this);
    protected DFA125 dfa125 = new DFA125(this);
    protected DFA126 dfa126 = new DFA126(this);
    protected DFA127 dfa127 = new DFA127(this);
    protected DFA129 dfa129 = new DFA129(this);
    protected DFA138 dfa138 = new DFA138(this);
    protected DFA139 dfa139 = new DFA139(this);
    protected DFA140 dfa140 = new DFA140(this);
    protected DFA144 dfa144 = new DFA144(this);
    protected DFA164 dfa164 = new DFA164(this);
    protected DFA165 dfa165 = new DFA165(this);
    static final String DFA1_eotS =
        "\26\uffff";
    static final String DFA1_eofS =
        "\1\1\25\uffff";
    static final String DFA1_minS =
        "\1\40\25\uffff";
    static final String DFA1_maxS =
        "\1\u00a6\25\uffff";
    static final String DFA1_acceptS =
        "\1\uffff\1\2\1\1\23\uffff";
    static final String DFA1_specialS =
        "\26\uffff}>";
    static final String[] DFA1_transitionS = {
            "\1\2\61\uffff\1\2\16\uffff\1\2\2\uffff\2\2\1\uffff\5\2\11\uffff"+
            "\1\2\14\uffff\1\2\3\uffff\1\2\1\uffff\2\2\4\uffff\1\2\1\uffff"+
            "\2\2\1\uffff\1\2\21\uffff\2\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA1_eot = DFA.unpackEncodedString(DFA1_eotS);
    static final short[] DFA1_eof = DFA.unpackEncodedString(DFA1_eofS);
    static final char[] DFA1_min = DFA.unpackEncodedStringToUnsignedChars(DFA1_minS);
    static final char[] DFA1_max = DFA.unpackEncodedStringToUnsignedChars(DFA1_maxS);
    static final short[] DFA1_accept = DFA.unpackEncodedString(DFA1_acceptS);
    static final short[] DFA1_special = DFA.unpackEncodedString(DFA1_specialS);
    static final short[][] DFA1_transition;

    static {
        int numStates = DFA1_transitionS.length;
        DFA1_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA1_transition[i] = DFA.unpackEncodedString(DFA1_transitionS[i]);
        }
    }

    class DFA1 extends DFA {

        public DFA1(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 1;
            this.eot = DFA1_eot;
            this.eof = DFA1_eof;
            this.min = DFA1_min;
            this.max = DFA1_max;
            this.accept = DFA1_accept;
            this.special = DFA1_special;
            this.transition = DFA1_transition;
        }
        public String getDescription() {
            return "()+ loopback of 85:16: ( sql_stmt )+";
        }
    }
    static final String DFA3_eotS =
        "\25\uffff";
    static final String DFA3_eofS =
        "\25\uffff";
    static final String DFA3_minS =
        "\1\40\24\uffff";
    static final String DFA3_maxS =
        "\1\u00a6\24\uffff";
    static final String DFA3_acceptS =
        "\1\uffff\1\1\1\2\22\uffff";
    static final String DFA3_specialS =
        "\25\uffff}>";
    static final String[] DFA3_transitionS = {
            "\1\1\61\uffff\1\2\16\uffff\1\2\2\uffff\2\2\1\uffff\5\2\11\uffff"+
            "\1\2\14\uffff\1\2\3\uffff\1\2\1\uffff\2\2\4\uffff\1\2\1\uffff"+
            "\2\2\1\uffff\1\2\21\uffff\2\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA3_eot = DFA.unpackEncodedString(DFA3_eotS);
    static final short[] DFA3_eof = DFA.unpackEncodedString(DFA3_eofS);
    static final char[] DFA3_min = DFA.unpackEncodedStringToUnsignedChars(DFA3_minS);
    static final char[] DFA3_max = DFA.unpackEncodedStringToUnsignedChars(DFA3_maxS);
    static final short[] DFA3_accept = DFA.unpackEncodedString(DFA3_acceptS);
    static final short[] DFA3_special = DFA.unpackEncodedString(DFA3_specialS);
    static final short[][] DFA3_transition;

    static {
        int numStates = DFA3_transitionS.length;
        DFA3_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA3_transition[i] = DFA.unpackEncodedString(DFA3_transitionS[i]);
        }
    }

    class DFA3 extends DFA {

        public DFA3(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 3;
            this.eot = DFA3_eot;
            this.eof = DFA3_eof;
            this.min = DFA3_min;
            this.max = DFA3_max;
            this.accept = DFA3_accept;
            this.special = DFA3_special;
            this.transition = DFA3_transition;
        }
        public String getDescription() {
            return "87:11: ( EXPLAIN ( QUERY PLAN )? )?";
        }
    }
    static final String DFA2_eotS =
        "\25\uffff";
    static final String DFA2_eofS =
        "\25\uffff";
    static final String DFA2_minS =
        "\1\41\24\uffff";
    static final String DFA2_maxS =
        "\1\u00a6\24\uffff";
    static final String DFA2_acceptS =
        "\1\uffff\1\1\1\2\22\uffff";
    static final String DFA2_specialS =
        "\25\uffff}>";
    static final String[] DFA2_transitionS = {
            "\1\1\60\uffff\1\2\16\uffff\1\2\2\uffff\2\2\1\uffff\5\2\11\uffff"+
            "\1\2\14\uffff\1\2\3\uffff\1\2\1\uffff\2\2\4\uffff\1\2\1\uffff"+
            "\2\2\1\uffff\1\2\21\uffff\2\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA2_eot = DFA.unpackEncodedString(DFA2_eotS);
    static final short[] DFA2_eof = DFA.unpackEncodedString(DFA2_eofS);
    static final char[] DFA2_min = DFA.unpackEncodedStringToUnsignedChars(DFA2_minS);
    static final char[] DFA2_max = DFA.unpackEncodedStringToUnsignedChars(DFA2_maxS);
    static final short[] DFA2_accept = DFA.unpackEncodedString(DFA2_acceptS);
    static final short[] DFA2_special = DFA.unpackEncodedString(DFA2_specialS);
    static final short[][] DFA2_transition;

    static {
        int numStates = DFA2_transitionS.length;
        DFA2_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA2_transition[i] = DFA.unpackEncodedString(DFA2_transitionS[i]);
        }
    }

    class DFA2 extends DFA {

        public DFA2(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 2;
            this.eot = DFA2_eot;
            this.eof = DFA2_eof;
            this.min = DFA2_min;
            this.max = DFA2_max;
            this.accept = DFA2_accept;
            this.special = DFA2_special;
            this.transition = DFA2_transition;
        }
        public String getDescription() {
            return "87:20: ( QUERY PLAN )?";
        }
    }
    static final String DFA4_eotS =
        "\42\uffff";
    static final String DFA4_eofS =
        "\42\uffff";
    static final String DFA4_minS =
        "\1\122\20\uffff\1\u0094\1\u0095\2\uffff\1\u0095\14\uffff";
    static final String DFA4_maxS =
        "\1\u00a6\20\uffff\2\u00ac\2\uffff\1\u00ac\14\uffff";
    static final String DFA4_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\uffff\1\11\1\12\1\13"+
        "\1\14\1\15\1\16\1\17\2\uffff\1\23\1\20\1\uffff\1\30\1\21\1\26\1"+
        "\uffff\1\24\1\22\1\25\1\27\1\31\3\uffff";
    static final String DFA4_specialS =
        "\42\uffff}>";
    static final String[] DFA4_transitionS = {
            "\1\15\16\uffff\1\16\2\uffff\1\1\1\2\1\uffff\1\3\1\4\1\5\1\6"+
            "\1\10\11\uffff\1\7\14\uffff\1\10\3\uffff\1\12\1\uffff\1\13\1"+
            "\14\4\uffff\1\15\1\uffff\1\17\1\20\1\uffff\1\21\21\uffff\1\22"+
            "\1\23",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\24\1\27\1\25\6\uffff\1\30\14\uffff\1\32\1\30\1\26",
            "\1\33\24\uffff\1\34\1\35\1\36",
            "",
            "",
            "\1\27\24\uffff\1\32\1\uffff\1\26",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA4_eot = DFA.unpackEncodedString(DFA4_eotS);
    static final short[] DFA4_eof = DFA.unpackEncodedString(DFA4_eofS);
    static final char[] DFA4_min = DFA.unpackEncodedStringToUnsignedChars(DFA4_minS);
    static final char[] DFA4_max = DFA.unpackEncodedStringToUnsignedChars(DFA4_maxS);
    static final short[] DFA4_accept = DFA.unpackEncodedString(DFA4_acceptS);
    static final short[] DFA4_special = DFA.unpackEncodedString(DFA4_specialS);
    static final short[][] DFA4_transition;

    static {
        int numStates = DFA4_transitionS.length;
        DFA4_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA4_transition[i] = DFA.unpackEncodedString(DFA4_transitionS[i]);
        }
    }

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = DFA4_eot;
            this.eof = DFA4_eof;
            this.min = DFA4_min;
            this.max = DFA4_max;
            this.accept = DFA4_accept;
            this.special = DFA4_special;
            this.transition = DFA4_transition;
        }
        public String getDescription() {
            return "89:1: sql_stmt_core : ( pragma_stmt | attach_stmt | detach_stmt | analyze_stmt | reindex_stmt | vacuum_stmt | select_stmt | insert_stmt | update_stmt | delete_stmt | begin_stmt | commit_stmt | rollback_stmt | savepoint_stmt | release_stmt | create_virtual_table_stmt | create_table_stmt | drop_table_stmt | alter_table_stmt | create_view_stmt | drop_view_stmt | create_index_stmt | drop_index_stmt | create_trigger_stmt | drop_trigger_stmt );";
        }
    }
    static final String DFA5_eotS =
        "\23\uffff";
    static final String DFA5_eofS =
        "\23\uffff";
    static final String DFA5_minS =
        "\1\40\2\43\20\uffff";
    static final String DFA5_maxS =
        "\1\u00b3\2\u0087\20\uffff";
    static final String DFA5_acceptS =
        "\3\uffff\1\2\6\uffff\1\1\10\uffff";
    static final String DFA5_specialS =
        "\23\uffff}>";
    static final String[] DFA5_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\1\3\1\12\1\3\1\uffff\1\3\106\uffff\2\3\7\uffff\1\3\17\uffff"+
            "\1\3",
            "\1\3\1\12\1\3\1\uffff\1\3\106\uffff\2\3\7\uffff\1\3\17\uffff"+
            "\1\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA5_eot = DFA.unpackEncodedString(DFA5_eotS);
    static final short[] DFA5_eof = DFA.unpackEncodedString(DFA5_eofS);
    static final char[] DFA5_min = DFA.unpackEncodedStringToUnsignedChars(DFA5_minS);
    static final char[] DFA5_max = DFA.unpackEncodedStringToUnsignedChars(DFA5_maxS);
    static final short[] DFA5_accept = DFA.unpackEncodedString(DFA5_acceptS);
    static final short[] DFA5_special = DFA.unpackEncodedString(DFA5_specialS);
    static final short[][] DFA5_transition;

    static {
        int numStates = DFA5_transitionS.length;
        DFA5_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA5_transition[i] = DFA.unpackEncodedString(DFA5_transitionS[i]);
        }
    }

    class DFA5 extends DFA {

        public DFA5(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 5;
            this.eot = DFA5_eot;
            this.eof = DFA5_eof;
            this.min = DFA5_min;
            this.max = DFA5_max;
            this.accept = DFA5_accept;
            this.special = DFA5_special;
            this.transition = DFA5_transition;
        }
        public String getDescription() {
            return "119:23: (database_name= id DOT )?";
        }
    }
    static final String DFA7_eotS =
        "\137\uffff";
    static final String DFA7_eofS =
        "\137\uffff";
    static final String DFA7_minS =
        "\1\40\33\uffff\1\40\2\uffff\2\40\6\44\70\uffff";
    static final String DFA7_maxS =
        "\1\u00b3\33\uffff\1\u00b3\2\uffff\2\u00b3\1\46\3\165\1\46\1\125"+
        "\70\uffff";
    static final String DFA7_acceptS =
        "\1\uffff\1\2\47\uffff\1\1\65\uffff";
    static final String DFA7_specialS =
        "\137\uffff}>";
    static final String[] DFA7_transitionS = {
            "\4\1\1\uffff\2\1\1\uffff\1\34\2\1\2\uffff\2\1\2\uffff\3\1\27"+
            "\uffff\12\1\4\uffff\3\1\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\51\1\1\1\uffff\6\51\1\uffff\1\51\2\1\2\uffff\3\51\20\uffff"+
            "\2\51\4\uffff\44\51\1\45\1\46\1\51\1\42\1\51\1\43\1\44\1\51"+
            "\1\37\1\40\1\41\73\51",
            "",
            "",
            "\3\1\1\uffff\1\51\2\1\1\uffff\3\1\1\uffff\1\1\4\uffff\3\1\27"+
            "\uffff\12\1\4\uffff\3\1\3\uffff\125\1",
            "\3\1\1\uffff\1\51\6\1\1\uffff\1\1\4\uffff\3\1\20\uffff\2\1"+
            "\4\uffff\152\1",
            "\1\51\1\uffff\1\1",
            "\1\51\115\uffff\1\1\2\uffff\1\1",
            "\1\51\120\uffff\1\1",
            "\1\51\120\uffff\1\1",
            "\1\51\1\uffff\1\1",
            "\1\51\60\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA7_eot = DFA.unpackEncodedString(DFA7_eotS);
    static final short[] DFA7_eof = DFA.unpackEncodedString(DFA7_eofS);
    static final char[] DFA7_min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
    static final char[] DFA7_max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
    static final short[] DFA7_accept = DFA.unpackEncodedString(DFA7_acceptS);
    static final short[] DFA7_special = DFA.unpackEncodedString(DFA7_specialS);
    static final short[][] DFA7_transition;

    static {
        int numStates = DFA7_transitionS.length;
        DFA7_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA7_transition[i] = DFA.unpackEncodedString(DFA7_transitionS[i]);
        }
    }

    class DFA7 extends DFA {

        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = DFA7_eot;
            this.eof = DFA7_eof;
            this.min = DFA7_min;
            this.max = DFA7_max;
            this.accept = DFA7_accept;
            this.special = DFA7_special;
            this.transition = DFA7_transition;
        }
        public String getDescription() {
            return "()* loopback of 121:18: ( OR or_subexpr )*";
        }
    }
    static final String DFA8_eotS =
        "\140\uffff";
    static final String DFA8_eofS =
        "\140\uffff";
    static final String DFA8_minS =
        "\1\40\34\uffff\1\40\2\uffff\2\40\6\44\70\uffff";
    static final String DFA8_maxS =
        "\1\u00b3\34\uffff\1\u00b3\2\uffff\2\u00b3\1\46\3\165\1\46\1\125"+
        "\70\uffff";
    static final String DFA8_acceptS =
        "\1\uffff\1\2\50\uffff\1\1\65\uffff";
    static final String DFA8_specialS =
        "\140\uffff}>";
    static final String[] DFA8_transitionS = {
            "\4\1\1\uffff\2\1\1\uffff\1\1\1\35\1\1\2\uffff\2\1\2\uffff\3"+
            "\1\27\uffff\12\1\4\uffff\3\1\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\52\1\1\1\uffff\6\52\1\uffff\1\52\2\1\2\uffff\3\52\20\uffff"+
            "\2\52\4\uffff\44\52\1\46\1\47\1\52\1\43\1\52\1\44\1\45\1\52"+
            "\1\40\1\41\1\42\73\52",
            "",
            "",
            "\3\1\1\uffff\1\52\2\1\1\uffff\3\1\1\uffff\1\1\4\uffff\3\1\27"+
            "\uffff\12\1\4\uffff\3\1\3\uffff\125\1",
            "\3\1\1\uffff\1\52\6\1\1\uffff\1\1\4\uffff\3\1\20\uffff\2\1"+
            "\4\uffff\152\1",
            "\1\52\1\uffff\1\1",
            "\1\52\115\uffff\1\1\2\uffff\1\1",
            "\1\52\120\uffff\1\1",
            "\1\52\120\uffff\1\1",
            "\1\52\1\uffff\1\1",
            "\1\52\60\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA8_eot = DFA.unpackEncodedString(DFA8_eotS);
    static final short[] DFA8_eof = DFA.unpackEncodedString(DFA8_eofS);
    static final char[] DFA8_min = DFA.unpackEncodedStringToUnsignedChars(DFA8_minS);
    static final char[] DFA8_max = DFA.unpackEncodedStringToUnsignedChars(DFA8_maxS);
    static final short[] DFA8_accept = DFA.unpackEncodedString(DFA8_acceptS);
    static final short[] DFA8_special = DFA.unpackEncodedString(DFA8_specialS);
    static final short[][] DFA8_transition;

    static {
        int numStates = DFA8_transitionS.length;
        DFA8_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA8_transition[i] = DFA.unpackEncodedString(DFA8_transitionS[i]);
        }
    }

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = DFA8_eot;
            this.eof = DFA8_eof;
            this.min = DFA8_min;
            this.max = DFA8_max;
            this.accept = DFA8_accept;
            this.special = DFA8_special;
            this.transition = DFA8_transition;
        }
        public String getDescription() {
            return "()* loopback of 123:25: ( AND and_subexpr )*";
        }
    }
    static final String DFA9_eotS =
        "\165\uffff";
    static final String DFA9_eofS =
        "\165\uffff";
    static final String DFA9_minS =
        "\1\40\5\uffff\1\43\1\40\55\uffff\2\40\6\44\70\uffff";
    static final String DFA9_maxS =
        "\1\u00b3\5\uffff\1\170\1\u00b3\55\uffff\2\u00b3\1\46\3\165\1\46"+
        "\1\125\70\uffff";
    static final String DFA9_acceptS =
        "\1\uffff\1\1\7\uffff\1\2\153\uffff";
    static final String DFA9_specialS =
        "\165\uffff}>";
    static final String[] DFA9_transitionS = {
            "\4\11\1\uffff\2\11\1\1\3\11\1\1\1\uffff\2\11\2\1\1\6\1\11\1"+
            "\7\10\1\17\uffff\12\11\4\uffff\3\11\3\uffff\125\11",
            "",
            "",
            "",
            "",
            "",
            "\1\11\3\uffff\1\1\5\uffff\2\11\3\uffff\1\1\73\uffff\2\11\1"+
            "\uffff\1\11\1\uffff\2\11\1\uffff\3\11",
            "\3\1\1\11\1\uffff\6\1\1\uffff\1\1\2\11\2\uffff\3\1\20\uffff"+
            "\2\1\4\uffff\44\1\1\73\1\74\1\1\1\70\1\1\1\71\1\72\1\1\1\65"+
            "\1\66\1\67\73\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\11\1\uffff\1\1\2\11\1\uffff\3\11\1\uffff\1\11\4\uffff\3"+
            "\11\27\uffff\12\11\4\uffff\3\11\3\uffff\125\11",
            "\3\11\1\uffff\1\1\6\11\1\uffff\1\11\4\uffff\3\11\20\uffff\2"+
            "\11\4\uffff\152\11",
            "\1\1\1\uffff\1\11",
            "\1\1\115\uffff\1\11\2\uffff\1\11",
            "\1\1\120\uffff\1\11",
            "\1\1\120\uffff\1\11",
            "\1\1\1\uffff\1\11",
            "\1\1\60\uffff\1\11",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA9_eot = DFA.unpackEncodedString(DFA9_eotS);
    static final short[] DFA9_eof = DFA.unpackEncodedString(DFA9_eofS);
    static final char[] DFA9_min = DFA.unpackEncodedStringToUnsignedChars(DFA9_minS);
    static final char[] DFA9_max = DFA.unpackEncodedStringToUnsignedChars(DFA9_maxS);
    static final short[] DFA9_accept = DFA.unpackEncodedString(DFA9_acceptS);
    static final short[] DFA9_special = DFA.unpackEncodedString(DFA9_specialS);
    static final short[][] DFA9_transition;

    static {
        int numStates = DFA9_transitionS.length;
        DFA9_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA9_transition[i] = DFA.unpackEncodedString(DFA9_transitionS[i]);
        }
    }

    class DFA9 extends DFA {

        public DFA9(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 9;
            this.eot = DFA9_eot;
            this.eof = DFA9_eof;
            this.min = DFA9_min;
            this.max = DFA9_max;
            this.accept = DFA9_accept;
            this.special = DFA9_special;
            this.transition = DFA9_transition;
        }
        public String getDescription() {
            return "125:34: ( cond_expr )?";
        }
    }
    static final String DFA19_eotS =
        "\23\uffff";
    static final String DFA19_eofS =
        "\23\uffff";
    static final String DFA19_minS =
        "\1\47\1\53\1\uffff\1\40\6\uffff\1\40\10\uffff";
    static final String DFA19_maxS =
        "\2\73\1\uffff\1\u00b3\6\uffff\1\u00b3\10\uffff";
    static final String DFA19_acceptS =
        "\2\uffff\1\1\1\uffff\1\4\2\uffff\1\5\1\6\4\uffff\1\2\1\3\4\uffff";
    static final String DFA19_specialS =
        "\23\uffff}>";
    static final String[] DFA19_transitionS = {
            "\1\1\3\uffff\1\3\3\uffff\3\4\1\uffff\1\7\4\10\4\2",
            "\1\12\6\uffff\1\4\1\7\4\uffff\4\2",
            "",
            "\3\16\2\uffff\2\16\1\uffff\3\16\1\uffff\1\15\4\uffff\3\16\27"+
            "\uffff\12\16\4\uffff\3\16\3\uffff\125\16",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\16\2\uffff\2\16\1\uffff\3\16\1\uffff\1\15\4\uffff\3\16\27"+
            "\uffff\12\16\4\uffff\3\16\3\uffff\125\16",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA19_eot = DFA.unpackEncodedString(DFA19_eotS);
    static final short[] DFA19_eof = DFA.unpackEncodedString(DFA19_eofS);
    static final char[] DFA19_min = DFA.unpackEncodedStringToUnsignedChars(DFA19_minS);
    static final char[] DFA19_max = DFA.unpackEncodedStringToUnsignedChars(DFA19_maxS);
    static final short[] DFA19_accept = DFA.unpackEncodedString(DFA19_acceptS);
    static final short[] DFA19_special = DFA.unpackEncodedString(DFA19_specialS);
    static final short[][] DFA19_transition;

    static {
        int numStates = DFA19_transitionS.length;
        DFA19_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA19_transition[i] = DFA.unpackEncodedString(DFA19_transitionS[i]);
        }
    }

    class DFA19 extends DFA {

        public DFA19(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 19;
            this.eot = DFA19_eot;
            this.eof = DFA19_eof;
            this.min = DFA19_min;
            this.max = DFA19_max;
            this.accept = DFA19_accept;
            this.special = DFA19_special;
            this.transition = DFA19_transition;
        }
        public String getDescription() {
            return "127:1: cond_expr : ( ( NOT )? match_op match_expr= eq_subexpr ( ESCAPE escape_expr= eq_subexpr )? -> ^( match_op $match_expr ( NOT )? ( ^( ESCAPE $escape_expr) )? ) | ( NOT )? IN LPAREN expr ( COMMA expr )* RPAREN -> ^( IN_VALUES ( NOT )? ^( IN ( expr )+ ) ) | ( NOT )? IN (database_name= id DOT )? table_name= id -> ^( IN_TABLE ( NOT )? ^( IN ^( $table_name ( $database_name)? ) ) ) | ( ISNULL -> IS_NULL | NOTNULL -> NOT_NULL | IS NULL -> IS_NULL | NOT NULL -> NOT_NULL | IS NOT NULL -> NOT_NULL ) | ( NOT )? BETWEEN e1= eq_subexpr AND e2= eq_subexpr -> ^( BETWEEN ( NOT )? ^( AND $e1 $e2) ) | ( ( EQUALS | EQUALS2 | NOT_EQUALS | NOT_EQUALS2 ) eq_subexpr )+ );";
        }
    }
    static final String DFA11_eotS =
        "\141\uffff";
    static final String DFA11_eofS =
        "\141\uffff";
    static final String DFA11_minS =
        "\2\40\56\uffff\1\40\2\uffff\1\40\6\44\47\uffff";
    static final String DFA11_maxS =
        "\2\u00b3\56\uffff\1\u00b3\2\uffff\1\u00b3\1\46\3\165\1\46\1\125"+
        "\47\uffff";
    static final String DFA11_acceptS =
        "\2\uffff\1\2\35\uffff\1\1\100\uffff";
    static final String DFA11_specialS =
        "\141\uffff}>";
    static final String[] DFA11_transitionS = {
            "\4\2\1\uffff\2\2\1\uffff\2\2\1\1\2\uffff\2\2\2\uffff\3\2\27"+
            "\uffff\12\2\4\uffff\3\2\3\uffff\125\2",
            "\3\40\1\2\1\uffff\6\40\1\uffff\1\40\2\2\2\uffff\3\40\20\uffff"+
            "\2\40\4\uffff\44\40\1\70\1\71\1\40\1\65\1\40\1\66\1\67\1\40"+
            "\1\60\1\63\1\64\73\40",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\2\1\uffff\1\40\2\2\1\uffff\3\2\1\uffff\1\2\4\uffff\3\2\27"+
            "\uffff\12\2\4\uffff\3\2\3\uffff\125\2",
            "",
            "",
            "\3\2\1\uffff\1\40\6\2\1\uffff\1\2\4\uffff\3\2\20\uffff\2\2"+
            "\4\uffff\152\2",
            "\1\40\1\uffff\1\2",
            "\1\40\115\uffff\1\2\2\uffff\1\2",
            "\1\40\120\uffff\1\2",
            "\1\40\120\uffff\1\2",
            "\1\40\1\uffff\1\2",
            "\1\40\60\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA11_eot = DFA.unpackEncodedString(DFA11_eotS);
    static final short[] DFA11_eof = DFA.unpackEncodedString(DFA11_eofS);
    static final char[] DFA11_min = DFA.unpackEncodedStringToUnsignedChars(DFA11_minS);
    static final char[] DFA11_max = DFA.unpackEncodedStringToUnsignedChars(DFA11_maxS);
    static final short[] DFA11_accept = DFA.unpackEncodedString(DFA11_acceptS);
    static final short[] DFA11_special = DFA.unpackEncodedString(DFA11_specialS);
    static final short[][] DFA11_transition;

    static {
        int numStates = DFA11_transitionS.length;
        DFA11_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA11_transition[i] = DFA.unpackEncodedString(DFA11_transitionS[i]);
        }
    }

    class DFA11 extends DFA {

        public DFA11(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 11;
            this.eot = DFA11_eot;
            this.eof = DFA11_eof;
            this.min = DFA11_min;
            this.max = DFA11_max;
            this.accept = DFA11_accept;
            this.special = DFA11_special;
            this.transition = DFA11_transition;
        }
        public String getDescription() {
            return "128:41: ( ESCAPE escape_expr= eq_subexpr )?";
        }
    }
    static final String DFA15_eotS =
        "\101\uffff";
    static final String DFA15_eofS =
        "\101\uffff";
    static final String DFA15_minS =
        "\3\40\76\uffff";
    static final String DFA15_maxS =
        "\3\u00b3\76\uffff";
    static final String DFA15_acceptS =
        "\3\uffff\1\2\35\uffff\1\1\37\uffff";
    static final String DFA15_specialS =
        "\101\uffff}>";
    static final String[] DFA15_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\4\3\1\41\2\3\1\uffff\3\3\2\uffff\2\3\2\uffff\3\3\27\uffff"+
            "\12\3\4\uffff\3\3\3\uffff\125\3",
            "\4\3\1\41\2\3\1\uffff\3\3\2\uffff\2\3\2\uffff\3\3\27\uffff"+
            "\12\3\4\uffff\3\3\3\uffff\125\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA15_eot = DFA.unpackEncodedString(DFA15_eotS);
    static final short[] DFA15_eof = DFA.unpackEncodedString(DFA15_eofS);
    static final char[] DFA15_min = DFA.unpackEncodedStringToUnsignedChars(DFA15_minS);
    static final char[] DFA15_max = DFA.unpackEncodedStringToUnsignedChars(DFA15_maxS);
    static final short[] DFA15_accept = DFA.unpackEncodedString(DFA15_acceptS);
    static final short[] DFA15_special = DFA.unpackEncodedString(DFA15_specialS);
    static final short[][] DFA15_transition;

    static {
        int numStates = DFA15_transitionS.length;
        DFA15_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA15_transition[i] = DFA.unpackEncodedString(DFA15_transitionS[i]);
        }
    }

    class DFA15 extends DFA {

        public DFA15(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 15;
            this.eot = DFA15_eot;
            this.eof = DFA15_eof;
            this.min = DFA15_min;
            this.max = DFA15_max;
            this.accept = DFA15_accept;
            this.special = DFA15_special;
            this.transition = DFA15_transition;
        }
        public String getDescription() {
            return "130:13: (database_name= id DOT )?";
        }
    }
    static final String DFA18_eotS =
        "\40\uffff";
    static final String DFA18_eofS =
        "\40\uffff";
    static final String DFA18_minS =
        "\1\40\37\uffff";
    static final String DFA18_maxS =
        "\1\u00b3\37\uffff";
    static final String DFA18_acceptS =
        "\1\uffff\1\2\35\uffff\1\1";
    static final String DFA18_specialS =
        "\40\uffff}>";
    static final String[] DFA18_transitionS = {
            "\4\1\1\uffff\2\1\1\uffff\3\1\2\uffff\2\1\2\uffff\3\1\4\37\23"+
            "\uffff\12\1\4\uffff\3\1\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA18_eot = DFA.unpackEncodedString(DFA18_eotS);
    static final short[] DFA18_eof = DFA.unpackEncodedString(DFA18_eofS);
    static final char[] DFA18_min = DFA.unpackEncodedStringToUnsignedChars(DFA18_minS);
    static final char[] DFA18_max = DFA.unpackEncodedStringToUnsignedChars(DFA18_maxS);
    static final short[] DFA18_accept = DFA.unpackEncodedString(DFA18_acceptS);
    static final short[] DFA18_special = DFA.unpackEncodedString(DFA18_specialS);
    static final short[][] DFA18_transition;

    static {
        int numStates = DFA18_transitionS.length;
        DFA18_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA18_transition[i] = DFA.unpackEncodedString(DFA18_transitionS[i]);
        }
    }

    class DFA18 extends DFA {

        public DFA18(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 18;
            this.eot = DFA18_eot;
            this.eof = DFA18_eof;
            this.min = DFA18_min;
            this.max = DFA18_max;
            this.accept = DFA18_accept;
            this.special = DFA18_special;
            this.transition = DFA18_transition;
        }
        public String getDescription() {
            return "()+ loopback of 135:5: ( ( EQUALS | EQUALS2 | NOT_EQUALS | NOT_EQUALS2 ) eq_subexpr )+";
        }
    }
    static final String DFA20_eotS =
        "\51\uffff";
    static final String DFA20_eofS =
        "\51\uffff";
    static final String DFA20_minS =
        "\1\40\50\uffff";
    static final String DFA20_maxS =
        "\1\u00b3\50\uffff";
    static final String DFA20_acceptS =
        "\1\uffff\1\2\46\uffff\1\1";
    static final String DFA20_specialS =
        "\51\uffff}>";
    static final String[] DFA20_transitionS = {
            "\4\1\1\uffff\7\1\1\uffff\17\1\4\50\13\uffff\12\1\4\uffff\3\1"+
            "\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA20_eot = DFA.unpackEncodedString(DFA20_eotS);
    static final short[] DFA20_eof = DFA.unpackEncodedString(DFA20_eofS);
    static final char[] DFA20_min = DFA.unpackEncodedStringToUnsignedChars(DFA20_minS);
    static final char[] DFA20_max = DFA.unpackEncodedStringToUnsignedChars(DFA20_maxS);
    static final short[] DFA20_accept = DFA.unpackEncodedString(DFA20_acceptS);
    static final short[] DFA20_special = DFA.unpackEncodedString(DFA20_specialS);
    static final short[][] DFA20_transition;

    static {
        int numStates = DFA20_transitionS.length;
        DFA20_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA20_transition[i] = DFA.unpackEncodedString(DFA20_transitionS[i]);
        }
    }

    class DFA20 extends DFA {

        public DFA20(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 20;
            this.eot = DFA20_eot;
            this.eof = DFA20_eof;
            this.min = DFA20_min;
            this.max = DFA20_max;
            this.accept = DFA20_accept;
            this.special = DFA20_special;
            this.transition = DFA20_transition;
        }
        public String getDescription() {
            return "()* loopback of 140:25: ( ( LESS | LESS_OR_EQ | GREATER | GREATER_OR_EQ ) neq_subexpr )*";
        }
    }
    static final String DFA21_eotS =
        "\52\uffff";
    static final String DFA21_eofS =
        "\52\uffff";
    static final String DFA21_minS =
        "\1\40\51\uffff";
    static final String DFA21_maxS =
        "\1\u00b3\51\uffff";
    static final String DFA21_acceptS =
        "\1\uffff\1\2\47\uffff\1\1";
    static final String DFA21_specialS =
        "\52\uffff}>";
    static final String[] DFA21_transitionS = {
            "\4\1\1\uffff\7\1\1\uffff\23\1\4\51\7\uffff\12\1\4\uffff\3\1"+
            "\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "()* loopback of 142:26: ( ( SHIFT_LEFT | SHIFT_RIGHT | AMPERSAND | PIPE ) bit_subexpr )*";
        }
    }
    static final String DFA22_eotS =
        "\53\uffff";
    static final String DFA22_eofS =
        "\53\uffff";
    static final String DFA22_minS =
        "\1\40\52\uffff";
    static final String DFA22_maxS =
        "\1\u00b3\52\uffff";
    static final String DFA22_acceptS =
        "\1\uffff\1\2\50\uffff\1\1";
    static final String DFA22_specialS =
        "\53\uffff}>";
    static final String[] DFA22_transitionS = {
            "\4\1\1\uffff\7\1\1\uffff\27\1\2\52\5\uffff\12\1\4\uffff\3\1"+
            "\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA22_eot = DFA.unpackEncodedString(DFA22_eotS);
    static final short[] DFA22_eof = DFA.unpackEncodedString(DFA22_eofS);
    static final char[] DFA22_min = DFA.unpackEncodedStringToUnsignedChars(DFA22_minS);
    static final char[] DFA22_max = DFA.unpackEncodedStringToUnsignedChars(DFA22_maxS);
    static final short[] DFA22_accept = DFA.unpackEncodedString(DFA22_acceptS);
    static final short[] DFA22_special = DFA.unpackEncodedString(DFA22_specialS);
    static final short[][] DFA22_transition;

    static {
        int numStates = DFA22_transitionS.length;
        DFA22_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA22_transition[i] = DFA.unpackEncodedString(DFA22_transitionS[i]);
        }
    }

    class DFA22 extends DFA {

        public DFA22(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 22;
            this.eot = DFA22_eot;
            this.eof = DFA22_eof;
            this.min = DFA22_min;
            this.max = DFA22_max;
            this.accept = DFA22_accept;
            this.special = DFA22_special;
            this.transition = DFA22_transition;
        }
        public String getDescription() {
            return "()* loopback of 144:26: ( ( PLUS | MINUS ) add_subexpr )*";
        }
    }
    static final String DFA23_eotS =
        "\54\uffff";
    static final String DFA23_eofS =
        "\54\uffff";
    static final String DFA23_minS =
        "\1\40\53\uffff";
    static final String DFA23_maxS =
        "\1\u00b3\53\uffff";
    static final String DFA23_acceptS =
        "\1\uffff\1\2\51\uffff\1\1";
    static final String DFA23_specialS =
        "\54\uffff}>";
    static final String[] DFA23_transitionS = {
            "\4\1\1\uffff\7\1\1\uffff\31\1\3\53\2\uffff\12\1\4\uffff\3\1"+
            "\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA23_eot = DFA.unpackEncodedString(DFA23_eotS);
    static final short[] DFA23_eof = DFA.unpackEncodedString(DFA23_eofS);
    static final char[] DFA23_min = DFA.unpackEncodedStringToUnsignedChars(DFA23_minS);
    static final char[] DFA23_max = DFA.unpackEncodedStringToUnsignedChars(DFA23_maxS);
    static final short[] DFA23_accept = DFA.unpackEncodedString(DFA23_acceptS);
    static final short[] DFA23_special = DFA.unpackEncodedString(DFA23_specialS);
    static final short[][] DFA23_transition;

    static {
        int numStates = DFA23_transitionS.length;
        DFA23_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA23_transition[i] = DFA.unpackEncodedString(DFA23_transitionS[i]);
        }
    }

    class DFA23 extends DFA {

        public DFA23(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 23;
            this.eot = DFA23_eot;
            this.eof = DFA23_eof;
            this.min = DFA23_min;
            this.max = DFA23_max;
            this.accept = DFA23_accept;
            this.special = DFA23_special;
            this.transition = DFA23_transition;
        }
        public String getDescription() {
            return "()* loopback of 146:26: ( ( ASTERISK | SLASH | PERCENT ) mul_subexpr )*";
        }
    }
    static final String DFA24_eotS =
        "\55\uffff";
    static final String DFA24_eofS =
        "\55\uffff";
    static final String DFA24_minS =
        "\1\40\54\uffff";
    static final String DFA24_maxS =
        "\1\u00b3\54\uffff";
    static final String DFA24_acceptS =
        "\1\uffff\1\2\52\uffff\1\1";
    static final String DFA24_specialS =
        "\55\uffff}>";
    static final String[] DFA24_transitionS = {
            "\4\1\1\uffff\7\1\1\uffff\34\1\1\54\1\uffff\12\1\4\uffff\3\1"+
            "\3\uffff\125\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA24_eot = DFA.unpackEncodedString(DFA24_eotS);
    static final short[] DFA24_eof = DFA.unpackEncodedString(DFA24_eofS);
    static final char[] DFA24_min = DFA.unpackEncodedStringToUnsignedChars(DFA24_minS);
    static final char[] DFA24_max = DFA.unpackEncodedStringToUnsignedChars(DFA24_maxS);
    static final short[] DFA24_accept = DFA.unpackEncodedString(DFA24_acceptS);
    static final short[] DFA24_special = DFA.unpackEncodedString(DFA24_specialS);
    static final short[][] DFA24_transition;

    static {
        int numStates = DFA24_transitionS.length;
        DFA24_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA24_transition[i] = DFA.unpackEncodedString(DFA24_transitionS[i]);
        }
    }

    class DFA24 extends DFA {

        public DFA24(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 24;
            this.eot = DFA24_eot;
            this.eof = DFA24_eof;
            this.min = DFA24_min;
            this.max = DFA24_max;
            this.accept = DFA24_accept;
            this.special = DFA24_special;
            this.transition = DFA24_transition;
        }
        public String getDescription() {
            return "()* loopback of 148:26: ( DOUBLE_PIPE con_subexpr )*";
        }
    }
    static final String DFA25_eotS =
        "\23\uffff";
    static final String DFA25_eofS =
        "\23\uffff";
    static final String DFA25_minS =
        "\1\40\22\uffff";
    static final String DFA25_maxS =
        "\1\u00b3\22\uffff";
    static final String DFA25_acceptS =
        "\1\uffff\1\1\20\uffff\1\2";
    static final String DFA25_specialS =
        "\23\uffff}>";
    static final String[] DFA25_transitionS = {
            "\3\1\2\uffff\2\1\1\22\3\1\1\uffff\1\1\4\uffff\3\1\20\uffff\2"+
            "\22\4\uffff\1\22\151\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA25_eot = DFA.unpackEncodedString(DFA25_eotS);
    static final short[] DFA25_eof = DFA.unpackEncodedString(DFA25_eofS);
    static final char[] DFA25_min = DFA.unpackEncodedStringToUnsignedChars(DFA25_minS);
    static final char[] DFA25_max = DFA.unpackEncodedStringToUnsignedChars(DFA25_maxS);
    static final short[] DFA25_accept = DFA.unpackEncodedString(DFA25_acceptS);
    static final short[] DFA25_special = DFA.unpackEncodedString(DFA25_specialS);
    static final short[][] DFA25_transition;

    static {
        int numStates = DFA25_transitionS.length;
        DFA25_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA25_transition[i] = DFA.unpackEncodedString(DFA25_transitionS[i]);
        }
    }

    class DFA25 extends DFA {

        public DFA25(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 25;
            this.eot = DFA25_eot;
            this.eof = DFA25_eof;
            this.min = DFA25_min;
            this.max = DFA25_max;
            this.accept = DFA25_accept;
            this.special = DFA25_special;
            this.transition = DFA25_transition;
        }
        public String getDescription() {
            return "150:1: con_subexpr : ( unary_subexpr | unary_op unary_subexpr -> ^( unary_op unary_subexpr ) );";
        }
    }
    static final String DFA26_eotS =
        "\72\uffff";
    static final String DFA26_eofS =
        "\72\uffff";
    static final String DFA26_minS =
        "\1\40\1\43\70\uffff";
    static final String DFA26_maxS =
        "\1\u00b3\1\170\70\uffff";
    static final String DFA26_acceptS =
        "\2\uffff\1\2\53\uffff\1\1\13\uffff";
    static final String DFA26_specialS =
        "\72\uffff}>";
    static final String[] DFA26_transitionS = {
            "\4\2\1\uffff\7\2\1\uffff\35\2\1\uffff\1\1\11\2\4\uffff\3\2\3"+
            "\uffff\125\2",
            "\1\2\11\uffff\2\2\35\uffff\1\56\41\uffff\2\2\1\uffff\1\2\1"+
            "\uffff\2\2\1\uffff\3\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA26_eot = DFA.unpackEncodedString(DFA26_eotS);
    static final short[] DFA26_eof = DFA.unpackEncodedString(DFA26_eofS);
    static final char[] DFA26_min = DFA.unpackEncodedStringToUnsignedChars(DFA26_minS);
    static final char[] DFA26_max = DFA.unpackEncodedStringToUnsignedChars(DFA26_maxS);
    static final short[] DFA26_accept = DFA.unpackEncodedString(DFA26_acceptS);
    static final short[] DFA26_special = DFA.unpackEncodedString(DFA26_specialS);
    static final short[][] DFA26_transition;

    static {
        int numStates = DFA26_transitionS.length;
        DFA26_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA26_transition[i] = DFA.unpackEncodedString(DFA26_transitionS[i]);
        }
    }

    class DFA26 extends DFA {

        public DFA26(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 26;
            this.eot = DFA26_eot;
            this.eof = DFA26_eof;
            this.min = DFA26_min;
            this.max = DFA26_max;
            this.accept = DFA26_accept;
            this.special = DFA26_special;
            this.transition = DFA26_transition;
        }
        public String getDescription() {
            return "154:26: ( COLLATE collation_name= ID )?";
        }
    }
    static final String DFA35_eotS =
        "\u0111\uffff";
    static final String DFA35_eofS =
        "\u0111\uffff";
    static final String DFA35_minS =
        "\1\40\4\uffff\4\40\3\uffff\1\40\1\44\1\uffff\1\40\1\44\u0100\uffff";
    static final String DFA35_maxS =
        "\1\u00b3\4\uffff\4\u00b3\3\uffff\1\u00b3\1\54\1\uffff\1\u00b3\1"+
        "\54\u0100\uffff";
    static final String DFA35_acceptS =
        "\1\uffff\1\1\7\uffff\1\2\4\uffff\1\5\2\uffff\1\3\u00b8\uffff\1\4"+
        "\56\uffff\1\6\2\uffff\1\7\22\uffff\1\10\1\uffff";
    static final String DFA35_specialS =
        "\u0111\uffff}>";
    static final String[] DFA35_transitionS = {
            "\3\21\2\uffff\2\21\1\uffff\3\21\1\uffff\1\16\4\uffff\1\21\1"+
            "\5\1\21\27\uffff\1\21\1\14\1\21\1\15\1\21\1\17\4\21\4\1\1\6"+
            "\1\7\1\10\3\11\1\20\124\21",
            "",
            "",
            "",
            "",
            "\4\1\1\21\7\1\1\uffff\35\1\1\uffff\12\1\4\uffff\3\1\3\uffff"+
            "\125\1",
            "\4\1\1\21\7\1\1\uffff\35\1\1\uffff\12\1\4\uffff\3\1\3\uffff"+
            "\125\1",
            "\4\1\1\21\7\1\1\uffff\35\1\1\uffff\12\1\4\uffff\3\1\3\uffff"+
            "\125\1",
            "\4\1\1\21\7\1\1\uffff\35\1\1\uffff\12\1\4\uffff\3\1\3\uffff"+
            "\125\1",
            "",
            "",
            "",
            "\14\21\1\u00ca\35\21\1\uffff\12\21\4\uffff\3\21\3\uffff\125"+
            "\21",
            "\1\21\7\uffff\1\u00f9",
            "",
            "\3\u00fc\1\uffff\1\21\6\u00fc\1\uffff\1\u00fc\4\uffff\3\u00fc"+
            "\20\uffff\2\u00fc\4\uffff\152\u00fc",
            "\1\21\7\uffff\1\u010f",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA35_eot = DFA.unpackEncodedString(DFA35_eotS);
    static final short[] DFA35_eof = DFA.unpackEncodedString(DFA35_eofS);
    static final char[] DFA35_min = DFA.unpackEncodedStringToUnsignedChars(DFA35_minS);
    static final char[] DFA35_max = DFA.unpackEncodedStringToUnsignedChars(DFA35_maxS);
    static final short[] DFA35_accept = DFA.unpackEncodedString(DFA35_acceptS);
    static final short[] DFA35_special = DFA.unpackEncodedString(DFA35_specialS);
    static final short[][] DFA35_transition;

    static {
        int numStates = DFA35_transitionS.length;
        DFA35_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA35_transition[i] = DFA.unpackEncodedString(DFA35_transitionS[i]);
        }
    }

    class DFA35 extends DFA {

        public DFA35(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 35;
            this.eot = DFA35_eot;
            this.eof = DFA35_eof;
            this.min = DFA35_min;
            this.max = DFA35_max;
            this.accept = DFA35_accept;
            this.special = DFA35_special;
            this.transition = DFA35_transition;
        }
        public String getDescription() {
            return "156:1: atom_expr : ( literal_value | bind_parameter | ( (database_name= id DOT )? table_name= id DOT )? column_name= ID -> ^( COLUMN_EXPRESSION ^( $column_name ( ^( $table_name ( $database_name)? ) )? ) ) | name= ID LPAREN ( ( DISTINCT )? args+= expr ( COMMA args+= expr )* | ASTERISK )? RPAREN -> ^( FUNCTION_EXPRESSION $name ( DISTINCT )? ( $args)* ( ASTERISK )? ) | LPAREN expr RPAREN | CAST LPAREN expr AS type_name RPAREN | CASE (case_expr= expr )? ( when_expr )+ ( ELSE else_expr= expr )? END -> ^( CASE ( $case_expr)? ( when_expr )+ ( $else_expr)? ) | raise_function );";
        }
    }
    static final String DFA28_eotS =
        "\61\uffff";
    static final String DFA28_eofS =
        "\61\uffff";
    static final String DFA28_minS =
        "\2\40\57\uffff";
    static final String DFA28_maxS =
        "\2\u00b3\57\uffff";
    static final String DFA28_acceptS =
        "\2\uffff\1\1\1\uffff\1\2\54\uffff";
    static final String DFA28_specialS =
        "\61\uffff}>";
    static final String[] DFA28_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\4\4\1\2\7\4\1\uffff\35\4\1\uffff\12\4\4\uffff\3\4\3\uffff"+
            "\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA28_eot = DFA.unpackEncodedString(DFA28_eotS);
    static final short[] DFA28_eof = DFA.unpackEncodedString(DFA28_eofS);
    static final char[] DFA28_min = DFA.unpackEncodedStringToUnsignedChars(DFA28_minS);
    static final char[] DFA28_max = DFA.unpackEncodedStringToUnsignedChars(DFA28_maxS);
    static final short[] DFA28_accept = DFA.unpackEncodedString(DFA28_acceptS);
    static final short[] DFA28_special = DFA.unpackEncodedString(DFA28_specialS);
    static final short[][] DFA28_transition;

    static {
        int numStates = DFA28_transitionS.length;
        DFA28_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA28_transition[i] = DFA.unpackEncodedString(DFA28_transitionS[i]);
        }
    }

    class DFA28 extends DFA {

        public DFA28(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 28;
            this.eot = DFA28_eot;
            this.eof = DFA28_eof;
            this.min = DFA28_min;
            this.max = DFA28_max;
            this.accept = DFA28_accept;
            this.special = DFA28_special;
            this.transition = DFA28_transition;
        }
        public String getDescription() {
            return "159:5: ( (database_name= id DOT )? table_name= id DOT )?";
        }
    }
    static final String DFA27_eotS =
        "\145\uffff";
    static final String DFA27_eofS =
        "\145\uffff";
    static final String DFA27_minS =
        "\1\40\2\44\3\40\1\uffff\1\40\135\uffff";
    static final String DFA27_maxS =
        "\1\u00b3\2\44\3\u00b3\1\uffff\1\u00b3\135\uffff";
    static final String DFA27_acceptS =
        "\6\uffff\1\1\3\uffff\1\2\132\uffff";
    static final String DFA27_specialS =
        "\145\uffff}>";
    static final String[] DFA27_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\1\3",
            "\1\4",
            "\3\6\2\uffff\2\6\1\uffff\3\6\6\uffff\3\6\27\uffff\1\6\1\5\10"+
            "\6\4\uffff\3\6\3\uffff\125\6",
            "\3\6\2\uffff\2\6\1\uffff\3\6\6\uffff\3\6\27\uffff\1\6\1\7\10"+
            "\6\4\uffff\3\6\3\uffff\125\6",
            "\4\12\1\6\7\12\1\uffff\35\12\1\uffff\12\12\4\uffff\3\12\3\uffff"+
            "\125\12",
            "",
            "\4\12\1\6\7\12\1\uffff\35\12\1\uffff\12\12\4\uffff\3\12\3\uffff"+
            "\125\12",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA27_eot = DFA.unpackEncodedString(DFA27_eotS);
    static final short[] DFA27_eof = DFA.unpackEncodedString(DFA27_eofS);
    static final char[] DFA27_min = DFA.unpackEncodedStringToUnsignedChars(DFA27_minS);
    static final char[] DFA27_max = DFA.unpackEncodedStringToUnsignedChars(DFA27_maxS);
    static final short[] DFA27_accept = DFA.unpackEncodedString(DFA27_acceptS);
    static final short[] DFA27_special = DFA.unpackEncodedString(DFA27_specialS);
    static final short[][] DFA27_transition;

    static {
        int numStates = DFA27_transitionS.length;
        DFA27_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA27_transition[i] = DFA.unpackEncodedString(DFA27_transitionS[i]);
        }
    }

    class DFA27 extends DFA {

        public DFA27(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 27;
            this.eot = DFA27_eot;
            this.eof = DFA27_eof;
            this.min = DFA27_min;
            this.max = DFA27_max;
            this.accept = DFA27_accept;
            this.special = DFA27_special;
            this.transition = DFA27_transition;
        }
        public String getDescription() {
            return "159:6: (database_name= id DOT )?";
        }
    }
    static final String DFA31_eotS =
        "\26\uffff";
    static final String DFA31_eofS =
        "\26\uffff";
    static final String DFA31_minS =
        "\1\40\25\uffff";
    static final String DFA31_maxS =
        "\1\u00b3\25\uffff";
    static final String DFA31_acceptS =
        "\1\uffff\1\1\22\uffff\1\2\1\3";
    static final String DFA31_specialS =
        "\26\uffff}>";
    static final String[] DFA31_transitionS = {
            "\3\1\2\uffff\6\1\1\uffff\1\1\1\uffff\1\25\2\uffff\3\1\20\uffff"+
            "\2\1\1\24\3\uffff\152\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA31_eot = DFA.unpackEncodedString(DFA31_eotS);
    static final short[] DFA31_eof = DFA.unpackEncodedString(DFA31_eofS);
    static final char[] DFA31_min = DFA.unpackEncodedStringToUnsignedChars(DFA31_minS);
    static final char[] DFA31_max = DFA.unpackEncodedStringToUnsignedChars(DFA31_maxS);
    static final short[] DFA31_accept = DFA.unpackEncodedString(DFA31_acceptS);
    static final short[] DFA31_special = DFA.unpackEncodedString(DFA31_specialS);
    static final short[][] DFA31_transition;

    static {
        int numStates = DFA31_transitionS.length;
        DFA31_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA31_transition[i] = DFA.unpackEncodedString(DFA31_transitionS[i]);
        }
    }

    class DFA31 extends DFA {

        public DFA31(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 31;
            this.eot = DFA31_eot;
            this.eof = DFA31_eof;
            this.min = DFA31_min;
            this.max = DFA31_max;
            this.accept = DFA31_accept;
            this.special = DFA31_special;
            this.transition = DFA31_transition;
        }
        public String getDescription() {
            return "160:20: ( ( DISTINCT )? args+= expr ( COMMA args+= expr )* | ASTERISK )?";
        }
    }
    static final String DFA29_eotS =
        "\47\uffff";
    static final String DFA29_eofS =
        "\47\uffff";
    static final String DFA29_minS =
        "\2\40\45\uffff";
    static final String DFA29_maxS =
        "\2\u00b3\45\uffff";
    static final String DFA29_acceptS =
        "\2\uffff\1\2\22\uffff\1\1\21\uffff";
    static final String DFA29_specialS =
        "\47\uffff}>";
    static final String[] DFA29_transitionS = {
            "\3\2\2\uffff\6\2\1\uffff\1\2\4\uffff\3\2\20\uffff\2\2\4\uffff"+
            "\3\2\1\1\146\2",
            "\3\25\1\uffff\1\2\6\25\1\uffff\1\25\4\uffff\3\25\20\uffff\2"+
            "\25\4\uffff\152\25",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA29_eot = DFA.unpackEncodedString(DFA29_eotS);
    static final short[] DFA29_eof = DFA.unpackEncodedString(DFA29_eofS);
    static final char[] DFA29_min = DFA.unpackEncodedStringToUnsignedChars(DFA29_minS);
    static final char[] DFA29_max = DFA.unpackEncodedStringToUnsignedChars(DFA29_maxS);
    static final short[] DFA29_accept = DFA.unpackEncodedString(DFA29_acceptS);
    static final short[] DFA29_special = DFA.unpackEncodedString(DFA29_specialS);
    static final short[][] DFA29_transition;

    static {
        int numStates = DFA29_transitionS.length;
        DFA29_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA29_transition[i] = DFA.unpackEncodedString(DFA29_transitionS[i]);
        }
    }

    class DFA29 extends DFA {

        public DFA29(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 29;
            this.eot = DFA29_eot;
            this.eof = DFA29_eof;
            this.min = DFA29_min;
            this.max = DFA29_max;
            this.accept = DFA29_accept;
            this.special = DFA29_special;
            this.transition = DFA29_transition;
        }
        public String getDescription() {
            return "160:21: ( DISTINCT )?";
        }
    }
    static final String DFA32_eotS =
        "\47\uffff";
    static final String DFA32_eofS =
        "\47\uffff";
    static final String DFA32_minS =
        "\1\40\20\uffff\1\40\25\uffff";
    static final String DFA32_maxS =
        "\1\u00b3\20\uffff\1\u00b3\25\uffff";
    static final String DFA32_acceptS =
        "\1\uffff\1\1\22\uffff\1\2\22\uffff";
    static final String DFA32_specialS =
        "\47\uffff}>";
    static final String[] DFA32_transitionS = {
            "\3\1\2\uffff\6\1\1\uffff\1\1\4\uffff\3\1\20\uffff\2\1\4\uffff"+
            "\11\1\1\21\140\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\24\1\uffff\1\1\6\24\1\uffff\1\24\4\uffff\3\24\20\uffff\2"+
            "\24\4\uffff\152\24",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA32_eot = DFA.unpackEncodedString(DFA32_eotS);
    static final short[] DFA32_eof = DFA.unpackEncodedString(DFA32_eofS);
    static final char[] DFA32_min = DFA.unpackEncodedStringToUnsignedChars(DFA32_minS);
    static final char[] DFA32_max = DFA.unpackEncodedStringToUnsignedChars(DFA32_maxS);
    static final short[] DFA32_accept = DFA.unpackEncodedString(DFA32_acceptS);
    static final short[] DFA32_special = DFA.unpackEncodedString(DFA32_specialS);
    static final short[][] DFA32_transition;

    static {
        int numStates = DFA32_transitionS.length;
        DFA32_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA32_transition[i] = DFA.unpackEncodedString(DFA32_transitionS[i]);
        }
    }

    class DFA32 extends DFA {

        public DFA32(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 32;
            this.eot = DFA32_eot;
            this.eof = DFA32_eof;
            this.min = DFA32_min;
            this.max = DFA32_max;
            this.accept = DFA32_accept;
            this.special = DFA32_special;
            this.transition = DFA32_transition;
        }
        public String getDescription() {
            return "165:10: (case_expr= expr )?";
        }
    }
    static final String DFA37_eotS =
        "\62\uffff";
    static final String DFA37_eofS =
        "\62\uffff";
    static final String DFA37_minS =
        "\1\134\1\40\60\uffff";
    static final String DFA37_maxS =
        "\1\136\1\u00b3\60\uffff";
    static final String DFA37_acceptS =
        "\2\uffff\1\3\1\4\1\2\1\1\54\uffff";
    static final String DFA37_specialS =
        "\62\uffff}>";
    static final String[] DFA37_transitionS = {
            "\1\1\1\2\1\3",
            "\4\5\1\uffff\7\5\1\uffff\35\5\1\uffff\12\5\1\4\3\uffff\3\5"+
            "\3\uffff\125\5",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA37_eot = DFA.unpackEncodedString(DFA37_eotS);
    static final short[] DFA37_eof = DFA.unpackEncodedString(DFA37_eofS);
    static final char[] DFA37_min = DFA.unpackEncodedStringToUnsignedChars(DFA37_minS);
    static final char[] DFA37_max = DFA.unpackEncodedStringToUnsignedChars(DFA37_maxS);
    static final short[] DFA37_accept = DFA.unpackEncodedString(DFA37_acceptS);
    static final short[] DFA37_special = DFA.unpackEncodedString(DFA37_specialS);
    static final short[][] DFA37_transition;

    static {
        int numStates = DFA37_transitionS.length;
        DFA37_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA37_transition[i] = DFA.unpackEncodedString(DFA37_transitionS[i]);
        }
    }

    class DFA37 extends DFA {

        public DFA37(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 37;
            this.eot = DFA37_eot;
            this.eof = DFA37_eof;
            this.min = DFA37_min;
            this.max = DFA37_max;
            this.accept = DFA37_accept;
            this.special = DFA37_special;
            this.transition = DFA37_transition;
        }
        public String getDescription() {
            return "182:1: bind_parameter : ( QUESTION -> BIND | QUESTION position= INTEGER -> ^( BIND $position) | COLON name= id -> ^( BIND_NAME $name) | AT name= id -> ^( BIND_NAME $name) );";
        }
    }
    static final String DFA39_eotS =
        "\16\uffff";
    static final String DFA39_eofS =
        "\16\uffff";
    static final String DFA39_minS =
        "\1\43\15\uffff";
    static final String DFA39_maxS =
        "\1\u00a0\15\uffff";
    static final String DFA39_acceptS =
        "\1\uffff\1\2\13\uffff\1\1";
    static final String DFA39_specialS =
        "\16\uffff}>";
    static final String[] DFA39_transitionS = {
            "\1\1\3\uffff\1\1\4\uffff\3\1\34\uffff\1\1\1\15\70\uffff\1\1"+
            "\23\uffff\2\1\2\uffff\2\1\1\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA39_eot = DFA.unpackEncodedString(DFA39_eotS);
    static final short[] DFA39_eof = DFA.unpackEncodedString(DFA39_eofS);
    static final char[] DFA39_min = DFA.unpackEncodedStringToUnsignedChars(DFA39_minS);
    static final char[] DFA39_max = DFA.unpackEncodedStringToUnsignedChars(DFA39_maxS);
    static final short[] DFA39_accept = DFA.unpackEncodedString(DFA39_acceptS);
    static final short[] DFA39_special = DFA.unpackEncodedString(DFA39_specialS);
    static final short[][] DFA39_transition;

    static {
        int numStates = DFA39_transitionS.length;
        DFA39_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA39_transition[i] = DFA.unpackEncodedString(DFA39_transitionS[i]);
        }
    }

    class DFA39 extends DFA {

        public DFA39(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 39;
            this.eot = DFA39_eot;
            this.eof = DFA39_eof;
            this.min = DFA39_min;
            this.max = DFA39_max;
            this.accept = DFA39_accept;
            this.special = DFA39_special;
            this.transition = DFA39_transition;
        }
        public String getDescription() {
            return "()+ loopback of 193:17: (names+= ID )+";
        }
    }
    static final String DFA41_eotS =
        "\15\uffff";
    static final String DFA41_eofS =
        "\15\uffff";
    static final String DFA41_minS =
        "\1\43\14\uffff";
    static final String DFA41_maxS =
        "\1\u00a0\14\uffff";
    static final String DFA41_acceptS =
        "\1\uffff\1\1\1\2\12\uffff";
    static final String DFA41_specialS =
        "\15\uffff}>";
    static final String[] DFA41_transitionS = {
            "\1\2\3\uffff\1\2\4\uffff\1\1\2\2\34\uffff\1\2\71\uffff\1\2\23"+
            "\uffff\2\2\2\uffff\2\2\1\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA41_eot = DFA.unpackEncodedString(DFA41_eotS);
    static final short[] DFA41_eof = DFA.unpackEncodedString(DFA41_eofS);
    static final char[] DFA41_min = DFA.unpackEncodedStringToUnsignedChars(DFA41_minS);
    static final char[] DFA41_max = DFA.unpackEncodedStringToUnsignedChars(DFA41_maxS);
    static final short[] DFA41_accept = DFA.unpackEncodedString(DFA41_acceptS);
    static final short[] DFA41_special = DFA.unpackEncodedString(DFA41_specialS);
    static final short[][] DFA41_transition;

    static {
        int numStates = DFA41_transitionS.length;
        DFA41_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA41_transition[i] = DFA.unpackEncodedString(DFA41_transitionS[i]);
        }
    }

    class DFA41 extends DFA {

        public DFA41(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 41;
            this.eot = DFA41_eot;
            this.eof = DFA41_eof;
            this.min = DFA41_min;
            this.max = DFA41_max;
            this.accept = DFA41_accept;
            this.special = DFA41_special;
            this.transition = DFA41_transition;
        }
        public String getDescription() {
            return "193:23: ( LPAREN size1= signed_number ( COMMA size2= signed_number )? RPAREN )?";
        }
    }
    static final String DFA43_eotS =
        "\13\uffff";
    static final String DFA43_eofS =
        "\13\uffff";
    static final String DFA43_minS =
        "\1\40\2\43\10\uffff";
    static final String DFA43_maxS =
        "\1\u00b3\2\64\10\uffff";
    static final String DFA43_acceptS =
        "\3\uffff\1\2\2\uffff\1\1\4\uffff";
    static final String DFA43_specialS =
        "\13\uffff}>";
    static final String[] DFA43_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\1\3\1\6\7\uffff\1\3\7\uffff\1\3",
            "\1\3\1\6\7\uffff\1\3\7\uffff\1\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA43_eot = DFA.unpackEncodedString(DFA43_eotS);
    static final short[] DFA43_eof = DFA.unpackEncodedString(DFA43_eofS);
    static final char[] DFA43_min = DFA.unpackEncodedStringToUnsignedChars(DFA43_minS);
    static final char[] DFA43_max = DFA.unpackEncodedStringToUnsignedChars(DFA43_maxS);
    static final short[] DFA43_accept = DFA.unpackEncodedString(DFA43_acceptS);
    static final short[] DFA43_special = DFA.unpackEncodedString(DFA43_specialS);
    static final short[][] DFA43_transition;

    static {
        int numStates = DFA43_transitionS.length;
        DFA43_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA43_transition[i] = DFA.unpackEncodedString(DFA43_transitionS[i]);
        }
    }

    class DFA43 extends DFA {

        public DFA43(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 43;
            this.eot = DFA43_eot;
            this.eof = DFA43_eof;
            this.min = DFA43_min;
            this.max = DFA43_max;
            this.accept = DFA43_accept;
            this.special = DFA43_special;
            this.transition = DFA43_transition;
        }
        public String getDescription() {
            return "199:21: (database_name= id DOT )?";
        }
    }
    static final String DFA46_eotS =
        "\17\uffff";
    static final String DFA46_eofS =
        "\17\uffff";
    static final String DFA46_minS =
        "\2\40\5\uffff\1\40\1\uffff\1\40\5\uffff";
    static final String DFA46_maxS =
        "\2\u00b3\5\uffff\1\u00b3\1\uffff\1\u00b3\5\uffff";
    static final String DFA46_acceptS =
        "\2\uffff\1\2\2\uffff\1\1\11\uffff";
    static final String DFA46_specialS =
        "\17\uffff}>";
    static final String[] DFA46_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\12\2\2\uffff"+
            "\1\2\1\uffff\3\2\3\uffff\7\2\1\1\115\2",
            "\3\5\2\uffff\2\5\1\uffff\3\5\6\uffff\3\5\27\uffff\4\5\1\7\5"+
            "\5\2\uffff\1\5\1\uffff\3\5\3\uffff\125\5",
            "",
            "",
            "",
            "",
            "",
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\4\2\1\11"+
            "\5\2\4\uffff\3\2\3\uffff\125\2",
            "",
            "\3\5\1\2\1\uffff\2\5\1\uffff\3\5\6\uffff\3\5\27\uffff\12\5"+
            "\4\uffff\3\5\3\uffff\125\5",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA46_eot = DFA.unpackEncodedString(DFA46_eotS);
    static final short[] DFA46_eof = DFA.unpackEncodedString(DFA46_eofS);
    static final char[] DFA46_min = DFA.unpackEncodedStringToUnsignedChars(DFA46_minS);
    static final char[] DFA46_max = DFA.unpackEncodedStringToUnsignedChars(DFA46_maxS);
    static final short[] DFA46_accept = DFA.unpackEncodedString(DFA46_acceptS);
    static final short[] DFA46_special = DFA.unpackEncodedString(DFA46_specialS);
    static final short[][] DFA46_transition;

    static {
        int numStates = DFA46_transitionS.length;
        DFA46_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA46_transition[i] = DFA.unpackEncodedString(DFA46_transitionS[i]);
        }
    }

    class DFA46 extends DFA {

        public DFA46(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 46;
            this.eot = DFA46_eot;
            this.eof = DFA46_eof;
            this.min = DFA46_min;
            this.max = DFA46_max;
            this.accept = DFA46_accept;
            this.special = DFA46_special;
            this.transition = DFA46_transition;
        }
        public String getDescription() {
            return "209:21: ( DATABASE )?";
        }
    }
    static final String DFA51_eotS =
        "\14\uffff";
    static final String DFA51_eofS =
        "\14\uffff";
    static final String DFA51_minS =
        "\1\43\13\uffff";
    static final String DFA51_maxS =
        "\1\171\13\uffff";
    static final String DFA51_acceptS =
        "\1\uffff\1\1\1\2\1\3\10\uffff";
    static final String DFA51_specialS =
        "\14\uffff}>";
    static final String[] DFA51_transitionS = {
            "\1\3\11\uffff\2\3\75\uffff\1\1\1\2\2\3\1\uffff\1\3\1\uffff\2"+
            "\3\4\uffff\1\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA51_eot = DFA.unpackEncodedString(DFA51_eotS);
    static final short[] DFA51_eof = DFA.unpackEncodedString(DFA51_eofS);
    static final char[] DFA51_min = DFA.unpackEncodedStringToUnsignedChars(DFA51_minS);
    static final char[] DFA51_max = DFA.unpackEncodedStringToUnsignedChars(DFA51_maxS);
    static final short[] DFA51_accept = DFA.unpackEncodedString(DFA51_acceptS);
    static final short[] DFA51_special = DFA.unpackEncodedString(DFA51_specialS);
    static final short[][] DFA51_transition;

    static {
        int numStates = DFA51_transitionS.length;
        DFA51_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA51_transition[i] = DFA.unpackEncodedString(DFA51_transitionS[i]);
        }
    }

    class DFA51 extends DFA {

        public DFA51(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 51;
            this.eot = DFA51_eot;
            this.eof = DFA51_eof;
            this.min = DFA51_min;
            this.max = DFA51_max;
            this.accept = DFA51_accept;
            this.special = DFA51_special;
            this.transition = DFA51_transition;
        }
        public String getDescription() {
            return "229:82: ( ASC | DESC )?";
        }
    }
    static final String DFA63_eotS =
        "\76\uffff";
    static final String DFA63_eofS =
        "\76\uffff";
    static final String DFA63_minS =
        "\3\40\73\uffff";
    static final String DFA63_maxS =
        "\3\u00b3\73\uffff";
    static final String DFA63_acceptS =
        "\3\uffff\1\3\22\uffff\1\1\24\uffff\1\2\22\uffff";
    static final String DFA63_specialS =
        "\76\uffff}>";
    static final String[] DFA63_transitionS = {
            "\3\3\2\uffff\6\3\1\uffff\1\3\4\uffff\3\3\20\uffff\3\3\3\uffff"+
            "\3\3\1\2\44\3\1\1\101\3",
            "\3\26\1\uffff\1\3\6\26\1\uffff\1\26\4\uffff\3\26\20\uffff\3"+
            "\26\3\uffff\152\26",
            "\3\53\1\uffff\1\3\6\53\1\uffff\1\53\4\uffff\3\53\20\uffff\3"+
            "\53\3\uffff\152\53",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA63_eot = DFA.unpackEncodedString(DFA63_eotS);
    static final short[] DFA63_eof = DFA.unpackEncodedString(DFA63_eofS);
    static final char[] DFA63_min = DFA.unpackEncodedStringToUnsignedChars(DFA63_minS);
    static final char[] DFA63_max = DFA.unpackEncodedStringToUnsignedChars(DFA63_maxS);
    static final short[] DFA63_accept = DFA.unpackEncodedString(DFA63_acceptS);
    static final short[] DFA63_special = DFA.unpackEncodedString(DFA63_specialS);
    static final short[][] DFA63_transition;

    static {
        int numStates = DFA63_transitionS.length;
        DFA63_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA63_transition[i] = DFA.unpackEncodedString(DFA63_transitionS[i]);
        }
    }

    class DFA63 extends DFA {

        public DFA63(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 63;
            this.eot = DFA63_eot;
            this.eof = DFA63_eof;
            this.min = DFA63_min;
            this.max = DFA63_max;
            this.accept = DFA63_accept;
            this.special = DFA63_special;
            this.transition = DFA63_transition;
        }
        public String getDescription() {
            return "250:10: ( ALL | DISTINCT )?";
        }
    }
    static final String DFA64_eotS =
        "\14\uffff";
    static final String DFA64_eofS =
        "\14\uffff";
    static final String DFA64_minS =
        "\1\43\13\uffff";
    static final String DFA64_maxS =
        "\1\170\13\uffff";
    static final String DFA64_acceptS =
        "\1\uffff\1\2\11\uffff\1\1";
    static final String DFA64_specialS =
        "\14\uffff}>";
    static final String[] DFA64_transitionS = {
            "\1\1\11\uffff\1\13\1\1\77\uffff\2\1\1\uffff\1\1\1\uffff\2\1"+
            "\1\uffff\3\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA64_eot = DFA.unpackEncodedString(DFA64_eotS);
    static final short[] DFA64_eof = DFA.unpackEncodedString(DFA64_eofS);
    static final char[] DFA64_min = DFA.unpackEncodedStringToUnsignedChars(DFA64_minS);
    static final char[] DFA64_max = DFA.unpackEncodedStringToUnsignedChars(DFA64_maxS);
    static final short[] DFA64_accept = DFA.unpackEncodedString(DFA64_acceptS);
    static final short[] DFA64_special = DFA.unpackEncodedString(DFA64_specialS);
    static final short[][] DFA64_transition;

    static {
        int numStates = DFA64_transitionS.length;
        DFA64_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA64_transition[i] = DFA.unpackEncodedString(DFA64_transitionS[i]);
        }
    }

    class DFA64 extends DFA {

        public DFA64(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 64;
            this.eot = DFA64_eot;
            this.eof = DFA64_eof;
            this.min = DFA64_min;
            this.max = DFA64_max;
            this.accept = DFA64_accept;
            this.special = DFA64_special;
            this.transition = DFA64_transition;
        }
        public String getDescription() {
            return "()* loopback of 250:42: ( COMMA result_column )*";
        }
    }
    static final String DFA65_eotS =
        "\13\uffff";
    static final String DFA65_eofS =
        "\13\uffff";
    static final String DFA65_minS =
        "\1\43\12\uffff";
    static final String DFA65_maxS =
        "\1\170\12\uffff";
    static final String DFA65_acceptS =
        "\1\uffff\1\1\1\2\10\uffff";
    static final String DFA65_specialS =
        "\13\uffff}>";
    static final String[] DFA65_transitionS = {
            "\1\2\12\uffff\1\2\77\uffff\2\2\1\uffff\1\2\1\uffff\2\2\1\uffff"+
            "\1\1\2\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA65_eot = DFA.unpackEncodedString(DFA65_eotS);
    static final short[] DFA65_eof = DFA.unpackEncodedString(DFA65_eofS);
    static final char[] DFA65_min = DFA.unpackEncodedStringToUnsignedChars(DFA65_minS);
    static final char[] DFA65_max = DFA.unpackEncodedStringToUnsignedChars(DFA65_maxS);
    static final short[] DFA65_accept = DFA.unpackEncodedString(DFA65_acceptS);
    static final short[] DFA65_special = DFA.unpackEncodedString(DFA65_specialS);
    static final short[][] DFA65_transition;

    static {
        int numStates = DFA65_transitionS.length;
        DFA65_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA65_transition[i] = DFA.unpackEncodedString(DFA65_transitionS[i]);
        }
    }

    class DFA65 extends DFA {

        public DFA65(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 65;
            this.eot = DFA65_eot;
            this.eof = DFA65_eof;
            this.min = DFA65_min;
            this.max = DFA65_max;
            this.accept = DFA65_accept;
            this.special = DFA65_special;
            this.transition = DFA65_transition;
        }
        public String getDescription() {
            return "250:65: ( FROM join_source )?";
        }
    }
    static final String DFA66_eotS =
        "\12\uffff";
    static final String DFA66_eofS =
        "\12\uffff";
    static final String DFA66_minS =
        "\1\43\11\uffff";
    static final String DFA66_maxS =
        "\1\170\11\uffff";
    static final String DFA66_acceptS =
        "\1\uffff\1\1\1\2\7\uffff";
    static final String DFA66_specialS =
        "\12\uffff}>";
    static final String[] DFA66_transitionS = {
            "\1\2\12\uffff\1\2\77\uffff\2\2\1\uffff\1\2\1\uffff\2\2\2\uffff"+
            "\1\1\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA66_eot = DFA.unpackEncodedString(DFA66_eotS);
    static final short[] DFA66_eof = DFA.unpackEncodedString(DFA66_eofS);
    static final char[] DFA66_min = DFA.unpackEncodedStringToUnsignedChars(DFA66_minS);
    static final char[] DFA66_max = DFA.unpackEncodedStringToUnsignedChars(DFA66_maxS);
    static final short[] DFA66_accept = DFA.unpackEncodedString(DFA66_acceptS);
    static final short[] DFA66_special = DFA.unpackEncodedString(DFA66_specialS);
    static final short[][] DFA66_transition;

    static {
        int numStates = DFA66_transitionS.length;
        DFA66_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA66_transition[i] = DFA.unpackEncodedString(DFA66_transitionS[i]);
        }
    }

    class DFA66 extends DFA {

        public DFA66(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 66;
            this.eot = DFA66_eot;
            this.eof = DFA66_eof;
            this.min = DFA66_min;
            this.max = DFA66_max;
            this.accept = DFA66_accept;
            this.special = DFA66_special;
            this.transition = DFA66_transition;
        }
        public String getDescription() {
            return "250:85: ( WHERE where_expr= expr )?";
        }
    }
    static final String DFA67_eotS =
        "\12\uffff";
    static final String DFA67_eofS =
        "\12\uffff";
    static final String DFA67_minS =
        "\1\43\11\uffff";
    static final String DFA67_maxS =
        "\1\171\11\uffff";
    static final String DFA67_acceptS =
        "\1\uffff\1\2\7\uffff\1\1";
    static final String DFA67_specialS =
        "\12\uffff}>";
    static final String[] DFA67_transitionS = {
            "\1\1\11\uffff\1\11\1\1\77\uffff\2\1\1\uffff\1\1\1\uffff\2\1"+
            "\4\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA67_eot = DFA.unpackEncodedString(DFA67_eotS);
    static final short[] DFA67_eof = DFA.unpackEncodedString(DFA67_eofS);
    static final char[] DFA67_min = DFA.unpackEncodedStringToUnsignedChars(DFA67_minS);
    static final char[] DFA67_max = DFA.unpackEncodedStringToUnsignedChars(DFA67_maxS);
    static final short[] DFA67_accept = DFA.unpackEncodedString(DFA67_acceptS);
    static final short[] DFA67_special = DFA.unpackEncodedString(DFA67_specialS);
    static final short[][] DFA67_transition;

    static {
        int numStates = DFA67_transitionS.length;
        DFA67_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA67_transition[i] = DFA.unpackEncodedString(DFA67_transitionS[i]);
        }
    }

    class DFA67 extends DFA {

        public DFA67(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 67;
            this.eot = DFA67_eot;
            this.eof = DFA67_eof;
            this.min = DFA67_min;
            this.max = DFA67_max;
            this.accept = DFA67_accept;
            this.special = DFA67_special;
            this.transition = DFA67_transition;
        }
        public String getDescription() {
            return "()* loopback of 251:28: ( COMMA ordering_term )*";
        }
    }
    static final String DFA72_eotS =
        "\u00e4\uffff";
    static final String DFA72_eofS =
        "\u00e4\uffff";
    static final String DFA72_minS =
        "\1\40\1\uffff\2\40\4\uffff\3\40\1\44\4\uffff\1\40\2\44\2\uffff\1"+
        "\40\36\uffff\1\40\36\uffff\1\40\36\uffff\1\40\36\uffff\1\40\37\uffff"+
        "\2\40\24\uffff\2\40\33\uffff";
    static final String DFA72_maxS =
        "\1\u00b3\1\uffff\2\u00b3\4\uffff\3\u00b3\1\54\4\uffff\1\u00b3\1"+
        "\54\1\44\2\uffff\1\u00b3\36\uffff\1\u00b3\36\uffff\1\u00b3\36\uffff"+
        "\1\u00b3\36\uffff\1\u00b3\37\uffff\2\u00b3\24\uffff\2\u00b3\33\uffff";
    static final String DFA72_acceptS =
        "\1\uffff\1\1\2\uffff\1\3\u00c4\uffff\1\2\32\uffff";
    static final String DFA72_specialS =
        "\u00e4\uffff}>";
    static final String[] DFA72_transitionS = {
            "\3\22\2\uffff\2\22\1\4\3\22\1\uffff\1\4\4\uffff\1\22\1\3\1\22"+
            "\20\uffff\2\4\1\1\3\uffff\1\4\1\22\1\2\1\22\1\13\1\22\1\20\4"+
            "\22\4\4\1\10\1\11\1\12\3\4\1\21\124\22",
            "",
            "\4\4\1\25\45\4\1\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "\4\4\1\64\7\4\1\uffff\35\4\1\uffff\12\4\4\uffff\3\4\3\uffff"+
            "\125\4",
            "",
            "",
            "",
            "",
            "\4\4\1\123\7\4\1\uffff\35\4\1\uffff\12\4\4\uffff\3\4\3\uffff"+
            "\125\4",
            "\4\4\1\162\7\4\1\uffff\35\4\1\uffff\12\4\4\uffff\3\4\3\uffff"+
            "\125\4",
            "\4\4\1\u0091\7\4\1\uffff\35\4\1\uffff\12\4\4\uffff\3\4\3\uffff"+
            "\125\4",
            "\1\u00b1\7\uffff\1\4",
            "",
            "",
            "",
            "",
            "\3\4\1\uffff\1\u00b2\6\4\1\uffff\1\4\4\uffff\3\4\20\uffff\2"+
            "\4\4\uffff\152\4",
            "\1\u00c7\7\uffff\1\4",
            "\1\u00c8",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "\3\4\2\uffff\2\4\1\uffff\3\4\6\uffff\3\4\22\uffff\1\u00c9\4"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA72_eot = DFA.unpackEncodedString(DFA72_eotS);
    static final short[] DFA72_eof = DFA.unpackEncodedString(DFA72_eofS);
    static final char[] DFA72_min = DFA.unpackEncodedStringToUnsignedChars(DFA72_minS);
    static final char[] DFA72_max = DFA.unpackEncodedStringToUnsignedChars(DFA72_maxS);
    static final short[] DFA72_accept = DFA.unpackEncodedString(DFA72_acceptS);
    static final short[] DFA72_special = DFA.unpackEncodedString(DFA72_specialS);
    static final short[][] DFA72_transition;

    static {
        int numStates = DFA72_transitionS.length;
        DFA72_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA72_transition[i] = DFA.unpackEncodedString(DFA72_transitionS[i]);
        }
    }

    class DFA72 extends DFA {

        public DFA72(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 72;
            this.eot = DFA72_eot;
            this.eof = DFA72_eof;
            this.min = DFA72_min;
            this.max = DFA72_max;
            this.accept = DFA72_accept;
            this.special = DFA72_special;
            this.transition = DFA72_transition;
        }
        public String getDescription() {
            return "257:1: result_column : ( ASTERISK | table_name= id DOT ASTERISK -> ^( ASTERISK $table_name) | expr ( ( AS )? column_alias= id )? -> ^( ALIAS expr ( $column_alias)? ) );";
        }
    }
    static final String DFA71_eotS =
        "\u00cb\uffff";
    static final String DFA71_eofS =
        "\u00cb\uffff";
    static final String DFA71_minS =
        "\1\40\2\uffff\1\40\1\uffff\1\40\6\43\4\uffff\1\40\2\uffff\1\40\6"+
        "\44\23\uffff\1\40\2\uffff\1\40\6\44\u0094\uffff";
    static final String DFA71_maxS =
        "\1\u00b3\2\uffff\1\u00b3\1\uffff\1\u00b3\6\170\4\uffff\1\u00b3\2"+
        "\uffff\1\u00b3\1\46\3\165\1\46\1\125\23\uffff\1\u00b3\2\uffff\1"+
        "\u00b3\1\46\3\165\1\46\1\125\u0094\uffff";
    static final String DFA71_acceptS =
        "\1\uffff\1\1\2\uffff\1\2\u00c6\uffff";
    static final String DFA71_specialS =
        "\u00cb\uffff}>";
    static final String[] DFA71_transitionS = {
            "\3\1\1\4\1\uffff\2\1\1\uffff\3\1\2\uffff\2\4\2\uffff\3\1\27"+
            "\uffff\12\1\4\uffff\3\1\3\uffff\17\1\1\12\1\13\1\1\1\7\1\1\1"+
            "\10\1\11\1\1\1\3\1\5\1\6\73\1",
            "",
            "",
            "\3\4\1\1\1\uffff\2\4\1\uffff\3\4\1\uffff\1\4\2\1\2\uffff\3"+
            "\4\27\uffff\12\4\4\uffff\3\4\3\uffff\17\4\1\30\1\31\1\4\1\25"+
            "\1\4\1\26\1\27\1\4\1\20\1\23\1\24\73\4",
            "",
            "\3\4\1\1\1\uffff\6\4\1\uffff\1\4\2\1\2\uffff\3\4\20\uffff\2"+
            "\4\4\uffff\44\4\1\65\1\66\1\4\1\62\1\4\1\63\1\64\1\4\1\55\1"+
            "\60\1\61\73\4",
            "\1\1\2\uffff\1\4\6\uffff\2\1\77\uffff\2\1\1\uffff\1\1\1\uffff"+
            "\2\1\1\uffff\3\1",
            "\1\1\11\uffff\2\1\77\uffff\2\1\1\uffff\1\1\1\4\2\1\1\4\3\1",
            "\1\1\11\uffff\2\1\77\uffff\2\1\1\uffff\1\1\1\uffff\2\1\1\4"+
            "\3\1",
            "\1\1\11\uffff\2\1\77\uffff\2\1\1\uffff\1\1\1\uffff\2\1\1\4"+
            "\3\1",
            "\1\1\2\uffff\1\4\6\uffff\2\1\77\uffff\2\1\1\uffff\1\1\1\uffff"+
            "\2\1\1\uffff\3\1",
            "\1\1\11\uffff\2\1\46\uffff\1\4\30\uffff\2\1\1\uffff\1\1\1\uffff"+
            "\2\1\1\uffff\3\1",
            "",
            "",
            "",
            "",
            "\3\1\1\uffff\1\4\2\1\1\uffff\3\1\1\uffff\1\1\4\uffff\3\1\27"+
            "\uffff\12\1\4\uffff\3\1\3\uffff\125\1",
            "",
            "",
            "\3\1\1\uffff\1\4\6\1\1\uffff\1\1\4\uffff\3\1\20\uffff\2\1\4"+
            "\uffff\152\1",
            "\1\4\1\uffff\1\1",
            "\1\4\115\uffff\1\1\2\uffff\1\1",
            "\1\4\120\uffff\1\1",
            "\1\4\120\uffff\1\1",
            "\1\4\1\uffff\1\1",
            "\1\4\60\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\1\1\uffff\1\4\2\1\1\uffff\3\1\1\uffff\1\1\4\uffff\3\1\27"+
            "\uffff\12\1\4\uffff\3\1\3\uffff\125\1",
            "",
            "",
            "\3\1\1\uffff\1\4\6\1\1\uffff\1\1\4\uffff\3\1\20\uffff\2\1\4"+
            "\uffff\152\1",
            "\1\4\1\uffff\1\1",
            "\1\4\115\uffff\1\1\2\uffff\1\1",
            "\1\4\120\uffff\1\1",
            "\1\4\120\uffff\1\1",
            "\1\4\1\uffff\1\1",
            "\1\4\60\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA71_eot = DFA.unpackEncodedString(DFA71_eotS);
    static final short[] DFA71_eof = DFA.unpackEncodedString(DFA71_eofS);
    static final char[] DFA71_min = DFA.unpackEncodedStringToUnsignedChars(DFA71_minS);
    static final char[] DFA71_max = DFA.unpackEncodedStringToUnsignedChars(DFA71_maxS);
    static final short[] DFA71_accept = DFA.unpackEncodedString(DFA71_acceptS);
    static final short[] DFA71_special = DFA.unpackEncodedString(DFA71_specialS);
    static final short[][] DFA71_transition;

    static {
        int numStates = DFA71_transitionS.length;
        DFA71_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA71_transition[i] = DFA.unpackEncodedString(DFA71_transitionS[i]);
        }
    }

    class DFA71 extends DFA {

        public DFA71(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 71;
            this.eot = DFA71_eot;
            this.eof = DFA71_eof;
            this.min = DFA71_min;
            this.max = DFA71_max;
            this.accept = DFA71_accept;
            this.special = DFA71_special;
            this.transition = DFA71_transition;
        }
        public String getDescription() {
            return "260:10: ( ( AS )? column_alias= id )?";
        }
    }
    static final String DFA70_eotS =
        "\u00cd\uffff";
    static final String DFA70_eofS =
        "\u00cd\uffff";
    static final String DFA70_minS =
        "\2\40\3\uffff\1\40\1\uffff\1\40\6\43\4\uffff\1\40\2\uffff\1\40\6"+
        "\44\23\uffff\1\40\2\uffff\1\40\6\44\u0094\uffff";
    static final String DFA70_maxS =
        "\2\u00b3\3\uffff\1\u00b3\1\uffff\1\u00b3\6\170\4\uffff\1\u00b3\2"+
        "\uffff\1\u00b3\1\46\3\165\1\46\1\125\23\uffff\1\u00b3\2\uffff\1"+
        "\u00b3\1\46\3\165\1\46\1\125\u0094\uffff";
    static final String DFA70_acceptS =
        "\2\uffff\1\2\1\uffff\1\1\u00c8\uffff";
    static final String DFA70_specialS =
        "\u00cd\uffff}>";
    static final String[] DFA70_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\4\2\1\1\5"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\3\4\1\2\1\uffff\2\4\1\uffff\3\4\2\uffff\2\2\2\uffff\3\4\27"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\17\4\1\14\1\15\1\4\1\11\1\4"+
            "\1\12\1\13\1\4\1\5\1\7\1\10\73\4",
            "",
            "",
            "",
            "\3\2\1\4\1\uffff\2\2\1\uffff\3\2\1\uffff\1\2\2\4\2\uffff\3"+
            "\2\27\uffff\12\2\4\uffff\3\2\3\uffff\17\2\1\32\1\33\1\2\1\27"+
            "\1\2\1\30\1\31\1\2\1\22\1\25\1\26\73\2",
            "",
            "\3\2\1\4\1\uffff\6\2\1\uffff\1\2\2\4\2\uffff\3\2\20\uffff\2"+
            "\2\4\uffff\44\2\1\67\1\70\1\2\1\64\1\2\1\65\1\66\1\2\1\57\1"+
            "\62\1\63\73\2",
            "\1\4\2\uffff\1\2\6\uffff\2\4\77\uffff\2\4\1\uffff\1\4\1\uffff"+
            "\2\4\1\uffff\3\4",
            "\1\4\11\uffff\2\4\77\uffff\2\4\1\uffff\1\4\1\2\2\4\1\2\3\4",
            "\1\4\11\uffff\2\4\77\uffff\2\4\1\uffff\1\4\1\uffff\2\4\1\2"+
            "\3\4",
            "\1\4\11\uffff\2\4\77\uffff\2\4\1\uffff\1\4\1\uffff\2\4\1\2"+
            "\3\4",
            "\1\4\2\uffff\1\2\6\uffff\2\4\77\uffff\2\4\1\uffff\1\4\1\uffff"+
            "\2\4\1\uffff\3\4",
            "\1\4\11\uffff\2\4\46\uffff\1\2\30\uffff\2\4\1\uffff\1\4\1\uffff"+
            "\2\4\1\uffff\3\4",
            "",
            "",
            "",
            "",
            "\3\4\1\uffff\1\2\2\4\1\uffff\3\4\1\uffff\1\4\4\uffff\3\4\27"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "\3\4\1\uffff\1\2\6\4\1\uffff\1\4\4\uffff\3\4\20\uffff\2\4\4"+
            "\uffff\152\4",
            "\1\2\1\uffff\1\4",
            "\1\2\115\uffff\1\4\2\uffff\1\4",
            "\1\2\120\uffff\1\4",
            "\1\2\120\uffff\1\4",
            "\1\2\1\uffff\1\4",
            "\1\2\60\uffff\1\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\3\4\1\uffff\1\2\2\4\1\uffff\3\4\1\uffff\1\4\4\uffff\3\4\27"+
            "\uffff\12\4\4\uffff\3\4\3\uffff\125\4",
            "",
            "",
            "\3\4\1\uffff\1\2\6\4\1\uffff\1\4\4\uffff\3\4\20\uffff\2\4\4"+
            "\uffff\152\4",
            "\1\2\1\uffff\1\4",
            "\1\2\115\uffff\1\4\2\uffff\1\4",
            "\1\2\120\uffff\1\4",
            "\1\2\120\uffff\1\4",
            "\1\2\1\uffff\1\4",
            "\1\2\60\uffff\1\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA70_eot = DFA.unpackEncodedString(DFA70_eotS);
    static final short[] DFA70_eof = DFA.unpackEncodedString(DFA70_eofS);
    static final char[] DFA70_min = DFA.unpackEncodedStringToUnsignedChars(DFA70_minS);
    static final char[] DFA70_max = DFA.unpackEncodedStringToUnsignedChars(DFA70_maxS);
    static final short[] DFA70_accept = DFA.unpackEncodedString(DFA70_acceptS);
    static final short[] DFA70_special = DFA.unpackEncodedString(DFA70_specialS);
    static final short[][] DFA70_transition;

    static {
        int numStates = DFA70_transitionS.length;
        DFA70_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA70_transition[i] = DFA.unpackEncodedString(DFA70_transitionS[i]);
        }
    }

    class DFA70 extends DFA {

        public DFA70(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 70;
            this.eot = DFA70_eot;
            this.eof = DFA70_eof;
            this.min = DFA70_min;
            this.max = DFA70_max;
            this.accept = DFA70_accept;
            this.special = DFA70_special;
            this.transition = DFA70_transition;
        }
        public String getDescription() {
            return "260:11: ( AS )?";
        }
    }
    static final String DFA74_eotS =
        "\21\uffff";
    static final String DFA74_eofS =
        "\21\uffff";
    static final String DFA74_minS =
        "\1\43\20\uffff";
    static final String DFA74_maxS =
        "\1\177\20\uffff";
    static final String DFA74_acceptS =
        "\1\uffff\1\2\10\uffff\1\1\6\uffff";
    static final String DFA74_specialS =
        "\21\uffff}>";
    static final String[] DFA74_transitionS = {
            "\1\1\11\uffff\1\12\1\1\77\uffff\2\1\1\uffff\1\1\1\uffff\2\1"+
            "\2\uffff\2\1\1\uffff\6\12",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA74_eot = DFA.unpackEncodedString(DFA74_eotS);
    static final short[] DFA74_eof = DFA.unpackEncodedString(DFA74_eofS);
    static final char[] DFA74_min = DFA.unpackEncodedStringToUnsignedChars(DFA74_minS);
    static final char[] DFA74_max = DFA.unpackEncodedStringToUnsignedChars(DFA74_maxS);
    static final short[] DFA74_accept = DFA.unpackEncodedString(DFA74_acceptS);
    static final short[] DFA74_special = DFA.unpackEncodedString(DFA74_specialS);
    static final short[][] DFA74_transition;

    static {
        int numStates = DFA74_transitionS.length;
        DFA74_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA74_transition[i] = DFA.unpackEncodedString(DFA74_transitionS[i]);
        }
    }

    class DFA74 extends DFA {

        public DFA74(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 74;
            this.eot = DFA74_eot;
            this.eof = DFA74_eof;
            this.min = DFA74_min;
            this.max = DFA74_max;
            this.accept = DFA74_accept;
            this.special = DFA74_special;
            this.transition = DFA74_transition;
        }
        public String getDescription() {
            return "()* loopback of 262:28: ( join_op single_source ( join_constraint )? )*";
        }
    }
    static final String DFA73_eotS =
        "\23\uffff";
    static final String DFA73_eofS =
        "\23\uffff";
    static final String DFA73_minS =
        "\1\43\22\uffff";
    static final String DFA73_maxS =
        "\1\u0081\22\uffff";
    static final String DFA73_acceptS =
        "\1\uffff\1\1\1\uffff\1\2\17\uffff";
    static final String DFA73_specialS =
        "\23\uffff}>";
    static final String[] DFA73_transitionS = {
            "\1\3\11\uffff\2\3\77\uffff\2\3\1\uffff\1\3\1\uffff\2\3\2\uffff"+
            "\2\3\1\uffff\6\3\2\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA73_eot = DFA.unpackEncodedString(DFA73_eotS);
    static final short[] DFA73_eof = DFA.unpackEncodedString(DFA73_eofS);
    static final char[] DFA73_min = DFA.unpackEncodedStringToUnsignedChars(DFA73_minS);
    static final char[] DFA73_max = DFA.unpackEncodedStringToUnsignedChars(DFA73_maxS);
    static final short[] DFA73_accept = DFA.unpackEncodedString(DFA73_acceptS);
    static final short[] DFA73_special = DFA.unpackEncodedString(DFA73_specialS);
    static final short[][] DFA73_transition;

    static {
        int numStates = DFA73_transitionS.length;
        DFA73_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA73_transition[i] = DFA.unpackEncodedString(DFA73_transitionS[i]);
        }
    }

    class DFA73 extends DFA {

        public DFA73(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 73;
            this.eot = DFA73_eot;
            this.eof = DFA73_eof;
            this.min = DFA73_min;
            this.max = DFA73_max;
            this.accept = DFA73_accept;
            this.special = DFA73_special;
            this.transition = DFA73_transition;
        }
        public String getDescription() {
            return "262:52: ( join_constraint )?";
        }
    }
    static final String DFA81_eotS =
        "\36\uffff";
    static final String DFA81_eofS =
        "\36\uffff";
    static final String DFA81_minS =
        "\1\40\2\uffff\1\40\1\uffff\1\40\30\uffff";
    static final String DFA81_maxS =
        "\1\u00b3\2\uffff\1\u00b3\1\uffff\1\u00b3\30\uffff";
    static final String DFA81_acceptS =
        "\1\uffff\1\1\2\uffff\1\3\4\uffff\1\2\24\uffff";
    static final String DFA81_specialS =
        "\36\uffff}>";
    static final String[] DFA81_transitionS = {
            "\3\1\2\uffff\2\1\1\uffff\3\1\1\uffff\1\3\4\uffff\3\1\27\uffff"+
            "\12\1\4\uffff\3\1\3\uffff\125\1",
            "",
            "",
            "\3\4\2\uffff\2\4\1\uffff\3\4\1\uffff\1\4\4\uffff\3\4\27\uffff"+
            "\12\4\4\uffff\3\4\3\uffff\26\4\1\5\76\4",
            "",
            "\3\11\1\uffff\1\4\6\11\1\uffff\1\11\4\uffff\3\11\20\uffff\3"+
            "\11\3\uffff\152\11",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA81_eot = DFA.unpackEncodedString(DFA81_eotS);
    static final short[] DFA81_eof = DFA.unpackEncodedString(DFA81_eofS);
    static final char[] DFA81_min = DFA.unpackEncodedStringToUnsignedChars(DFA81_minS);
    static final char[] DFA81_max = DFA.unpackEncodedStringToUnsignedChars(DFA81_maxS);
    static final short[] DFA81_accept = DFA.unpackEncodedString(DFA81_acceptS);
    static final short[] DFA81_special = DFA.unpackEncodedString(DFA81_specialS);
    static final short[][] DFA81_transition;

    static {
        int numStates = DFA81_transitionS.length;
        DFA81_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA81_transition[i] = DFA.unpackEncodedString(DFA81_transitionS[i]);
        }
    }

    class DFA81 extends DFA {

        public DFA81(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 81;
            this.eot = DFA81_eot;
            this.eof = DFA81_eof;
            this.min = DFA81_min;
            this.max = DFA81_max;
            this.accept = DFA81_accept;
            this.special = DFA81_special;
            this.transition = DFA81_transition;
        }
        public String getDescription() {
            return "264:1: single_source : ( (database_name= id DOT )? table_name= ID ( ( AS )? table_alias= ID )? ( INDEXED BY index_name= id | NOT INDEXED )? -> ^( ALIAS ^( $table_name ( $database_name)? ) ( $table_alias)? ( ^( INDEXED ( NOT )? ( $index_name)? ) )? ) | LPAREN select_stmt RPAREN ( ( AS )? table_alias= ID )? -> ^( ALIAS select_stmt ( $table_alias)? ) | LPAREN join_source RPAREN );";
        }
    }
    static final String DFA75_eotS =
        "\32\uffff";
    static final String DFA75_eofS =
        "\32\uffff";
    static final String DFA75_minS =
        "\1\40\1\43\30\uffff";
    static final String DFA75_maxS =
        "\1\u00b3\1\u0081\30\uffff";
    static final String DFA75_acceptS =
        "\2\uffff\1\1\1\2\26\uffff";
    static final String DFA75_specialS =
        "\32\uffff}>";
    static final String[] DFA75_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\1\3\1\2\1\3\1\uffff\1\3\5\uffff\2\3\35\uffff\1\3\2\uffff\1"+
            "\3\36\uffff\2\3\1\uffff\1\3\1\uffff\2\3\2\uffff\2\3\1\uffff"+
            "\10\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA75_eot = DFA.unpackEncodedString(DFA75_eotS);
    static final short[] DFA75_eof = DFA.unpackEncodedString(DFA75_eofS);
    static final char[] DFA75_min = DFA.unpackEncodedStringToUnsignedChars(DFA75_minS);
    static final char[] DFA75_max = DFA.unpackEncodedStringToUnsignedChars(DFA75_maxS);
    static final short[] DFA75_accept = DFA.unpackEncodedString(DFA75_acceptS);
    static final short[] DFA75_special = DFA.unpackEncodedString(DFA75_specialS);
    static final short[][] DFA75_transition;

    static {
        int numStates = DFA75_transitionS.length;
        DFA75_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA75_transition[i] = DFA.unpackEncodedString(DFA75_transitionS[i]);
        }
    }

    class DFA75 extends DFA {

        public DFA75(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 75;
            this.eot = DFA75_eot;
            this.eof = DFA75_eof;
            this.min = DFA75_min;
            this.max = DFA75_max;
            this.accept = DFA75_accept;
            this.special = DFA75_special;
            this.transition = DFA75_transition;
        }
        public String getDescription() {
            return "265:5: (database_name= id DOT )?";
        }
    }
    static final String DFA77_eotS =
        "\27\uffff";
    static final String DFA77_eofS =
        "\27\uffff";
    static final String DFA77_minS =
        "\1\43\26\uffff";
    static final String DFA77_maxS =
        "\1\u0081\26\uffff";
    static final String DFA77_acceptS =
        "\1\uffff\1\1\1\uffff\1\2\23\uffff";
    static final String DFA77_specialS =
        "\27\uffff}>";
    static final String[] DFA77_transitionS = {
            "\1\3\1\uffff\1\3\1\uffff\1\3\5\uffff\2\3\35\uffff\1\1\2\uffff"+
            "\1\1\36\uffff\2\3\1\uffff\1\3\1\uffff\2\3\2\uffff\2\3\1\uffff"+
            "\10\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA77_eot = DFA.unpackEncodedString(DFA77_eotS);
    static final short[] DFA77_eof = DFA.unpackEncodedString(DFA77_eofS);
    static final char[] DFA77_min = DFA.unpackEncodedStringToUnsignedChars(DFA77_minS);
    static final char[] DFA77_max = DFA.unpackEncodedStringToUnsignedChars(DFA77_maxS);
    static final short[] DFA77_accept = DFA.unpackEncodedString(DFA77_acceptS);
    static final short[] DFA77_special = DFA.unpackEncodedString(DFA77_specialS);
    static final short[][] DFA77_transition;

    static {
        int numStates = DFA77_transitionS.length;
        DFA77_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA77_transition[i] = DFA.unpackEncodedString(DFA77_transitionS[i]);
        }
    }

    class DFA77 extends DFA {

        public DFA77(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 77;
            this.eot = DFA77_eot;
            this.eof = DFA77_eof;
            this.min = DFA77_min;
            this.max = DFA77_max;
            this.accept = DFA77_accept;
            this.special = DFA77_special;
            this.transition = DFA77_transition;
        }
        public String getDescription() {
            return "265:43: ( ( AS )? table_alias= ID )?";
        }
    }
    static final String DFA78_eotS =
        "\25\uffff";
    static final String DFA78_eofS =
        "\25\uffff";
    static final String DFA78_minS =
        "\1\43\24\uffff";
    static final String DFA78_maxS =
        "\1\u0081\24\uffff";
    static final String DFA78_acceptS =
        "\1\uffff\1\1\1\2\1\3\21\uffff";
    static final String DFA78_specialS =
        "\25\uffff}>";
    static final String[] DFA78_transitionS = {
            "\1\3\1\uffff\1\1\1\uffff\1\2\5\uffff\2\3\77\uffff\2\3\1\uffff"+
            "\1\3\1\uffff\2\3\2\uffff\2\3\1\uffff\10\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA78_eot = DFA.unpackEncodedString(DFA78_eotS);
    static final short[] DFA78_eof = DFA.unpackEncodedString(DFA78_eofS);
    static final char[] DFA78_min = DFA.unpackEncodedStringToUnsignedChars(DFA78_minS);
    static final char[] DFA78_max = DFA.unpackEncodedStringToUnsignedChars(DFA78_maxS);
    static final short[] DFA78_accept = DFA.unpackEncodedString(DFA78_acceptS);
    static final short[] DFA78_special = DFA.unpackEncodedString(DFA78_specialS);
    static final short[][] DFA78_transition;

    static {
        int numStates = DFA78_transitionS.length;
        DFA78_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA78_transition[i] = DFA.unpackEncodedString(DFA78_transitionS[i]);
        }
    }

    class DFA78 extends DFA {

        public DFA78(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 78;
            this.eot = DFA78_eot;
            this.eof = DFA78_eof;
            this.min = DFA78_min;
            this.max = DFA78_max;
            this.accept = DFA78_accept;
            this.special = DFA78_special;
            this.transition = DFA78_transition;
        }
        public String getDescription() {
            return "265:67: ( INDEXED BY index_name= id | NOT INDEXED )?";
        }
    }
    static final String DFA80_eotS =
        "\25\uffff";
    static final String DFA80_eofS =
        "\25\uffff";
    static final String DFA80_minS =
        "\1\43\24\uffff";
    static final String DFA80_maxS =
        "\1\u0081\24\uffff";
    static final String DFA80_acceptS =
        "\1\uffff\1\1\1\uffff\1\2\21\uffff";
    static final String DFA80_specialS =
        "\25\uffff}>";
    static final String[] DFA80_transitionS = {
            "\1\3\11\uffff\2\3\35\uffff\1\1\2\uffff\1\1\36\uffff\2\3\1\uffff"+
            "\1\3\1\uffff\2\3\2\uffff\2\3\1\uffff\10\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA80_eot = DFA.unpackEncodedString(DFA80_eotS);
    static final short[] DFA80_eof = DFA.unpackEncodedString(DFA80_eofS);
    static final char[] DFA80_min = DFA.unpackEncodedStringToUnsignedChars(DFA80_minS);
    static final char[] DFA80_max = DFA.unpackEncodedStringToUnsignedChars(DFA80_maxS);
    static final short[] DFA80_accept = DFA.unpackEncodedString(DFA80_acceptS);
    static final short[] DFA80_special = DFA.unpackEncodedString(DFA80_specialS);
    static final short[][] DFA80_transition;

    static {
        int numStates = DFA80_transitionS.length;
        DFA80_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA80_transition[i] = DFA.unpackEncodedString(DFA80_transitionS[i]);
        }
    }

    class DFA80 extends DFA {

        public DFA80(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 80;
            this.eot = DFA80_eot;
            this.eof = DFA80_eof;
            this.min = DFA80_min;
            this.max = DFA80_max;
            this.accept = DFA80_accept;
            this.special = DFA80_special;
            this.transition = DFA80_transition;
        }
        public String getDescription() {
            return "267:31: ( ( AS )? table_alias= ID )?";
        }
    }
    static final String DFA91_eotS =
        "\15\uffff";
    static final String DFA91_eofS =
        "\15\uffff";
    static final String DFA91_minS =
        "\1\40\2\44\12\uffff";
    static final String DFA91_maxS =
        "\1\u00b3\2\u0085\12\uffff";
    static final String DFA91_acceptS =
        "\3\uffff\1\2\3\uffff\1\1\5\uffff";
    static final String DFA91_specialS =
        "\15\uffff}>";
    static final String[] DFA91_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\1\7\7\uffff\1\3\110\uffff\1\3\16\uffff\2\3",
            "\1\7\7\uffff\1\3\110\uffff\1\3\16\uffff\2\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA91_eot = DFA.unpackEncodedString(DFA91_eotS);
    static final short[] DFA91_eof = DFA.unpackEncodedString(DFA91_eofS);
    static final char[] DFA91_min = DFA.unpackEncodedStringToUnsignedChars(DFA91_minS);
    static final char[] DFA91_max = DFA.unpackEncodedStringToUnsignedChars(DFA91_maxS);
    static final short[] DFA91_accept = DFA.unpackEncodedString(DFA91_acceptS);
    static final short[] DFA91_special = DFA.unpackEncodedString(DFA91_specialS);
    static final short[][] DFA91_transition;

    static {
        int numStates = DFA91_transitionS.length;
        DFA91_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA91_transition[i] = DFA.unpackEncodedString(DFA91_transitionS[i]);
        }
    }

    class DFA91 extends DFA {

        public DFA91(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 91;
            this.eot = DFA91_eot;
            this.eof = DFA91_eof;
            this.min = DFA91_min;
            this.max = DFA91_max;
            this.accept = DFA91_accept;
            this.special = DFA91_special;
            this.transition = DFA91_transition;
        }
        public String getDescription() {
            return "280:67: (database_name= id DOT )?";
        }
    }
    static final String DFA116_eotS =
        "\72\uffff";
    static final String DFA116_eofS =
        "\72\uffff";
    static final String DFA116_minS =
        "\1\55\1\40\2\uffff\1\47\1\uffff\3\47\61\uffff";
    static final String DFA116_maxS =
        "\1\56\1\u00b3\2\uffff\1\u00a0\1\uffff\3\u00a0\61\uffff";
    static final String DFA116_acceptS =
        "\2\uffff\1\2\1\1\66\uffff";
    static final String DFA116_specialS =
        "\72\uffff}>";
    static final String[] DFA116_transitionS = {
            "\1\1\1\2",
            "\3\3\2\uffff\7\3\3\uffff\5\3\4\uffff\4\3\17\uffff\12\3\4\uffff"+
            "\3\3\3\uffff\72\3\1\2\1\4\2\3\1\6\1\7\1\10\11\3\1\uffff\12\3",
            "",
            "",
            "\1\3\5\uffff\2\3\34\uffff\2\3\70\uffff\1\3\23\uffff\2\3\1\2"+
            "\1\uffff\2\3\1\uffff\1\3",
            "",
            "\1\3\4\uffff\1\2\2\3\34\uffff\2\3\70\uffff\1\3\23\uffff\2\3"+
            "\2\uffff\2\3\1\uffff\1\3",
            "\1\3\4\uffff\1\2\2\3\34\uffff\2\3\70\uffff\1\3\23\uffff\2\3"+
            "\2\uffff\2\3\1\uffff\1\3",
            "\1\3\5\uffff\2\3\34\uffff\2\3\70\uffff\1\3\23\uffff\2\3\1\2"+
            "\1\uffff\2\3\1\uffff\1\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA116_eot = DFA.unpackEncodedString(DFA116_eotS);
    static final short[] DFA116_eof = DFA.unpackEncodedString(DFA116_eofS);
    static final char[] DFA116_min = DFA.unpackEncodedStringToUnsignedChars(DFA116_minS);
    static final char[] DFA116_max = DFA.unpackEncodedStringToUnsignedChars(DFA116_maxS);
    static final short[] DFA116_accept = DFA.unpackEncodedString(DFA116_acceptS);
    static final short[] DFA116_special = DFA.unpackEncodedString(DFA116_specialS);
    static final short[][] DFA116_transition;

    static {
        int numStates = DFA116_transitionS.length;
        DFA116_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA116_transition[i] = DFA.unpackEncodedString(DFA116_transitionS[i]);
        }
    }

    class DFA116 extends DFA {

        public DFA116(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 116;
            this.eot = DFA116_eot;
            this.eof = DFA116_eof;
            this.min = DFA116_min;
            this.max = DFA116_max;
            this.accept = DFA116_accept;
            this.special = DFA116_special;
            this.transition = DFA116_transition;
        }
        public String getDescription() {
            return "()* loopback of 323:23: ( COMMA column_def )*";
        }
    }
    static final String DFA119_eotS =
        "\15\uffff";
    static final String DFA119_eofS =
        "\15\uffff";
    static final String DFA119_minS =
        "\1\43\14\uffff";
    static final String DFA119_maxS =
        "\1\u00a0\14\uffff";
    static final String DFA119_acceptS =
        "\1\uffff\1\1\1\2\12\uffff";
    static final String DFA119_specialS =
        "\15\uffff}>";
    static final String[] DFA119_transitionS = {
            "\1\2\3\uffff\1\2\5\uffff\2\2\34\uffff\1\2\1\1\70\uffff\1\2\23"+
            "\uffff\2\2\2\uffff\2\2\1\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA119_eot = DFA.unpackEncodedString(DFA119_eotS);
    static final short[] DFA119_eof = DFA.unpackEncodedString(DFA119_eofS);
    static final char[] DFA119_min = DFA.unpackEncodedStringToUnsignedChars(DFA119_minS);
    static final char[] DFA119_max = DFA.unpackEncodedStringToUnsignedChars(DFA119_maxS);
    static final short[] DFA119_accept = DFA.unpackEncodedString(DFA119_acceptS);
    static final short[] DFA119_special = DFA.unpackEncodedString(DFA119_specialS);
    static final short[][] DFA119_transition;

    static {
        int numStates = DFA119_transitionS.length;
        DFA119_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA119_transition[i] = DFA.unpackEncodedString(DFA119_transitionS[i]);
        }
    }

    class DFA119 extends DFA {

        public DFA119(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 119;
            this.eot = DFA119_eot;
            this.eof = DFA119_eof;
            this.min = DFA119_min;
            this.max = DFA119_max;
            this.accept = DFA119_accept;
            this.special = DFA119_special;
            this.transition = DFA119_transition;
        }
        public String getDescription() {
            return "328:32: ( type_name )?";
        }
    }
    static final String DFA120_eotS =
        "\14\uffff";
    static final String DFA120_eofS =
        "\14\uffff";
    static final String DFA120_minS =
        "\1\43\13\uffff";
    static final String DFA120_maxS =
        "\1\u00a0\13\uffff";
    static final String DFA120_acceptS =
        "\1\uffff\1\2\2\uffff\1\1\7\uffff";
    static final String DFA120_specialS =
        "\14\uffff}>";
    static final String[] DFA120_transitionS = {
            "\1\1\3\uffff\1\4\5\uffff\2\1\34\uffff\1\4\71\uffff\1\4\23\uffff"+
            "\2\4\2\uffff\2\4\1\uffff\1\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA120_eot = DFA.unpackEncodedString(DFA120_eotS);
    static final short[] DFA120_eof = DFA.unpackEncodedString(DFA120_eofS);
    static final char[] DFA120_min = DFA.unpackEncodedStringToUnsignedChars(DFA120_minS);
    static final char[] DFA120_max = DFA.unpackEncodedStringToUnsignedChars(DFA120_maxS);
    static final short[] DFA120_accept = DFA.unpackEncodedString(DFA120_acceptS);
    static final short[] DFA120_special = DFA.unpackEncodedString(DFA120_specialS);
    static final short[][] DFA120_transition;

    static {
        int numStates = DFA120_transitionS.length;
        DFA120_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA120_transition[i] = DFA.unpackEncodedString(DFA120_transitionS[i]);
        }
    }

    class DFA120 extends DFA {

        public DFA120(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 120;
            this.eot = DFA120_eot;
            this.eof = DFA120_eof;
            this.min = DFA120_min;
            this.max = DFA120_max;
            this.accept = DFA120_accept;
            this.special = DFA120_special;
            this.transition = DFA120_transition;
        }
        public String getDescription() {
            return "()* loopback of 328:43: ( column_constraint )*";
        }
    }
    static final String DFA123_eotS =
        "\17\uffff";
    static final String DFA123_eofS =
        "\17\uffff";
    static final String DFA123_minS =
        "\1\43\16\uffff";
    static final String DFA123_maxS =
        "\1\u00a0\16\uffff";
    static final String DFA123_acceptS =
        "\1\uffff\1\1\1\2\14\uffff";
    static final String DFA123_specialS =
        "\17\uffff}>";
    static final String[] DFA123_transitionS = {
            "\1\2\3\uffff\1\2\5\uffff\2\2\34\uffff\1\2\40\uffff\2\1\22\uffff"+
            "\1\2\4\uffff\1\2\23\uffff\2\2\1\uffff\3\2\1\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA123_eot = DFA.unpackEncodedString(DFA123_eotS);
    static final short[] DFA123_eof = DFA.unpackEncodedString(DFA123_eofS);
    static final char[] DFA123_min = DFA.unpackEncodedStringToUnsignedChars(DFA123_minS);
    static final char[] DFA123_max = DFA.unpackEncodedStringToUnsignedChars(DFA123_maxS);
    static final short[] DFA123_accept = DFA.unpackEncodedString(DFA123_acceptS);
    static final short[] DFA123_special = DFA.unpackEncodedString(DFA123_specialS);
    static final short[][] DFA123_transition;

    static {
        int numStates = DFA123_transitionS.length;
        DFA123_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA123_transition[i] = DFA.unpackEncodedString(DFA123_transitionS[i]);
        }
    }

    class DFA123 extends DFA {

        public DFA123(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 123;
            this.eot = DFA123_eot;
            this.eof = DFA123_eof;
            this.min = DFA123_min;
            this.max = DFA123_max;
            this.accept = DFA123_accept;
            this.special = DFA123_special;
            this.transition = DFA123_transition;
        }
        public String getDescription() {
            return "349:37: ( ASC | DESC )?";
        }
    }
    static final String DFA124_eotS =
        "\16\uffff";
    static final String DFA124_eofS =
        "\16\uffff";
    static final String DFA124_minS =
        "\1\43\15\uffff";
    static final String DFA124_maxS =
        "\1\u00a0\15\uffff";
    static final String DFA124_acceptS =
        "\1\uffff\1\1\1\2\13\uffff";
    static final String DFA124_specialS =
        "\16\uffff}>";
    static final String[] DFA124_transitionS = {
            "\1\2\3\uffff\1\2\5\uffff\2\2\34\uffff\1\2\64\uffff\1\1\4\uffff"+
            "\1\2\23\uffff\2\2\1\uffff\3\2\1\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA124_eot = DFA.unpackEncodedString(DFA124_eotS);
    static final short[] DFA124_eof = DFA.unpackEncodedString(DFA124_eofS);
    static final char[] DFA124_min = DFA.unpackEncodedStringToUnsignedChars(DFA124_minS);
    static final char[] DFA124_max = DFA.unpackEncodedStringToUnsignedChars(DFA124_maxS);
    static final short[] DFA124_accept = DFA.unpackEncodedString(DFA124_acceptS);
    static final short[] DFA124_special = DFA.unpackEncodedString(DFA124_specialS);
    static final short[][] DFA124_transition;

    static {
        int numStates = DFA124_transitionS.length;
        DFA124_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA124_transition[i] = DFA.unpackEncodedString(DFA124_transitionS[i]);
        }
    }

    class DFA124 extends DFA {

        public DFA124(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 124;
            this.eot = DFA124_eot;
            this.eof = DFA124_eof;
            this.min = DFA124_min;
            this.max = DFA124_max;
            this.accept = DFA124_accept;
            this.special = DFA124_special;
            this.transition = DFA124_transition;
        }
        public String getDescription() {
            return "349:51: ( table_conflict_clause )?";
        }
    }
    static final String DFA125_eotS =
        "\15\uffff";
    static final String DFA125_eofS =
        "\15\uffff";
    static final String DFA125_minS =
        "\1\43\14\uffff";
    static final String DFA125_maxS =
        "\1\u00a0\14\uffff";
    static final String DFA125_acceptS =
        "\1\uffff\1\1\1\2\12\uffff";
    static final String DFA125_specialS =
        "\15\uffff}>";
    static final String[] DFA125_transitionS = {
            "\1\2\3\uffff\1\2\5\uffff\2\2\34\uffff\1\2\71\uffff\1\2\23\uffff"+
            "\2\2\1\uffff\1\1\2\2\1\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA125_eot = DFA.unpackEncodedString(DFA125_eotS);
    static final short[] DFA125_eof = DFA.unpackEncodedString(DFA125_eofS);
    static final char[] DFA125_min = DFA.unpackEncodedStringToUnsignedChars(DFA125_minS);
    static final char[] DFA125_max = DFA.unpackEncodedStringToUnsignedChars(DFA125_maxS);
    static final short[] DFA125_accept = DFA.unpackEncodedString(DFA125_acceptS);
    static final short[] DFA125_special = DFA.unpackEncodedString(DFA125_specialS);
    static final short[][] DFA125_transition;

    static {
        int numStates = DFA125_transitionS.length;
        DFA125_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA125_transition[i] = DFA.unpackEncodedString(DFA125_transitionS[i]);
        }
    }

    class DFA125 extends DFA {

        public DFA125(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 125;
            this.eot = DFA125_eot;
            this.eof = DFA125_eof;
            this.min = DFA125_min;
            this.max = DFA125_max;
            this.accept = DFA125_accept;
            this.special = DFA125_special;
            this.transition = DFA125_transition;
        }
        public String getDescription() {
            return "349:74: ( AUTOINCREMENT )?";
        }
    }
    static final String DFA126_eotS =
        "\15\uffff";
    static final String DFA126_eofS =
        "\15\uffff";
    static final String DFA126_minS =
        "\1\43\14\uffff";
    static final String DFA126_maxS =
        "\1\u00a0\14\uffff";
    static final String DFA126_acceptS =
        "\1\uffff\1\1\1\2\12\uffff";
    static final String DFA126_specialS =
        "\15\uffff}>";
    static final String[] DFA126_transitionS = {
            "\1\2\3\uffff\1\2\5\uffff\2\2\34\uffff\1\2\64\uffff\1\1\4\uffff"+
            "\1\2\23\uffff\2\2\2\uffff\2\2\1\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA126_eot = DFA.unpackEncodedString(DFA126_eotS);
    static final short[] DFA126_eof = DFA.unpackEncodedString(DFA126_eofS);
    static final char[] DFA126_min = DFA.unpackEncodedStringToUnsignedChars(DFA126_minS);
    static final char[] DFA126_max = DFA.unpackEncodedStringToUnsignedChars(DFA126_maxS);
    static final short[] DFA126_accept = DFA.unpackEncodedString(DFA126_acceptS);
    static final short[] DFA126_special = DFA.unpackEncodedString(DFA126_specialS);
    static final short[][] DFA126_transition;

    static {
        int numStates = DFA126_transitionS.length;
        DFA126_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA126_transition[i] = DFA.unpackEncodedString(DFA126_transitionS[i]);
        }
    }

    class DFA126 extends DFA {

        public DFA126(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 126;
            this.eot = DFA126_eot;
            this.eof = DFA126_eof;
            this.min = DFA126_min;
            this.max = DFA126_max;
            this.accept = DFA126_accept;
            this.special = DFA126_special;
            this.transition = DFA126_transition;
        }
        public String getDescription() {
            return "351:38: ( table_conflict_clause )?";
        }
    }
    static final String DFA127_eotS =
        "\15\uffff";
    static final String DFA127_eofS =
        "\15\uffff";
    static final String DFA127_minS =
        "\1\43\14\uffff";
    static final String DFA127_maxS =
        "\1\u00a0\14\uffff";
    static final String DFA127_acceptS =
        "\1\uffff\1\1\1\2\12\uffff";
    static final String DFA127_specialS =
        "\15\uffff}>";
    static final String[] DFA127_transitionS = {
            "\1\2\3\uffff\1\2\5\uffff\2\2\34\uffff\1\2\64\uffff\1\1\4\uffff"+
            "\1\2\23\uffff\2\2\2\uffff\2\2\1\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA127_eot = DFA.unpackEncodedString(DFA127_eotS);
    static final short[] DFA127_eof = DFA.unpackEncodedString(DFA127_eofS);
    static final char[] DFA127_min = DFA.unpackEncodedStringToUnsignedChars(DFA127_minS);
    static final char[] DFA127_max = DFA.unpackEncodedStringToUnsignedChars(DFA127_maxS);
    static final short[] DFA127_accept = DFA.unpackEncodedString(DFA127_acceptS);
    static final short[] DFA127_special = DFA.unpackEncodedString(DFA127_specialS);
    static final short[][] DFA127_transition;

    static {
        int numStates = DFA127_transitionS.length;
        DFA127_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA127_transition[i] = DFA.unpackEncodedString(DFA127_transitionS[i]);
        }
    }

    class DFA127 extends DFA {

        public DFA127(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 127;
            this.eot = DFA127_eot;
            this.eof = DFA127_eof;
            this.min = DFA127_min;
            this.max = DFA127_max;
            this.accept = DFA127_accept;
            this.special = DFA127_special;
            this.transition = DFA127_transition;
        }
        public String getDescription() {
            return "353:35: ( table_conflict_clause )?";
        }
    }
    static final String DFA129_eotS =
        "\13\uffff";
    static final String DFA129_eofS =
        "\13\uffff";
    static final String DFA129_minS =
        "\1\54\12\uffff";
    static final String DFA129_maxS =
        "\1\133\12\uffff";
    static final String DFA129_acceptS =
        "\1\uffff\1\1\1\2\7\uffff\1\3";
    static final String DFA129_specialS =
        "\13\uffff}>";
    static final String[] DFA129_transitionS = {
            "\1\12\5\uffff\1\2\21\uffff\2\1\17\uffff\7\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA129_eot = DFA.unpackEncodedString(DFA129_eotS);
    static final short[] DFA129_eof = DFA.unpackEncodedString(DFA129_eofS);
    static final char[] DFA129_min = DFA.unpackEncodedStringToUnsignedChars(DFA129_minS);
    static final char[] DFA129_max = DFA.unpackEncodedStringToUnsignedChars(DFA129_maxS);
    static final short[] DFA129_accept = DFA.unpackEncodedString(DFA129_acceptS);
    static final short[] DFA129_special = DFA.unpackEncodedString(DFA129_specialS);
    static final short[][] DFA129_transition;

    static {
        int numStates = DFA129_transitionS.length;
        DFA129_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA129_transition[i] = DFA.unpackEncodedString(DFA129_transitionS[i]);
        }
    }

    class DFA129 extends DFA {

        public DFA129(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 129;
            this.eot = DFA129_eot;
            this.eof = DFA129_eof;
            this.min = DFA129_min;
            this.max = DFA129_max;
            this.accept = DFA129_accept;
            this.special = DFA129_special;
            this.transition = DFA129_transition;
        }
        public String getDescription() {
            return "365:37: ( signed_default_number | literal_value | LPAREN expr RPAREN )";
        }
    }
    static final String DFA138_eotS =
        "\20\uffff";
    static final String DFA138_eofS =
        "\20\uffff";
    static final String DFA138_minS =
        "\1\43\17\uffff";
    static final String DFA138_maxS =
        "\1\u00a3\17\uffff";
    static final String DFA138_acceptS =
        "\1\uffff\1\1\1\2\15\uffff";
    static final String DFA138_specialS =
        "\20\uffff}>";
    static final String[] DFA138_transitionS = {
            "\1\2\3\uffff\1\2\4\uffff\1\1\2\2\14\uffff\1\2\17\uffff\1\2\64"+
            "\uffff\1\2\4\uffff\1\2\23\uffff\2\2\2\uffff\2\2\1\uffff\1\2"+
            "\2\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA138_eot = DFA.unpackEncodedString(DFA138_eotS);
    static final short[] DFA138_eof = DFA.unpackEncodedString(DFA138_eofS);
    static final char[] DFA138_min = DFA.unpackEncodedStringToUnsignedChars(DFA138_minS);
    static final char[] DFA138_max = DFA.unpackEncodedStringToUnsignedChars(DFA138_maxS);
    static final short[] DFA138_accept = DFA.unpackEncodedString(DFA138_acceptS);
    static final short[] DFA138_special = DFA.unpackEncodedString(DFA138_specialS);
    static final short[][] DFA138_transition;

    static {
        int numStates = DFA138_transitionS.length;
        DFA138_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA138_transition[i] = DFA.unpackEncodedString(DFA138_transitionS[i]);
        }
    }

    class DFA138 extends DFA {

        public DFA138(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 138;
            this.eot = DFA138_eot;
            this.eof = DFA138_eof;
            this.min = DFA138_min;
            this.max = DFA138_max;
            this.accept = DFA138_accept;
            this.special = DFA138_special;
            this.transition = DFA138_transition;
        }
        public String getDescription() {
            return "394:40: ( LPAREN column_names+= id ( COMMA column_names+= id )* RPAREN )?";
        }
    }
    static final String DFA139_eotS =
        "\17\uffff";
    static final String DFA139_eofS =
        "\17\uffff";
    static final String DFA139_minS =
        "\1\43\16\uffff";
    static final String DFA139_maxS =
        "\1\u00a3\16\uffff";
    static final String DFA139_acceptS =
        "\1\uffff\1\2\13\uffff\1\1\1\uffff";
    static final String DFA139_specialS =
        "\17\uffff}>";
    static final String[] DFA139_transitionS = {
            "\1\1\3\uffff\1\1\5\uffff\2\1\14\uffff\1\15\17\uffff\1\1\64\uffff"+
            "\1\15\4\uffff\1\1\23\uffff\2\1\2\uffff\2\1\1\uffff\1\1\2\uffff"+
            "\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA139_eot = DFA.unpackEncodedString(DFA139_eotS);
    static final short[] DFA139_eof = DFA.unpackEncodedString(DFA139_eofS);
    static final char[] DFA139_min = DFA.unpackEncodedStringToUnsignedChars(DFA139_minS);
    static final char[] DFA139_max = DFA.unpackEncodedStringToUnsignedChars(DFA139_maxS);
    static final short[] DFA139_accept = DFA.unpackEncodedString(DFA139_acceptS);
    static final short[] DFA139_special = DFA.unpackEncodedString(DFA139_specialS);
    static final short[][] DFA139_transition;

    static {
        int numStates = DFA139_transitionS.length;
        DFA139_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA139_transition[i] = DFA.unpackEncodedString(DFA139_transitionS[i]);
        }
    }

    class DFA139 extends DFA {

        public DFA139(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 139;
            this.eot = DFA139_eot;
            this.eof = DFA139_eof;
            this.min = DFA139_min;
            this.max = DFA139_max;
            this.accept = DFA139_accept;
            this.special = DFA139_special;
            this.transition = DFA139_transition;
        }
        public String getDescription() {
            return "()* loopback of 395:3: ( fk_clause_action )*";
        }
    }
    static final String DFA140_eotS =
        "\17\uffff";
    static final String DFA140_eofS =
        "\17\uffff";
    static final String DFA140_minS =
        "\1\43\1\62\15\uffff";
    static final String DFA140_maxS =
        "\2\u00a3\15\uffff";
    static final String DFA140_acceptS =
        "\2\uffff\1\1\1\2\13\uffff";
    static final String DFA140_specialS =
        "\17\uffff}>";
    static final String[] DFA140_transitionS = {
            "\1\3\3\uffff\1\1\5\uffff\2\3\34\uffff\1\3\71\uffff\1\3\23\uffff"+
            "\2\3\2\uffff\2\3\1\uffff\1\3\2\uffff\1\2",
            "\1\3\160\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA140_eot = DFA.unpackEncodedString(DFA140_eotS);
    static final short[] DFA140_eof = DFA.unpackEncodedString(DFA140_eofS);
    static final char[] DFA140_min = DFA.unpackEncodedStringToUnsignedChars(DFA140_minS);
    static final char[] DFA140_max = DFA.unpackEncodedStringToUnsignedChars(DFA140_maxS);
    static final short[] DFA140_accept = DFA.unpackEncodedString(DFA140_acceptS);
    static final short[] DFA140_special = DFA.unpackEncodedString(DFA140_specialS);
    static final short[][] DFA140_transition;

    static {
        int numStates = DFA140_transitionS.length;
        DFA140_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA140_transition[i] = DFA.unpackEncodedString(DFA140_transitionS[i]);
        }
    }

    class DFA140 extends DFA {

        public DFA140(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 140;
            this.eot = DFA140_eot;
            this.eof = DFA140_eof;
            this.min = DFA140_min;
            this.max = DFA140_max;
            this.accept = DFA140_accept;
            this.special = DFA140_special;
            this.transition = DFA140_transition;
        }
        public String getDescription() {
            return "395:21: ( fk_clause_deferrable )?";
        }
    }
    static final String DFA144_eotS =
        "\17\uffff";
    static final String DFA144_eofS =
        "\17\uffff";
    static final String DFA144_minS =
        "\1\43\1\u008a\15\uffff";
    static final String DFA144_maxS =
        "\1\u00a4\1\u008b\15\uffff";
    static final String DFA144_acceptS =
        "\2\uffff\1\3\12\uffff\1\1\1\2";
    static final String DFA144_specialS =
        "\17\uffff}>";
    static final String[] DFA144_transitionS = {
            "\1\2\3\uffff\1\2\5\uffff\2\2\34\uffff\1\2\71\uffff\1\2\23\uffff"+
            "\2\2\2\uffff\2\2\1\uffff\1\2\3\uffff\1\1",
            "\1\15\1\16",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA144_eot = DFA.unpackEncodedString(DFA144_eotS);
    static final short[] DFA144_eof = DFA.unpackEncodedString(DFA144_eofS);
    static final char[] DFA144_min = DFA.unpackEncodedStringToUnsignedChars(DFA144_minS);
    static final char[] DFA144_max = DFA.unpackEncodedStringToUnsignedChars(DFA144_maxS);
    static final short[] DFA144_accept = DFA.unpackEncodedString(DFA144_acceptS);
    static final short[] DFA144_special = DFA.unpackEncodedString(DFA144_specialS);
    static final short[][] DFA144_transition;

    static {
        int numStates = DFA144_transitionS.length;
        DFA144_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA144_transition[i] = DFA.unpackEncodedString(DFA144_transitionS[i]);
        }
    }

    class DFA144 extends DFA {

        public DFA144(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 144;
            this.eot = DFA144_eot;
            this.eof = DFA144_eof;
            this.min = DFA144_min;
            this.max = DFA144_max;
            this.accept = DFA144_accept;
            this.special = DFA144_special;
            this.transition = DFA144_transition;
        }
        public String getDescription() {
            return "402:42: ( INITIALLY DEFERRED | INITIALLY IMMEDIATE )?";
        }
    }
    static final String DFA164_eotS =
        "\14\uffff";
    static final String DFA164_eofS =
        "\14\uffff";
    static final String DFA164_minS =
        "\1\40\1\44\12\uffff";
    static final String DFA164_maxS =
        "\1\u00b3\1\u00af\12\uffff";
    static final String DFA164_acceptS =
        "\2\uffff\1\2\1\uffff\1\1\7\uffff";
    static final String DFA164_specialS =
        "\14\uffff}>";
    static final String[] DFA164_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\12\2\4\uffff"+
            "\3\2\3\uffff\70\2\1\1\34\2",
            "\1\2\2\uffff\1\4\132\uffff\1\2\3\uffff\1\2\1\uffff\1\2\44\uffff"+
            "\3\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA164_eot = DFA.unpackEncodedString(DFA164_eotS);
    static final short[] DFA164_eof = DFA.unpackEncodedString(DFA164_eofS);
    static final char[] DFA164_min = DFA.unpackEncodedStringToUnsignedChars(DFA164_minS);
    static final char[] DFA164_max = DFA.unpackEncodedStringToUnsignedChars(DFA164_maxS);
    static final short[] DFA164_accept = DFA.unpackEncodedString(DFA164_acceptS);
    static final short[] DFA164_special = DFA.unpackEncodedString(DFA164_specialS);
    static final short[][] DFA164_transition;

    static {
        int numStates = DFA164_transitionS.length;
        DFA164_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA164_transition[i] = DFA.unpackEncodedString(DFA164_transitionS[i]);
        }
    }

    class DFA164 extends DFA {

        public DFA164(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 164;
            this.eot = DFA164_eot;
            this.eof = DFA164_eof;
            this.min = DFA164_min;
            this.max = DFA164_max;
            this.accept = DFA164_accept;
            this.special = DFA164_special;
            this.transition = DFA164_transition;
        }
        public String getDescription() {
            return "430:48: ( IF NOT EXISTS )?";
        }
    }
    static final String DFA165_eotS =
        "\21\uffff";
    static final String DFA165_eofS =
        "\21\uffff";
    static final String DFA165_minS =
        "\1\40\2\44\16\uffff";
    static final String DFA165_maxS =
        "\1\u00b3\2\u00af\16\uffff";
    static final String DFA165_acceptS =
        "\3\uffff\1\1\1\2\14\uffff";
    static final String DFA165_specialS =
        "\21\uffff}>";
    static final String[] DFA165_transitionS = {
            "\3\2\2\uffff\2\2\1\uffff\3\2\6\uffff\3\2\27\uffff\1\2\1\1\10"+
            "\2\4\uffff\3\2\3\uffff\125\2",
            "\1\3\135\uffff\1\4\3\uffff\1\4\1\uffff\1\4\44\uffff\3\4",
            "\1\3\135\uffff\1\4\3\uffff\1\4\1\uffff\1\4\44\uffff\3\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA165_eot = DFA.unpackEncodedString(DFA165_eotS);
    static final short[] DFA165_eof = DFA.unpackEncodedString(DFA165_eofS);
    static final char[] DFA165_min = DFA.unpackEncodedStringToUnsignedChars(DFA165_minS);
    static final char[] DFA165_max = DFA.unpackEncodedStringToUnsignedChars(DFA165_maxS);
    static final short[] DFA165_accept = DFA.unpackEncodedString(DFA165_acceptS);
    static final short[] DFA165_special = DFA.unpackEncodedString(DFA165_specialS);
    static final short[][] DFA165_transition;

    static {
        int numStates = DFA165_transitionS.length;
        DFA165_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA165_transition[i] = DFA.unpackEncodedString(DFA165_transitionS[i]);
        }
    }

    class DFA165 extends DFA {

        public DFA165(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 165;
            this.eot = DFA165_eot;
            this.eof = DFA165_eof;
            this.min = DFA165_min;
            this.max = DFA165_max;
            this.accept = DFA165_accept;
            this.special = DFA165_special;
            this.transition = DFA165_transition;
        }
        public String getDescription() {
            return "430:65: (database_name= id DOT )?";
        }
    }
 

    public static final BitSet FOLLOW_sql_stmt_in_sql_stmt_list190 = new BitSet(new long[]{0x0000000100000002L,0x00200FB200040000L,0x00000060000B4344L});
    public static final BitSet FOLLOW_EXPLAIN_in_sql_stmt200 = new BitSet(new long[]{0x0000000B00000000L,0x00200FB200040000L,0x00000060000B4344L});
    public static final BitSet FOLLOW_QUERY_in_sql_stmt203 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_PLAN_in_sql_stmt205 = new BitSet(new long[]{0x0000000900000000L,0x00200FB200040000L,0x00000060000B4344L});
    public static final BitSet FOLLOW_sql_stmt_core_in_sql_stmt211 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_SEMI_in_sql_stmt213 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_pragma_stmt_in_sql_stmt_core224 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_attach_stmt_in_sql_stmt_core230 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_detach_stmt_in_sql_stmt_core236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_analyze_stmt_in_sql_stmt_core242 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_reindex_stmt_in_sql_stmt_core248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_vacuum_stmt_in_sql_stmt_core254 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_select_stmt_in_sql_stmt_core263 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_insert_stmt_in_sql_stmt_core269 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_update_stmt_in_sql_stmt_core275 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_delete_stmt_in_sql_stmt_core281 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_begin_stmt_in_sql_stmt_core287 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_commit_stmt_in_sql_stmt_core293 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rollback_stmt_in_sql_stmt_core299 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_savepoint_stmt_in_sql_stmt_core305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_release_stmt_in_sql_stmt_core311 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_create_virtual_table_stmt_in_sql_stmt_core320 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_create_table_stmt_in_sql_stmt_core326 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_drop_table_stmt_in_sql_stmt_core332 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_alter_table_stmt_in_sql_stmt_core338 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_create_view_stmt_in_sql_stmt_core344 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_drop_view_stmt_in_sql_stmt_core350 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_create_index_stmt_in_sql_stmt_core356 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_drop_index_stmt_in_sql_stmt_core362 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_create_trigger_stmt_in_sql_stmt_core368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_drop_trigger_stmt_in_sql_stmt_core374 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_in_qualified_table_name387 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_qualified_table_name389 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_qualified_table_name395 = new BitSet(new long[]{0x000000A000000002L});
    public static final BitSet FOLLOW_INDEXED_in_qualified_table_name398 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_BY_in_qualified_table_name400 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_qualified_table_name404 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_qualified_table_name408 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_INDEXED_in_qualified_table_name410 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_or_subexpr_in_expr419 = new BitSet(new long[]{0x0000010000000002L});
    public static final BitSet FOLLOW_OR_in_expr422 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_or_subexpr_in_expr425 = new BitSet(new long[]{0x0000010000000002L});
    public static final BitSet FOLLOW_and_subexpr_in_or_subexpr434 = new BitSet(new long[]{0x0000020000000002L});
    public static final BitSet FOLLOW_AND_in_or_subexpr437 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_and_subexpr_in_or_subexpr440 = new BitSet(new long[]{0x0000020000000002L});
    public static final BitSet FOLLOW_eq_subexpr_in_and_subexpr449 = new BitSet(new long[]{0x0FFB888000000002L});
    public static final BitSet FOLLOW_cond_expr_in_and_subexpr451 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_cond_expr463 = new BitSet(new long[]{0x0F00008000000000L});
    public static final BitSet FOLLOW_match_op_in_cond_expr466 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_eq_subexpr_in_cond_expr470 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_ESCAPE_in_cond_expr473 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_eq_subexpr_in_cond_expr477 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_cond_expr505 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_IN_in_cond_expr508 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_cond_expr510 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_cond_expr512 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_cond_expr515 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_cond_expr517 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_cond_expr521 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_cond_expr543 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_IN_in_cond_expr546 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_cond_expr551 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_cond_expr553 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_cond_expr559 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ISNULL_in_cond_expr590 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOTNULL_in_cond_expr598 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IS_in_cond_expr606 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_NULL_in_cond_expr608 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_cond_expr616 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_NULL_in_cond_expr618 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IS_in_cond_expr626 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_NOT_in_cond_expr628 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_NULL_in_cond_expr630 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_cond_expr641 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_BETWEEN_in_cond_expr644 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_eq_subexpr_in_cond_expr648 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_AND_in_cond_expr650 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_eq_subexpr_in_cond_expr654 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_cond_expr680 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_eq_subexpr_in_cond_expr697 = new BitSet(new long[]{0x00F0000000000002L});
    public static final BitSet FOLLOW_set_in_match_op0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_neq_subexpr_in_eq_subexpr730 = new BitSet(new long[]{0xF000000000000002L});
    public static final BitSet FOLLOW_set_in_eq_subexpr733 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_neq_subexpr_in_eq_subexpr750 = new BitSet(new long[]{0xF000000000000002L});
    public static final BitSet FOLLOW_bit_subexpr_in_neq_subexpr759 = new BitSet(new long[]{0x0000000000000002L,0x000000000000000FL});
    public static final BitSet FOLLOW_set_in_neq_subexpr762 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_bit_subexpr_in_neq_subexpr779 = new BitSet(new long[]{0x0000000000000002L,0x000000000000000FL});
    public static final BitSet FOLLOW_add_subexpr_in_bit_subexpr788 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000030L});
    public static final BitSet FOLLOW_set_in_bit_subexpr791 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_add_subexpr_in_bit_subexpr800 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000030L});
    public static final BitSet FOLLOW_mul_subexpr_in_add_subexpr809 = new BitSet(new long[]{0x0000000000000002L,0x00000000000001C0L});
    public static final BitSet FOLLOW_set_in_add_subexpr812 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_mul_subexpr_in_add_subexpr825 = new BitSet(new long[]{0x0000000000000002L,0x00000000000001C0L});
    public static final BitSet FOLLOW_con_subexpr_in_mul_subexpr834 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000200L});
    public static final BitSet FOLLOW_DOUBLE_PIPE_in_mul_subexpr837 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_con_subexpr_in_mul_subexpr840 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000200L});
    public static final BitSet FOLLOW_unary_subexpr_in_con_subexpr849 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unary_op_in_con_subexpr853 = new BitSet(new long[]{0x000E176700000000L,0xFFFFFFFFFFFFF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_unary_subexpr_in_con_subexpr855 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_unary_op0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_expr_in_unary_subexpr889 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000800L});
    public static final BitSet FOLLOW_COLLATE_in_unary_subexpr892 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_ID_in_unary_subexpr897 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_literal_value_in_atom_expr909 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_bind_parameter_in_atom_expr915 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_in_atom_expr925 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_atom_expr927 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_atom_expr933 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_atom_expr935 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_ID_in_atom_expr941 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom_expr970 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_atom_expr972 = new BitSet(new long[]{0x000E57E700000000L,0xFFFFFFFFFFFFFC70L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_DISTINCT_in_atom_expr975 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_atom_expr980 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_atom_expr983 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_atom_expr987 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_ASTERISK_in_atom_expr993 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_atom_expr997 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_atom_expr1022 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_atom_expr1025 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_atom_expr1027 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CAST_in_atom_expr1034 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_atom_expr1037 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_atom_expr1040 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_AS_in_atom_expr1042 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_type_name_in_atom_expr1045 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_atom_expr1047 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_in_atom_expr1056 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_atom_expr1061 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_when_expr_in_atom_expr1065 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ELSE_in_atom_expr1069 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_atom_expr1073 = new BitSet(new long[]{0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_END_in_atom_expr1077 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_raise_function_in_atom_expr1100 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHEN_in_when_expr1110 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_when_expr1114 = new BitSet(new long[]{0x0000000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_THEN_in_when_expr1116 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_when_expr1120 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTEGER_in_literal_value1142 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOAT_in_literal_value1156 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_literal_value1170 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BLOB_in_literal_value1184 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NULL_in_literal_value1198 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CURRENT_TIME_in_literal_value1204 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CURRENT_DATE_in_literal_value1218 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CURRENT_TIMESTAMP_in_literal_value1232 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_QUESTION_in_bind_parameter1253 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_QUESTION_in_bind_parameter1263 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_INTEGER_in_bind_parameter1267 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLON_in_bind_parameter1282 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_bind_parameter1286 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_in_bind_parameter1301 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_bind_parameter1305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RAISE_in_raise_function1326 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_raise_function1329 = new BitSet(new long[]{0x0000000000000000L,0x0000000F00000000L});
    public static final BitSet FOLLOW_IGNORE_in_raise_function1333 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_set_in_raise_function1337 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_COMMA_in_raise_function1349 = new BitSet(new long[]{0x0000000000000000L,0x0000000000800000L});
    public static final BitSet FOLLOW_STRING_in_raise_function1354 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_raise_function1357 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_type_name1367 = new BitSet(new long[]{0x0000100000000002L,0x0000000000001000L});
    public static final BitSet FOLLOW_LPAREN_in_type_name1371 = new BitSet(new long[]{0x0000000000000000L,0x0000000000600030L});
    public static final BitSet FOLLOW_signed_number_in_type_name1375 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_type_name1378 = new BitSet(new long[]{0x0000000000000000L,0x0000000000600030L});
    public static final BitSet FOLLOW_signed_number_in_type_name1382 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_type_name1386 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_signed_number1417 = new BitSet(new long[]{0x0000000000000000L,0x0000000000600000L});
    public static final BitSet FOLLOW_set_in_signed_number1426 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRAGMA_in_pragma_stmt1440 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_pragma_stmt1445 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_pragma_stmt1447 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_pragma_stmt1453 = new BitSet(new long[]{0x0010100000000002L});
    public static final BitSet FOLLOW_EQUALS_in_pragma_stmt1456 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8EFFF830L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_pragma_value_in_pragma_stmt1458 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_pragma_stmt1462 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8EFFF830L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_pragma_value_in_pragma_stmt1464 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_pragma_stmt1466 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_signed_number_in_pragma_value1495 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_in_pragma_value1508 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_pragma_value1521 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ATTACH_in_attach_stmt1539 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E9FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_DATABASE_in_attach_stmt1542 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E9FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_STRING_in_attach_stmt1549 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_id_in_attach_stmt1553 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_AS_in_attach_stmt1556 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_attach_stmt1560 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DETACH_in_detach_stmt1568 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_DATABASE_in_detach_stmt1571 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_detach_stmt1577 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ANALYZE_in_analyze_stmt1585 = new BitSet(new long[]{0x000E076700000002L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_analyze_stmt1590 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_in_analyze_stmt1596 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_analyze_stmt1598 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_analyze_stmt1602 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REINDEX_in_reindex_stmt1612 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_reindex_stmt1617 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_reindex_stmt1619 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_reindex_stmt1625 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VACUUM_in_vacuum_stmt1633 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_OR_in_operation_conflict_clause1644 = new BitSet(new long[]{0x0000000000000000L,0x0000080F00000000L});
    public static final BitSet FOLLOW_set_in_operation_conflict_clause1646 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expr_in_ordering_term1671 = new BitSet(new long[]{0x0000000000000002L,0x0000300000000000L});
    public static final BitSet FOLLOW_ASC_in_ordering_term1676 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DESC_in_ordering_term1680 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ORDER_in_operation_limited_clause1710 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_BY_in_operation_limited_clause1712 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ordering_term_in_operation_limited_clause1714 = new BitSet(new long[]{0x0000200000000000L,0x0000800000000000L});
    public static final BitSet FOLLOW_COMMA_in_operation_limited_clause1717 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ordering_term_in_operation_limited_clause1719 = new BitSet(new long[]{0x0000200000000000L,0x0000800000000000L});
    public static final BitSet FOLLOW_LIMIT_in_operation_limited_clause1727 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_INTEGER_in_operation_limited_clause1731 = new BitSet(new long[]{0x0000200000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_set_in_operation_limited_clause1734 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_INTEGER_in_operation_limited_clause1744 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_select_list_in_select_stmt1754 = new BitSet(new long[]{0x0000000000000002L,0x0000C00000000000L});
    public static final BitSet FOLLOW_ORDER_in_select_stmt1759 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_BY_in_select_stmt1761 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ordering_term_in_select_stmt1763 = new BitSet(new long[]{0x0000200000000002L,0x0000800000000000L});
    public static final BitSet FOLLOW_COMMA_in_select_stmt1766 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ordering_term_in_select_stmt1768 = new BitSet(new long[]{0x0000200000000002L,0x0000800000000000L});
    public static final BitSet FOLLOW_LIMIT_in_select_stmt1777 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_INTEGER_in_select_stmt1781 = new BitSet(new long[]{0x0000200000000002L,0x0001000000000000L});
    public static final BitSet FOLLOW_OFFSET_in_select_stmt1785 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_COMMA_in_select_stmt1789 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_INTEGER_in_select_stmt1794 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_select_core_in_select_list1839 = new BitSet(new long[]{0x0000000000000002L,0x001A000000000000L});
    public static final BitSet FOLLOW_select_op_in_select_list1842 = new BitSet(new long[]{0x0000000000000000L,0x0020000000000000L});
    public static final BitSet FOLLOW_select_core_in_select_list1845 = new BitSet(new long[]{0x0000000000000002L,0x001A000000000000L});
    public static final BitSet FOLLOW_UNION_in_select_op1854 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L});
    public static final BitSet FOLLOW_ALL_in_select_op1858 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTERSECT_in_select_op1864 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXCEPT_in_select_op1868 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SELECT_in_select_core1877 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC70L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ALL_in_select_core1880 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC70L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_DISTINCT_in_select_core1884 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC70L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_result_column_in_select_core1888 = new BitSet(new long[]{0x0000200000000002L,0x01C0000000000000L});
    public static final BitSet FOLLOW_COMMA_in_select_core1891 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC70L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_result_column_in_select_core1893 = new BitSet(new long[]{0x0000200000000002L,0x01C0000000000000L});
    public static final BitSet FOLLOW_FROM_in_select_core1898 = new BitSet(new long[]{0x000E176700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_join_source_in_select_core1900 = new BitSet(new long[]{0x0000000000000002L,0x0180000000000000L});
    public static final BitSet FOLLOW_WHERE_in_select_core1905 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_select_core1909 = new BitSet(new long[]{0x0000000000000002L,0x0100000000000000L});
    public static final BitSet FOLLOW_GROUP_in_select_core1917 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_BY_in_select_core1919 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ordering_term_in_select_core1921 = new BitSet(new long[]{0x0000200000000002L,0x0200000000000000L});
    public static final BitSet FOLLOW_COMMA_in_select_core1924 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_ordering_term_in_select_core1926 = new BitSet(new long[]{0x0000200000000002L,0x0200000000000000L});
    public static final BitSet FOLLOW_HAVING_in_select_core1931 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_select_core1935 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ASTERISK_in_result_column2005 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_in_result_column2013 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_result_column2015 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_ASTERISK_in_result_column2017 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expr_in_result_column2032 = new BitSet(new long[]{0x000E076700000002L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_AS_in_result_column2036 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_result_column2042 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_single_source_in_join_source2063 = new BitSet(new long[]{0x0000200000000002L,0xFC00000000000000L});
    public static final BitSet FOLLOW_join_op_in_join_source2066 = new BitSet(new long[]{0x000E176700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_single_source_in_join_source2069 = new BitSet(new long[]{0x0000200000000002L,0xFC00000000000000L,0x0000000000000003L});
    public static final BitSet FOLLOW_join_constraint_in_join_source2072 = new BitSet(new long[]{0x0000200000000002L,0xFC00000000000000L});
    public static final BitSet FOLLOW_id_in_single_source2089 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_single_source2091 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_ID_in_single_source2097 = new BitSet(new long[]{0x000000A000000002L,0x0000000000009000L});
    public static final BitSet FOLLOW_AS_in_single_source2101 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_ID_in_single_source2107 = new BitSet(new long[]{0x000000A000000002L});
    public static final BitSet FOLLOW_INDEXED_in_single_source2112 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_BY_in_single_source2114 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_single_source2118 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_single_source2122 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_INDEXED_in_single_source2124 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_single_source2165 = new BitSet(new long[]{0x0000000000000000L,0x0020000000000000L});
    public static final BitSet FOLLOW_select_stmt_in_single_source2167 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_single_source2169 = new BitSet(new long[]{0x0000000000000002L,0x0000000000009000L});
    public static final BitSet FOLLOW_AS_in_single_source2173 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_ID_in_single_source2179 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_single_source2201 = new BitSet(new long[]{0x000E176700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_join_source_in_single_source2204 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_single_source2206 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COMMA_in_join_op2217 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NATURAL_in_join_op2224 = new BitSet(new long[]{0x0000000000000000L,0xF800000000000000L});
    public static final BitSet FOLLOW_LEFT_in_join_op2230 = new BitSet(new long[]{0x0000000000000000L,0x9000000000000000L});
    public static final BitSet FOLLOW_OUTER_in_join_op2235 = new BitSet(new long[]{0x0000000000000000L,0x8000000000000000L});
    public static final BitSet FOLLOW_INNER_in_join_op2241 = new BitSet(new long[]{0x0000000000000000L,0x8000000000000000L});
    public static final BitSet FOLLOW_CROSS_in_join_op2245 = new BitSet(new long[]{0x0000000000000000L,0x8000000000000000L});
    public static final BitSet FOLLOW_JOIN_in_join_op2248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ON_in_join_constraint2259 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_join_constraint2262 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_USING_in_join_constraint2268 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_join_constraint2270 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_join_constraint2274 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_join_constraint2277 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_join_constraint2281 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_join_constraint2285 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INSERT_in_insert_stmt2304 = new BitSet(new long[]{0x0000010000000000L,0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_operation_conflict_clause_in_insert_stmt2307 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_REPLACE_in_insert_stmt2313 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000008L});
    public static final BitSet FOLLOW_INTO_in_insert_stmt2316 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_insert_stmt2321 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_insert_stmt2323 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_insert_stmt2329 = new BitSet(new long[]{0x0000100000000000L,0x0020000000000000L,0x0000000000000030L});
    public static final BitSet FOLLOW_LPAREN_in_insert_stmt2336 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_insert_stmt2340 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_insert_stmt2343 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_insert_stmt2347 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_insert_stmt2351 = new BitSet(new long[]{0x0000000000000000L,0x0020000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_VALUES_in_insert_stmt2360 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_insert_stmt2362 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_insert_stmt2366 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_insert_stmt2369 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_insert_stmt2373 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_insert_stmt2377 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_select_stmt_in_insert_stmt2381 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DEFAULT_in_insert_stmt2388 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_VALUES_in_insert_stmt2390 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UPDATE_in_update_stmt2400 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_operation_conflict_clause_in_update_stmt2403 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_qualified_table_name_in_update_stmt2407 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_SET_in_update_stmt2411 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_update_set_in_update_stmt2415 = new BitSet(new long[]{0x0000200000000002L,0x0080C00000000000L});
    public static final BitSet FOLLOW_COMMA_in_update_stmt2418 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_update_set_in_update_stmt2422 = new BitSet(new long[]{0x0000200000000002L,0x0080C00000000000L});
    public static final BitSet FOLLOW_WHERE_in_update_stmt2427 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_update_stmt2429 = new BitSet(new long[]{0x0000000000000002L,0x0000C00000000000L});
    public static final BitSet FOLLOW_operation_limited_clause_in_update_stmt2434 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_in_update_set2445 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_EQUALS_in_update_set2447 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_update_set2449 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DELETE_in_delete_stmt2457 = new BitSet(new long[]{0x0000000000000000L,0x0040000000000000L});
    public static final BitSet FOLLOW_FROM_in_delete_stmt2459 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_qualified_table_name_in_delete_stmt2461 = new BitSet(new long[]{0x0000000000000002L,0x0080C00000000000L});
    public static final BitSet FOLLOW_WHERE_in_delete_stmt2464 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_delete_stmt2466 = new BitSet(new long[]{0x0000000000000002L,0x0000C00000000000L});
    public static final BitSet FOLLOW_operation_limited_clause_in_delete_stmt2471 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BEGIN_in_begin_stmt2481 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000003C00L});
    public static final BitSet FOLLOW_set_in_begin_stmt2483 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_TRANSACTION_in_begin_stmt2497 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_commit_stmt2507 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000002000L});
    public static final BitSet FOLLOW_TRANSACTION_in_commit_stmt2516 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ROLLBACK_in_rollback_stmt2526 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x000000000000A000L});
    public static final BitSet FOLLOW_TRANSACTION_in_rollback_stmt2529 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_TO_in_rollback_stmt2534 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_SAVEPOINT_in_rollback_stmt2537 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_rollback_stmt2543 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SAVEPOINT_in_savepoint_stmt2553 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_savepoint_stmt2557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RELEASE_in_release_stmt2565 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_SAVEPOINT_in_release_stmt2568 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_release_stmt2574 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ON_in_table_conflict_clause2586 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
    public static final BitSet FOLLOW_CONFLICT_in_table_conflict_clause2589 = new BitSet(new long[]{0x0000000000000000L,0x0000080F00000000L});
    public static final BitSet FOLLOW_set_in_table_conflict_clause2592 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CREATE_in_create_virtual_table_stmt2619 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_VIRTUAL_in_create_virtual_table_stmt2621 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_TABLE_in_create_virtual_table_stmt2623 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_virtual_table_stmt2628 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_create_virtual_table_stmt2630 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_virtual_table_stmt2636 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_USING_in_create_virtual_table_stmt2640 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_virtual_table_stmt2644 = new BitSet(new long[]{0x0000100000000002L});
    public static final BitSet FOLLOW_LPAREN_in_create_virtual_table_stmt2647 = new BitSet(new long[]{0x0F0F8FE700000000L,0xFFFFFFFF8E1FF800L,0x000FFDFFFDFFFFFFL});
    public static final BitSet FOLLOW_column_def_in_create_virtual_table_stmt2649 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_create_virtual_table_stmt2652 = new BitSet(new long[]{0x0F0F8FE700000000L,0xFFFFFFFF8E1FF800L,0x000FFDFFFDFFFFFFL});
    public static final BitSet FOLLOW_column_def_in_create_virtual_table_stmt2654 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_create_virtual_table_stmt2658 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CREATE_in_create_table_stmt2668 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000600000L});
    public static final BitSet FOLLOW_TEMPORARY_in_create_table_stmt2670 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_TABLE_in_create_table_stmt2673 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_create_table_stmt2676 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_NOT_in_create_table_stmt2678 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_create_table_stmt2680 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_table_stmt2687 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_create_table_stmt2689 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_table_stmt2695 = new BitSet(new long[]{0x0000100000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_LPAREN_in_create_table_stmt2701 = new BitSet(new long[]{0x0F0F8FE700000000L,0xFFFFFFFF8E1FF800L,0x000FFDFFFDFFFFFFL});
    public static final BitSet FOLLOW_column_def_in_create_table_stmt2703 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_create_table_stmt2706 = new BitSet(new long[]{0x0F0F8FE700000000L,0xFFFFFFFF8E1FF800L,0x000FFDFFFDFFFFFFL});
    public static final BitSet FOLLOW_column_def_in_create_table_stmt2708 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_create_table_stmt2713 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x00000000E6000000L});
    public static final BitSet FOLLOW_table_constraint_in_create_table_stmt2715 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_create_table_stmt2719 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AS_in_create_table_stmt2725 = new BitSet(new long[]{0x0000000000000000L,0x0020000000000000L});
    public static final BitSet FOLLOW_select_stmt_in_create_table_stmt2727 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_column_def_in_column_def2783 = new BitSet(new long[]{0x0000008000000002L,0x0000000000001800L,0x0000000166000020L});
    public static final BitSet FOLLOW_type_name_in_column_def2785 = new BitSet(new long[]{0x0000008000000002L,0x0000000000000800L,0x0000000166000020L});
    public static final BitSet FOLLOW_column_constraint_in_column_def2788 = new BitSet(new long[]{0x0000008000000002L,0x0000000000000800L,0x0000000166000020L});
    public static final BitSet FOLLOW_CONSTRAINT_in_column_constraint2814 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_column_constraint2818 = new BitSet(new long[]{0x0000008000000000L,0x0000000000000800L,0x0000000166000020L});
    public static final BitSet FOLLOW_column_constraint_pk_in_column_constraint2826 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_column_constraint_not_null_in_column_constraint2832 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_column_constraint_unique_in_column_constraint2838 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_column_constraint_check_in_column_constraint2844 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_column_constraint_default_in_column_constraint2850 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_column_constraint_collate_in_column_constraint2856 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fk_clause_in_column_constraint2862 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRIMARY_in_column_constraint_pk2917 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_KEY_in_column_constraint_pk2920 = new BitSet(new long[]{0x0000000000000002L,0x0000300000000000L,0x0000000010000001L});
    public static final BitSet FOLLOW_set_in_column_constraint_pk2923 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000010000001L});
    public static final BitSet FOLLOW_table_conflict_clause_in_column_constraint_pk2932 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000010000000L});
    public static final BitSet FOLLOW_AUTOINCREMENT_in_column_constraint_pk2936 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_column_constraint_not_null2945 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_NULL_in_column_constraint_not_null2947 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_table_conflict_clause_in_column_constraint_not_null2949 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UNIQUE_in_column_constraint_unique2966 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_table_conflict_clause_in_column_constraint_unique2969 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CHECK_in_column_constraint_check2977 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_column_constraint_check2980 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_column_constraint_check2983 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_column_constraint_check2985 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTEGER_in_numeric_literal_value2996 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FLOAT_in_numeric_literal_value3010 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_signed_default_number3028 = new BitSet(new long[]{0x0000000000000000L,0x0000000000600000L});
    public static final BitSet FOLLOW_numeric_literal_value_in_signed_default_number3037 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DEFAULT_in_column_constraint_default3045 = new BitSet(new long[]{0x0004100000000000L,0x000000000FE00030L});
    public static final BitSet FOLLOW_signed_default_number_in_column_constraint_default3049 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_literal_value_in_column_constraint_default3053 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_column_constraint_default3057 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_column_constraint_default3060 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_column_constraint_default3062 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLLATE_in_column_constraint_collate3071 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_column_constraint_collate3076 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONSTRAINT_in_table_constraint3085 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_table_constraint3089 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x00000000E6000000L});
    public static final BitSet FOLLOW_table_constraint_pk_in_table_constraint3097 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_table_constraint_unique_in_table_constraint3103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_table_constraint_check_in_table_constraint3109 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_table_constraint_fk_in_table_constraint3115 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRIMARY_in_table_constraint_pk3155 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_KEY_in_table_constraint_pk3157 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_table_constraint_pk3161 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_table_constraint_pk3165 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_table_constraint_pk3168 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_table_constraint_pk3172 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_table_constraint_pk3176 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_table_conflict_clause_in_table_constraint_pk3178 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UNIQUE_in_table_constraint_unique3203 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_table_constraint_unique3207 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_table_constraint_unique3211 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_table_constraint_unique3214 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_table_constraint_unique3218 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_table_constraint_unique3222 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_table_conflict_clause_in_table_constraint_unique3224 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CHECK_in_table_constraint_check3249 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_table_constraint_check3252 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_table_constraint_check3255 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_RPAREN_in_table_constraint_check3257 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOREIGN_in_table_constraint_fk3265 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000008000000L});
    public static final BitSet FOLLOW_KEY_in_table_constraint_fk3267 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_table_constraint_fk3269 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_table_constraint_fk3273 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_table_constraint_fk3276 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_table_constraint_fk3280 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_table_constraint_fk3284 = new BitSet(new long[]{0x0000008000000000L,0x0000000000000800L,0x0000000166000020L});
    public static final BitSet FOLLOW_fk_clause_in_table_constraint_fk3286 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REFERENCES_in_fk_clause3309 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_fk_clause3313 = new BitSet(new long[]{0x0800108000000002L,0x0000000000000000L,0x0000000800000001L});
    public static final BitSet FOLLOW_LPAREN_in_fk_clause3316 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_fk_clause3320 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_fk_clause3323 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_fk_clause3327 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_fk_clause3331 = new BitSet(new long[]{0x0800008000000002L,0x0000000000000000L,0x0000000800000001L});
    public static final BitSet FOLLOW_fk_clause_action_in_fk_clause3337 = new BitSet(new long[]{0x0800008000000002L,0x0000000000000000L,0x0000000800000001L});
    public static final BitSet FOLLOW_fk_clause_deferrable_in_fk_clause3340 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ON_in_fk_clause_action3374 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000144L});
    public static final BitSet FOLLOW_set_in_fk_clause_action3377 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000600000080L});
    public static final BitSet FOLLOW_SET_in_fk_clause_action3390 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_NULL_in_fk_clause_action3393 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SET_in_fk_clause_action3397 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_DEFAULT_in_fk_clause_action3400 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASCADE_in_fk_clause_action3404 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RESTRICT_in_fk_clause_action3408 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MATCH_in_fk_clause_action3415 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_fk_clause_action3418 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_fk_clause_deferrable3426 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000800000000L});
    public static final BitSet FOLLOW_DEFERRABLE_in_fk_clause_deferrable3430 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000001000000000L});
    public static final BitSet FOLLOW_INITIALLY_in_fk_clause_deferrable3434 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_DEFERRED_in_fk_clause_deferrable3437 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INITIALLY_in_fk_clause_deferrable3441 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_IMMEDIATE_in_fk_clause_deferrable3444 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DROP_in_drop_table_stmt3454 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_TABLE_in_drop_table_stmt3456 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_drop_table_stmt3459 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_drop_table_stmt3461 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_table_stmt3468 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_drop_table_stmt3470 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_table_stmt3476 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ALTER_in_alter_table_stmt3506 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_TABLE_in_alter_table_stmt3508 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_alter_table_stmt3513 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_alter_table_stmt3515 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_alter_table_stmt3521 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000018000000000L});
    public static final BitSet FOLLOW_RENAME_in_alter_table_stmt3524 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_TO_in_alter_table_stmt3526 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_alter_table_stmt3530 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ADD_in_alter_table_stmt3534 = new BitSet(new long[]{0x0F0F8FE700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFDFFFFFFL});
    public static final BitSet FOLLOW_COLUMN_in_alter_table_stmt3537 = new BitSet(new long[]{0x0F0F8FE700000000L,0xFFFFFFFF8E1FF800L,0x000FFDFFFDFFFFFFL});
    public static final BitSet FOLLOW_column_def_in_alter_table_stmt3541 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CREATE_in_create_view_stmt3550 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000040000400000L});
    public static final BitSet FOLLOW_TEMPORARY_in_create_view_stmt3552 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000040000000000L});
    public static final BitSet FOLLOW_VIEW_in_create_view_stmt3555 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_create_view_stmt3558 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_NOT_in_create_view_stmt3560 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_create_view_stmt3562 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_view_stmt3569 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_create_view_stmt3571 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_view_stmt3577 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_AS_in_create_view_stmt3579 = new BitSet(new long[]{0x0000000000000000L,0x0020000000000000L});
    public static final BitSet FOLLOW_select_stmt_in_create_view_stmt3581 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DROP_in_drop_view_stmt3589 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000040000000000L});
    public static final BitSet FOLLOW_VIEW_in_drop_view_stmt3591 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_drop_view_stmt3594 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_drop_view_stmt3596 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_view_stmt3603 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_drop_view_stmt3605 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_view_stmt3611 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CREATE_in_create_index_stmt3619 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000080020000000L});
    public static final BitSet FOLLOW_UNIQUE_in_create_index_stmt3622 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000080000000000L});
    public static final BitSet FOLLOW_INDEX_in_create_index_stmt3626 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_create_index_stmt3629 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_NOT_in_create_index_stmt3631 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_create_index_stmt3633 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_index_stmt3640 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_create_index_stmt3642 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_index_stmt3648 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_ON_in_create_index_stmt3652 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_index_stmt3656 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_LPAREN_in_create_index_stmt3658 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_indexed_column_in_create_index_stmt3662 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_COMMA_in_create_index_stmt3665 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_indexed_column_in_create_index_stmt3669 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_RPAREN_in_create_index_stmt3673 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_id_in_indexed_column3719 = new BitSet(new long[]{0x0000000000000002L,0x0000300000000800L});
    public static final BitSet FOLLOW_COLLATE_in_indexed_column3722 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_indexed_column3726 = new BitSet(new long[]{0x0000000000000002L,0x0000300000000000L});
    public static final BitSet FOLLOW_ASC_in_indexed_column3731 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DESC_in_indexed_column3735 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DROP_in_drop_index_stmt3766 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000080000000000L});
    public static final BitSet FOLLOW_INDEX_in_drop_index_stmt3768 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_drop_index_stmt3771 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_drop_index_stmt3773 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_index_stmt3780 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_drop_index_stmt3782 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_index_stmt3788 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CREATE_in_create_trigger_stmt3818 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000100000400000L});
    public static final BitSet FOLLOW_TEMPORARY_in_create_trigger_stmt3820 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000100000000000L});
    public static final BitSet FOLLOW_TRIGGER_in_create_trigger_stmt3823 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_create_trigger_stmt3826 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_NOT_in_create_trigger_stmt3828 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_create_trigger_stmt3830 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_trigger_stmt3837 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_create_trigger_stmt3839 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_trigger_stmt3845 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000E00000000144L});
    public static final BitSet FOLLOW_BEFORE_in_create_trigger_stmt3850 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000144L});
    public static final BitSet FOLLOW_AFTER_in_create_trigger_stmt3854 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000144L});
    public static final BitSet FOLLOW_INSTEAD_in_create_trigger_stmt3858 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0001000000000000L});
    public static final BitSet FOLLOW_OF_in_create_trigger_stmt3860 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000144L});
    public static final BitSet FOLLOW_DELETE_in_create_trigger_stmt3865 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_INSERT_in_create_trigger_stmt3869 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_UPDATE_in_create_trigger_stmt3873 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0001000000000001L});
    public static final BitSet FOLLOW_OF_in_create_trigger_stmt3876 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_trigger_stmt3880 = new BitSet(new long[]{0x0000200000000000L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_COMMA_in_create_trigger_stmt3883 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_trigger_stmt3887 = new BitSet(new long[]{0x0000200000000000L,0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_ON_in_create_trigger_stmt3896 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_create_trigger_stmt3900 = new BitSet(new long[]{0x0000000000000000L,0x0000000000080000L,0x0002000000000200L});
    public static final BitSet FOLLOW_FOR_in_create_trigger_stmt3903 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0004000000000000L});
    public static final BitSet FOLLOW_EACH_in_create_trigger_stmt3905 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0008000000000000L});
    public static final BitSet FOLLOW_ROW_in_create_trigger_stmt3907 = new BitSet(new long[]{0x0000000000000000L,0x0000000000080000L,0x0000000000000200L});
    public static final BitSet FOLLOW_WHEN_in_create_trigger_stmt3912 = new BitSet(new long[]{0x000E17E700000000L,0xFFFFFFFFFFFFFC30L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_expr_in_create_trigger_stmt3914 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_BEGIN_in_create_trigger_stmt3920 = new BitSet(new long[]{0x0000000000000000L,0x0020080000000000L,0x0000000000000144L});
    public static final BitSet FOLLOW_update_stmt_in_create_trigger_stmt3924 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_insert_stmt_in_create_trigger_stmt3928 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_delete_stmt_in_create_trigger_stmt3932 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_select_stmt_in_create_trigger_stmt3936 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_SEMI_in_create_trigger_stmt3939 = new BitSet(new long[]{0x0000000000000000L,0x0020080000040000L,0x0000000000000144L});
    public static final BitSet FOLLOW_END_in_create_trigger_stmt3943 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_DROP_in_drop_trigger_stmt3951 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000100000000000L});
    public static final BitSet FOLLOW_TRIGGER_in_drop_trigger_stmt3953 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_IF_in_drop_trigger_stmt3956 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000001000000L});
    public static final BitSet FOLLOW_EXISTS_in_drop_trigger_stmt3958 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_trigger_stmt3965 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_DOT_in_drop_trigger_stmt3967 = new BitSet(new long[]{0x000E076700000000L,0xFFFFFFFF8E1FF800L,0x000FFFFFFFFFFFFFL});
    public static final BitSet FOLLOW_id_in_drop_trigger_stmt3973 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_id3983 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_keyword_in_id3987 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_keyword3994 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_id_column_def4661 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_keyword_column_def_in_id_column_def4665 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_keyword_column_def4672 = new BitSet(new long[]{0x0000000000000002L});

}