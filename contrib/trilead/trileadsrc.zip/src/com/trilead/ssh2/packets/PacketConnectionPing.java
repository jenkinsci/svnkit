package com.trilead.ssh2.packets;

/**
 * PacketPing.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: PacketSessionStartShell.java,v 1.2 2005/08/24 17:54:09 cplattne Exp $
 */
public class PacketConnectionPing
{
        byte[] payload;

        public PacketConnectionPing()
        {
        }

        public byte[] getPayload()
        {
                if (payload == null)
                {
                        TypesWriter tw = new TypesWriter();
                        tw.writeByte(Packets.SSH_MSG_GLOBAL_REQUEST);
                        tw.writeString("ping");
                        tw.writeBoolean(true);
                        payload = tw.getBytes();
                }
                return payload;
        }
}
