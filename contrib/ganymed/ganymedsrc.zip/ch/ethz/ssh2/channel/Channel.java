
package ch.ethz.ssh2.channel;

/**
 * Channel.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: Channel.java,v 1.4 2005/08/11 12:47:30 cplattne Exp $
 */
public class Channel
{
	public static final int STATE_UNKNOWN = 0;
	public static final int STATE_OPENING = 1;
	public static final int STATE_OPEN = 2;
	public static final int STATE_CLOSED = 4;
	public static final int STATE_FAILED = 5;

	public static final int CHANNEL_BUFFER_SIZE = 30000;

	public ChannelManager cm;

	public int state = STATE_UNKNOWN;

	public boolean closeMessageRecv = false;

	public String reasonClosed = null;

	public int localID = -1;
	public int remoteID = -1;

	public int localWindow = -1;
	public int remoteWindow = -1;

	public int localMaxPacketSize = -1;
	public int remoteMaxPacketSize = -1;
	public int estimatedMaxDataLen = 0;

	public ChannelOutputStream stdinStream;
	public ChannelInputStream stdoutStream;
	public ChannelInputStream stderrStream;

	public byte[] stdoutBuffer = new byte[CHANNEL_BUFFER_SIZE];
	public byte[] stderrBuffer = new byte[CHANNEL_BUFFER_SIZE];

	public int stdoutReadpos = 0;
	public int stdoutWritepos = 0;
	
	public int stderrReadpos = 0;
	public int stderrWritepos = 0;

	public boolean stdoutEOF = false;
	public boolean stderrEOF = false;

	public Integer exit_status;
	public String exit_signal;

	/*
	 * Make sure that we never send a data/EOF/WindowChange after a CLOSE
	 * 
	 * This is a little bit complicated, but we have to do it in that way, since
	 * we cannot keep a lock on the channel during the send operation (this
	 * would block sometimes the receiver thread, and, in extreme cases, can
	 * lead to a deadlock on both sides of the connection (senders are blocked
	 * since the receive buffers on the other side are full, and receiver
	 * threads wait for the senders to finish). It all depends on the
	 * implementation on the other side. But we cannot make any assumptions, we
	 * have to assume the worst case.
	 * 
	 * Confused? Just believe me.
	 */

	public Object channelSendLock = new Object();
	public boolean closeMessageSent = false;
	/* Stop memory fragmentation by allocating this often used buffer */
	public byte[] msgWindowAdjust = new byte[9];

}
