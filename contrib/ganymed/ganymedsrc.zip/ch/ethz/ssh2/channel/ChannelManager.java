
package ch.ethz.ssh2.channel;

import java.io.IOException;
import java.util.Vector;

import ch.ethz.ssh2.log.Logger;
import ch.ethz.ssh2.packets.PacketChannelOpenConfirmation;
import ch.ethz.ssh2.packets.PacketOpenDirectTCPIPChannel;
import ch.ethz.ssh2.packets.PacketOpenSessionChannel;
import ch.ethz.ssh2.packets.PacketSessionExecCommand;
import ch.ethz.ssh2.packets.PacketSessionPtyRequest;
import ch.ethz.ssh2.packets.PacketSessionStartShell;
import ch.ethz.ssh2.packets.PacketSessionSubsystemRequest;
import ch.ethz.ssh2.packets.Packets;
import ch.ethz.ssh2.packets.TypesReader;
import ch.ethz.ssh2.transport.MessageHandler;
import ch.ethz.ssh2.transport.TransportManager;

/**
 * ChannelManager.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: ChannelManager.java,v 1.8 2005/08/12 23:37:18 cplattne Exp $
 */
public class ChannelManager implements MessageHandler
{
	private static final Logger log = Logger.getLogger(ChannelManager.class);

	private TransportManager tm;

	private int nextLocalChannel = 100;
	private Vector channels = new Vector();

	private Vector listenerThreads = new Vector();
	private boolean listenerThreadsAllowed = true;

	public ChannelManager(TransportManager tm)
	{
		this.tm = tm;
		tm.registerMessageHandler(this, 90, 100);
	}

	private Channel getChannel(int id)
	{
		synchronized (channels)
		{
			for (int i = 0; i < channels.size(); i++)
			{
				Channel c = (Channel) channels.elementAt(i);
				if (c.localID == id)
					return c;
			}
		}
		return null;
	}

	private void removeChannel(int id)
	{
		synchronized (channels)
		{
			for (int i = 0; i < channels.size(); i++)
			{
				Channel c = (Channel) channels.elementAt(i);
				if (c.localID == id)
				{
					channels.removeElementAt(i);
					break;
				}
			}
		}
	}

	private int addChannel(Channel c)
	{
		synchronized (channels)
		{
			channels.addElement(c);
			return nextLocalChannel++;
		}
	}

	public void closeChannel(Channel c, String reason) throws IOException
	{
		if (log.isEnabled())
			log.log(50, "closeChannel (" + c.remoteID + ")");

		synchronized (c)
		{
			if ((c.state != Channel.STATE_CLOSED) && (c.state != Channel.STATE_FAILED))
			{
				c.state = Channel.STATE_CLOSED;
				c.reasonClosed = reason;
			}
		}

		synchronized (c.channelSendLock)
		{
			if (c.closeMessageSent == true)
				return;

			if (log.isEnabled())
				log.log(50, "Sending SSH_MSG_CHANNEL_CLOSE (" + c.remoteID + ")");

			byte msg[] = new byte[1 + 4];

			msg[0] = Packets.SSH_MSG_CHANNEL_CLOSE;
			msg[1] = (byte) (c.remoteID >> 24);
			msg[2] = (byte) (c.remoteID >> 16);
			msg[3] = (byte) (c.remoteID >> 8);
			msg[4] = (byte) (c.remoteID);

			tm.sendMessage(msg);
			c.closeMessageSent = true;
		}

		synchronized (c)
		{
			/*
			 * If the server already sent the close, then we don't have to wait.
			 * Otherwise wait until we get an answer to our close message.
			 */

			while (c.closeMessageRecv == false)
			{
				try
				{
					c.wait();
				}
				catch (InterruptedException e)
				{
				}
			}
			removeChannel(c.localID);
		}
	}

	public void sendEOF(Channel c) throws IOException
	{
		synchronized (c.channelSendLock)
		{
			if (c.closeMessageSent == true)
				return;

			byte msg[] = new byte[1 + 4];

			msg[0] = Packets.SSH_MSG_CHANNEL_EOF;
			msg[1] = (byte) (c.remoteID >> 24);
			msg[2] = (byte) (c.remoteID >> 16);
			msg[3] = (byte) (c.remoteID >> 8);
			msg[4] = (byte) (c.remoteID);

			if (c.closeMessageSent == false)
				tm.sendMessage(msg);
		}
	}

	public void sendData(Channel c, byte[] buffer, int pos, int len) throws IOException
	{
		while (len > 0)
		{
			int thislen = 0;

			synchronized (c)
			{
				while (true)
				{
					if ((c.state != Channel.STATE_OPEN) && (c.state != Channel.STATE_CLOSED)
							&& (c.state != Channel.STATE_FAILED))
						throw new IOException("SSH channel in strange state. (" + c.state + ")");

					if ((c.state == Channel.STATE_CLOSED) || (c.state == Channel.STATE_FAILED))
						throw new IOException("SSH channel is closed. (" + c.reasonClosed + ")");

					if (c.remoteWindow > 0)
						break;

					try
					{
						c.wait();
					}
					catch (InterruptedException ignore)
					{
					}
				}

				thislen = (c.remoteWindow >= len) ? len : c.remoteWindow;

				if (thislen > c.estimatedMaxDataLen)
					thislen = c.estimatedMaxDataLen;

				c.remoteWindow -= thislen;
			}

			synchronized (c.channelSendLock)
			{
				if (c.closeMessageSent == true)
					throw new IOException("SSH channel is closed. (" + c.reasonClosed + ")");

				byte msg[] = new byte[1 + 8 + thislen];

				msg[0] = Packets.SSH_MSG_CHANNEL_DATA;
				msg[1] = (byte) (c.remoteID >> 24);
				msg[2] = (byte) (c.remoteID >> 16);
				msg[3] = (byte) (c.remoteID >> 8);
				msg[4] = (byte) (c.remoteID);
				msg[5] = (byte) (thislen >> 24);
				msg[6] = (byte) (thislen >> 16);
				msg[7] = (byte) (thislen >> 8);
				msg[8] = (byte) (thislen);

				System.arraycopy(buffer, pos, msg, 9, thislen);

				tm.sendMessage(msg);
			}

			pos += thislen;
			len -= thislen;
		}
	}

	public void registerThread(LocalAcceptThread thr) throws IOException
	{
		synchronized (listenerThreads)
		{
			if (listenerThreadsAllowed == false)
				throw new IOException("Too late, this connection is closed.");
			listenerThreads.addElement(thr);
		}
	}

	public Channel createDirectTCPIPChannel(String host_to_connect, int port_to_connect, String originator_IP_address,
			int originator_port) throws IOException
	{
		Channel c = new Channel();

		c.cm = this;

		c.localWindow = Channel.CHANNEL_BUFFER_SIZE;
		c.localMaxPacketSize = 35000 - 1024; // leave enough slack
		c.state = Channel.STATE_OPENING;

		c.stdinStream = new ChannelOutputStream(c);
		c.stdoutStream = new ChannelInputStream(c, false);
		c.stderrStream = new ChannelInputStream(c, true);

		c.localID = addChannel(c);

		PacketOpenDirectTCPIPChannel dtc = new PacketOpenDirectTCPIPChannel(c.localID, c.localWindow,
				c.localMaxPacketSize, host_to_connect, port_to_connect, originator_IP_address, originator_port);

		tm.sendMessage(dtc.getPayload());

		synchronized (c)
		{
			while (c.state == Channel.STATE_OPENING)
			{
				try
				{
					c.wait();
				}
				catch (InterruptedException ignore)
				{
				}
			}

			if (c.state != Channel.STATE_OPEN)
			{
				removeChannel(c.localID);

				String detail;

				if (c.state == Channel.STATE_CLOSED)
					detail = c.reasonClosed;
				else
					detail = "state: " + c.state;

				throw new IOException("Could not open session channel (" + detail + ")");
			}
		}

		return c;
	}

	public Channel createSessionChannel() throws IOException
	{
		Channel c = new Channel();

		c.cm = this;

		c.localWindow = Channel.CHANNEL_BUFFER_SIZE;
		c.localMaxPacketSize = 35000 - 1024; // leave enough slack
		c.state = Channel.STATE_OPENING;

		c.stdinStream = new ChannelOutputStream(c);
		c.stdoutStream = new ChannelInputStream(c, false);
		c.stderrStream = new ChannelInputStream(c, true);

		c.localID = addChannel(c);

		PacketOpenSessionChannel smo = new PacketOpenSessionChannel(c.localID, c.localWindow, c.localMaxPacketSize);
		tm.sendMessage(smo.getPayload());

		synchronized (c)
		{
			while (c.state == Channel.STATE_OPENING)
			{
				try
				{
					c.wait();
				}
				catch (InterruptedException ignore)
				{
				}
			}

			if (c.state != Channel.STATE_OPEN)
			{
				removeChannel(c.localID);

				String detail;

				if (c.state == Channel.STATE_CLOSED)
					detail = c.reasonClosed;
				else
					detail = "state: " + c.state;

				throw new IOException("Could not open session channel (" + detail + ")");
			}
		}

		return c;
	}

	public void requestPTY(Channel c, String term, int term_width_characters, int term_height_characters,
			int term_width_pixels, int term_height_pixels, byte[] terminal_modes) throws IOException
	{
		synchronized (c)
		{
			if (c.state != Channel.STATE_OPEN)
				throw new IOException("Cannot request PTY on this channel (" + c.reasonClosed + ")");
		}

		synchronized (c.channelSendLock)
		{
			if (c.closeMessageSent)
				throw new IOException("Cannot request PTY on this channel (" + c.reasonClosed + ")");

			PacketSessionPtyRequest spr = new PacketSessionPtyRequest(c.remoteID, true, term, term_width_characters,
					term_height_characters, term_width_pixels, term_height_pixels, terminal_modes);
			tm.sendMessage(spr.getPayload());
		}
	}

	public void requestSubSystem(Channel c, String subSystemName) throws IOException
	{
		synchronized (c)
		{
			if (c.state != Channel.STATE_OPEN)
				throw new IOException("Cannot request subsystem on this channel (" + c.reasonClosed + ")");
		}

		synchronized (c.channelSendLock)
		{
			if (c.closeMessageSent)
				throw new IOException("Cannot request subsystem on this channel (" + c.reasonClosed + ")");

			PacketSessionSubsystemRequest ssr = new PacketSessionSubsystemRequest(c.remoteID, true, subSystemName);
			tm.sendMessage(ssr.getPayload());
		}
	}

	public void execCommand(Channel c, String cmd) throws IOException
	{
		synchronized (c)
		{
			if (c.state != Channel.STATE_OPEN)
				throw new IOException("Cannot execute command on this channel (" + c.reasonClosed + ")");
		}

		synchronized (c.channelSendLock)
		{
			if (c.closeMessageSent)
				throw new IOException("Cannot execute command on this channel (" + c.reasonClosed + ")");

			PacketSessionExecCommand sm = new PacketSessionExecCommand(c.remoteID, true, cmd);
			tm.sendMessage(sm.getPayload());
		}
	}

	public void startShell(Channel c) throws IOException
	{
		synchronized (c)
		{
			if (c.state != Channel.STATE_OPEN)
				throw new IOException("Cannot start shell on this channel (" + c.reasonClosed + ")");
		}

		synchronized (c.channelSendLock)
		{
			if (c.closeMessageSent)
				throw new IOException("Cannot start shell on this channel (" + c.reasonClosed + ")");

			PacketSessionStartShell sm = new PacketSessionStartShell(c.remoteID, true);
			tm.sendMessage(sm.getPayload());
		}
	}

	public void msgChannelExtendedData(byte[] msg, int msglen) throws IOException
	{
		if (msglen <= 13)
			throw new IOException("SSH_MSG_CHANNEL_EXTENDED_DATA message has wrong size (" + msglen + ")");

		int id = ((msg[1] & 0xff) << 24) | ((msg[2] & 0xff) << 16) | ((msg[3] & 0xff) << 8) | (msg[4] & 0xff);

		int dataType = ((msg[5] & 0xff) << 24) | ((msg[6] & 0xff) << 16) | ((msg[7] & 0xff) << 8) | (msg[8] & 0xff);

		int len = ((msg[9] & 0xff) << 24) | ((msg[10] & 0xff) << 16) | ((msg[11] & 0xff) << 8) | (msg[12] & 0xff);

		Channel c = getChannel(id);

		if (c == null)
			throw new IOException("Unexpected SSH_MSG_CHANNEL_EXTENDED_DATA message for non-existent channel " + id);

		if (dataType != Packets.SSH_EXTENDED_DATA_STDERR)
			throw new IOException("SSH_MSG_CHANNEL_EXTENDED_DATA message has unknown type (" + dataType + ")");

		if (len != (msglen - 13))
			throw new IOException("SSH_MSG_CHANNEL_EXTENDED_DATA message has wrong len (calculated " + (msglen - 13)
					+ ", got " + len + ")");

		if (log.isEnabled())
			log.log(50, "Got SSH_MSG_CHANNEL_EXTENDED_DATA (" + id + ", " + len + ")");

		synchronized (c)
		{
			/* Discard data */
			if (c.state != Channel.STATE_OPEN)
				return;

			if (c.localWindow < len)
				throw new IOException("Remote sent too much data, does not fit into window.");

			c.localWindow -= len;

			System.arraycopy(msg, 13, c.stderrBuffer, c.stderrWritepos, len);
			c.stderrWritepos += len;

			c.notifyAll();
		}
	}

	/**
	 * Wait until more data (either on stdout or stderr) is available.
	 * 
	 * @param c
	 *            Channel
	 * @param timeout
	 *            in ms, 0 means no timeout.
	 * @return
	 *            <ul>
	 *            <li><code>0</code> if no more data will arrive (EOF on both
	 *            streams or connection broken).</li>
	 *            <li><code>1</code> if more data is available.</li>
	 *            <li><code>-1</code> if a timeout occurred.</li>
	 *            </ul>
	 */
	public int waitUntilDataAvailable(Channel c, long timeout)
	{
		long end_time = 0;
		boolean end_time_set = false;

		synchronized (c)
		{
			while (true)
			{
				int stdoutAvail = c.stdoutWritepos - c.stdoutReadpos;
				int stderrAvail = c.stderrWritepos - c.stderrReadpos;

				if ((stdoutAvail > 0) || (stderrAvail > 0))
					return 1;

				if (c.state != Channel.STATE_OPEN)
					return 0;

				if ((c.stdoutEOF) && (c.stderrEOF))
					return 0;

				if (timeout > 0)
				{
					/*
					 * Only get the clock from the underlying OS if we really
					 * need to.
					 */

					if (!end_time_set)
					{
						end_time = System.currentTimeMillis() + timeout;
						end_time_set = true;
					}
					else
					{
						timeout = end_time - System.currentTimeMillis();

						if (timeout <= 0)
							return -1;
					}
				}

				try
				{
					if (timeout > 0)
						c.wait(timeout);
					else
						c.wait();
				}
				catch (InterruptedException e)
				{
				}
			}
		}
	}

	public int getAvailable(Channel c, boolean extended) throws IOException
	{
		synchronized (c)
		{
			if (c.state == Channel.STATE_FAILED)
				throw new IOException("This SSH2 channel has failed.");

			if (extended)
			{
				int avail = c.stderrWritepos - c.stderrReadpos;
				return ((avail > 0) ? avail : (c.stderrEOF ? -1 : 0));
			}

			int avail = c.stdoutWritepos - c.stdoutReadpos;
			return ((avail > 0) ? avail : (c.stdoutEOF ? -1 : 0));
		}
	}

	public int getChannelData(Channel c, boolean extended, byte[] target, int off, int len) throws IOException
	{
		int copylen = 0;
		int increment = 0;

		synchronized (c)
		{
			if (c.state == Channel.STATE_FAILED)
				throw new IOException("This SSH2 channel has failed.");

			if (c.state != Channel.STATE_OPEN)
			{
				if (log.isEnabled())
					log.log(80, "getChannelData: NOTICE: channel is not in STATE_OPEN");
			}

			int stdoutAvail = 0;
			int stderrAvail = 0;

			while (true)
			{
				/*
				 * Data available? We have to return remaining data even if
				 * the channel is already closed.
				 */

				stdoutAvail = c.stdoutWritepos - c.stdoutReadpos;
				stderrAvail = c.stderrWritepos - c.stderrReadpos;

				if ((!extended) && (stdoutAvail != 0))
					break;

				if ((extended) && (stderrAvail != 0))
					break;

				/* Do not wait if more data will never arrive (CLOSED, FAILED) */

				if (c.state != Channel.STATE_OPEN)
				{
					if (log.isEnabled())
						log.log(80, "getChannelData: channel is not in STATE_OPEN");
					return -1;
				}

				/* Do not wait if more data will never arrive (EOF) */

				if (((!extended) && c.stdoutEOF) || (extended && c.stderrEOF))
					return -1;

				try
				{
					c.wait();
				}
				catch (InterruptedException ignore)
				{
				}
			}

			/* OK, there is some data. Return it. */

			if (!extended)
			{
				copylen = (stdoutAvail > len) ? len : stdoutAvail;
				System.arraycopy(c.stdoutBuffer, c.stdoutReadpos, target, off, copylen);
				c.stdoutReadpos += copylen;

				if (c.stdoutReadpos != c.stdoutWritepos)

					System.arraycopy(c.stdoutBuffer, c.stdoutReadpos, c.stdoutBuffer, 0, c.stdoutWritepos
							- c.stdoutReadpos);

				c.stdoutWritepos -= c.stdoutReadpos;
				c.stdoutReadpos = 0;
			}
			else
			{
				copylen = (stderrAvail > len) ? len : stderrAvail;
				System.arraycopy(c.stderrBuffer, c.stderrReadpos, target, off, copylen);
				c.stderrReadpos += copylen;

				if (c.stderrReadpos != c.stderrWritepos)

					System.arraycopy(c.stderrBuffer, c.stderrReadpos, c.stderrBuffer, 0, c.stderrWritepos
							- c.stderrReadpos);

				c.stderrWritepos -= c.stderrReadpos;
				c.stderrReadpos = 0;
			}

			if (c.state != Channel.STATE_OPEN)
				return copylen;

			if (c.localWindow < ((Channel.CHANNEL_BUFFER_SIZE + 1) / 2))
			{
				int minFreeSpace = Math.min(Channel.CHANNEL_BUFFER_SIZE - c.stdoutWritepos, Channel.CHANNEL_BUFFER_SIZE
						- c.stderrWritepos);

				increment = minFreeSpace - c.localWindow;
				c.localWindow = minFreeSpace;
			}
		}

		/*
		 * If a consumer reads stdout and stdin in parallel, we may end up with
		 * sending two msgWindowAdjust messages at the same time. Luckily, it
		 * does not matter in which order they arrive at the server.
		 */

		if (increment > 0)
		{
			synchronized (c.channelSendLock)
			{
				byte msg[] = c.msgWindowAdjust;

				msg[0] = Packets.SSH_MSG_CHANNEL_WINDOW_ADJUST;
				msg[1] = (byte) (c.remoteID >> 24);
				msg[2] = (byte) (c.remoteID >> 16);
				msg[3] = (byte) (c.remoteID >> 8);
				msg[4] = (byte) (c.remoteID);
				msg[5] = (byte) (increment >> 24);
				msg[6] = (byte) (increment >> 16);
				msg[7] = (byte) (increment >> 8);
				msg[8] = (byte) (increment);

				if (c.closeMessageSent == false)
					tm.sendMessage(msg);
			}

			if (log.isEnabled())
				log.log(50, "Sent SSH_MSG_CHANNEL_WINDOW_ADJUST (" + c.remoteID + ", " + increment + ")");
		}

		return copylen;
	}

	public void msgChannelData(byte[] msg, int msglen) throws IOException
	{
		if (msglen <= 9)
			throw new IOException("SSH_MSG_CHANNEL_DATA message has wrong size (" + msglen + ")");

		int id = ((msg[1] & 0xff) << 24) | ((msg[2] & 0xff) << 16) | ((msg[3] & 0xff) << 8) | (msg[4] & 0xff);
		int len = ((msg[5] & 0xff) << 24) | ((msg[6] & 0xff) << 16) | ((msg[7] & 0xff) << 8) | (msg[8] & 0xff);

		Channel c = getChannel(id);

		if (c == null)
			throw new IOException("Unexpected SSH_MSG_CHANNEL_DATA message for non-existent channel " + id);

		if (len != (msglen - 9))
			throw new IOException("SSH_MSG_CHANNEL_DATA message has wrong len (calculated " + (msglen - 9) + ", got "
					+ len + ")");

		if (log.isEnabled())
			log.log(50, "Got SSH_MSG_CHANNEL_DATA (" + id + ", " + len + ")");

		synchronized (c)
		{
			/* Discard data */
			if (c.state != Channel.STATE_OPEN)
				return;

			if (c.localWindow < len)
				throw new IOException("Remote sent too much data, does not fit into window.");

			c.localWindow -= len;

			System.arraycopy(msg, 9, c.stdoutBuffer, c.stdoutWritepos, len);
			c.stdoutWritepos += len;

			c.notifyAll();
		}
	}

	public void msgChannelWindowAdjust(byte[] msg, int msglen) throws IOException
	{
		if (msglen != 9)
			throw new IOException("SSH_MSG_CHANNEL_WINDOW_ADJUST message has wrong size (" + msglen + ")");

		int id = ((msg[1] & 0xff) << 24) | ((msg[2] & 0xff) << 16) | ((msg[3] & 0xff) << 8) | (msg[4] & 0xff);
		int windowChange = ((msg[5] & 0xff) << 24) | ((msg[6] & 0xff) << 16) | ((msg[7] & 0xff) << 8) | (msg[8] & 0xff);

		Channel c = getChannel(id);

		if (c == null)
			throw new IOException("Unexpected WindowAdjust message for non-existent Channel " + id);

		if (log.isEnabled())
			log.log(50, "Got SSH_MSG_CHANNEL_WINDOW_ADJUST (" + id + ", " + windowChange + ")");

		synchronized (c)
		{
			/* Discard */
			if (c.state != Channel.STATE_OPEN)
				return;

			c.remoteWindow += windowChange;
			c.notifyAll();
		}
	}

	public void msgChannelRequest(byte[] msg, int msglen) throws IOException
	{
		TypesReader tr = new TypesReader(msg, 0, msglen);

		tr.readByte();
		int id = tr.readUINT32();

		Channel c = getChannel(id);

		if (c == null)
			throw new IOException("Unexpected SSH_MSG_CHANNEL_REQUEST message for non-existent channel " + id);

		String type = tr.readString("US-ASCII");

		if (log.isEnabled())
			log.log(50, "Got SSH_MSG_CHANNEL_REQUEST (" + id + ", '" + type + "')");

		if (type.equals("exit-status"))
		{
			if (tr.readBoolean() != false)
				throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message");
			int exit_status = tr.readUINT32();
			synchronized (c)
			{
				c.exit_status = new Integer(exit_status);
				c.notifyAll();
			}
			if (tr.remain() != 0)
				throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message");

			if (log.isEnabled())
				log.log(50, "Got EXIT STATUS (" + id + " => status " + exit_status + ")");

			return;
		}

		if (type.equals("exit-signal"))
		{
			if (tr.readBoolean() != false)
				throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message");
			String signame = tr.readString("US-ASCII");
			synchronized (c)
			{
				c.exit_signal = signame;
				c.notifyAll();
			}
			tr.readBoolean();
			tr.readString();
			tr.readString();
			if (tr.remain() != 0)
				throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message");

			if (log.isEnabled())
				log.log(50, "Got EXIT SIGNAL (" + id + " => signal " + signame + ")");

			return;
		}

		/* ignore unknown requests */
	}

	public void msgChannelEOF(byte[] msg, int msglen) throws IOException
	{
		if (msglen != 5)
			throw new IOException("SSH_MSG_CHANNEL_EOF message has wrong size (" + msglen + ")");

		int id = ((msg[1] & 0xff) << 24) | ((msg[2] & 0xff) << 16) | ((msg[3] & 0xff) << 8) | (msg[4] & 0xff);

		Channel c = getChannel(id);

		if (c == null)
			throw new IOException("Unexpected SSH_MSG_CHANNEL_EOF message for non-existent channel " + id);

		if (log.isEnabled())
			log.log(50, "Got SSH_MSG_CHANNEL_EOF (" + id + ")");

		synchronized (c)
		{
			c.stdoutEOF = true;
			c.stderrEOF = true;
			c.notifyAll();
		}
	}

	public void msgChannelClose(byte[] msg, int msglen) throws IOException
	{
		if (msglen != 5)
			throw new IOException("SSH_MSG_CHANNEL_CLOSE message has wrong size (" + msglen + ")");

		int id = ((msg[1] & 0xff) << 24) | ((msg[2] & 0xff) << 16) | ((msg[3] & 0xff) << 8) | (msg[4] & 0xff);

		Channel c = getChannel(id);

		if (c == null)
			throw new IOException("Unexpected SSH_MSG_CHANNEL_CLOSE message for non-existent channel " + id);

		if (log.isEnabled())
			log.log(50, "Got SSH_MSG_CHANNEL_CLOSE (" + id + ")");

		synchronized (c)
		{
			c.stdoutEOF = true;
			c.stderrEOF = true;

			if (c.state != Channel.STATE_CLOSED)
			{
				c.state = Channel.STATE_CLOSED;
				c.reasonClosed = "Close requested by remote";
			}

			c.closeMessageRecv = true;
			c.notifyAll();
		}
	}

	public void msgChannelSuccess(byte[] msg, int msglen) throws IOException
	{
		if (msglen != 5)
			throw new IOException("SSH_MSG_CHANNEL_SUCCESS message has wrong size (" + msglen + ")");

		// int id = ((msg[1] & 0xff) << 24) | ((msg[2] & 0xff) << 16) | ((msg[3]
		// & 0xff) << 8) | (msg[4] & 0xff);

		/* IGNORE */
	}

	public void msgChannelFailure(byte[] msg, int msglen) throws IOException
	{
		if (msglen != 5)
			throw new IOException("SSH_MSG_CHANNEL_FAILURE message has wrong size (" + msglen + ")");

		int id = ((msg[1] & 0xff) << 24) | ((msg[2] & 0xff) << 16) | ((msg[3] & 0xff) << 8) | (msg[4] & 0xff);

		Channel c = getChannel(id);

		if (c == null)
			throw new IOException("Unexpected SSH_MSG_CHANNEL_FAILURE message for non-existent channel " + id);

		if (log.isEnabled())
			log.log(50, "Got SSH_MSG_CHANNEL_FAILURE (" + id + ")");

		synchronized (c)
		{
			if (c.state != Channel.STATE_FAILED)
			{
				c.state = Channel.STATE_FAILED;
				c.reasonClosed = "Remote sent failure for this channel";
			}
			c.notifyAll();
		}
	}

	public void msgChannelOpenConfirmation(byte[] msg, int msglen) throws IOException
	{
		PacketChannelOpenConfirmation sm = new PacketChannelOpenConfirmation(msg, 0, msglen);

		Channel c = getChannel(sm.recipientChannelID);

		if (c == null)
			throw new IOException("Unexpected SSH_MSG_CHANNEL_OPEN_CONFIRMATION message for non-existent channel "
					+ sm.recipientChannelID);

		synchronized (c)
		{
			if (c.state != Channel.STATE_OPENING)
				throw new IOException("Unexpected SSH_MSG_CHANNEL_OPEN_CONFIRMATION message for channel "
						+ sm.recipientChannelID);

			c.remoteID = sm.senderChannelID;
			c.remoteWindow = sm.initialWindowSize;
			c.remoteMaxPacketSize = sm.maxPacketSize;

			/* TODO, better estimate */

			c.estimatedMaxDataLen = c.remoteMaxPacketSize - 256;

			if (c.estimatedMaxDataLen <= 0)
			{
				c.estimatedMaxDataLen = 1;
			}

			c.state = Channel.STATE_OPEN;
			c.notifyAll();
		}
	}

	public void handleMessage(byte[] msg, int msglen) throws IOException
	{
		if (msg == null)
		{
			if (log.isEnabled())
				log.log(50, "handleMessage: got shutdown");

			synchronized (listenerThreads)
			{
				for (int i = 0; i < listenerThreads.size(); i++)
				{
					LocalAcceptThread lat = (LocalAcceptThread) listenerThreads.elementAt(i);
					lat.stopListening();
				}
				listenerThreadsAllowed = false;
			}

			synchronized (channels)
			{
				for (int i = 0; i < channels.size(); i++)
				{
					Channel c = (Channel) channels.elementAt(i);
					synchronized (c)
					{
						c.state = Channel.STATE_CLOSED;
						c.reasonClosed = "Connection is being shutdown";
						c.closeMessageRecv = true; /*
						 * You never know, perhaps
						 * we are waiting for a
						 * pending close message
						 * from the server...
						 */
						c.notifyAll();
					}
				}
				/* Works with J2ME */
				channels.setSize(0);
				channels.trimToSize();
				return;
			}
		}

		// System.out.println("ChannelMessage: " + msg[0]);

		switch (msg[0])
		{
		case Packets.SSH_MSG_CHANNEL_OPEN_CONFIRMATION:
			msgChannelOpenConfirmation(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_WINDOW_ADJUST:
			msgChannelWindowAdjust(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_DATA:
			msgChannelData(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_EXTENDED_DATA:
			msgChannelExtendedData(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_REQUEST:
			msgChannelRequest(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_EOF:
			msgChannelEOF(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_CLOSE:
			msgChannelClose(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_SUCCESS:
			msgChannelSuccess(msg, msglen);
			break;
		case Packets.SSH_MSG_CHANNEL_FAILURE:
		case Packets.SSH_MSG_CHANNEL_OPEN_FAILURE:
			msgChannelFailure(msg, msglen);
			break;
		default:
			// SSHPackets.debug("Cannot handle: ", msg);
			throw new IOException("Cannot handle channel message " + (msg[0] & 0xff));
		}
	}
}
