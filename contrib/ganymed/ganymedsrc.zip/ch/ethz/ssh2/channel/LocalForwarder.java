
package ch.ethz.ssh2.channel;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * LocalForwarder.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: LocalForwarder.java,v 1.2 2005/06/13 10:51:52 cplattne Exp $
 */
public class LocalForwarder extends Thread
{
	OutputStream os;
	InputStream is;
	byte[] buffer = new byte[Channel.CHANNEL_BUFFER_SIZE];

	String mode;

	LocalForwarder(InputStream is, OutputStream os, String mode) throws IOException
	{
		this.is = is;
		this.os = os;
		this.mode = mode;
	}

	public void run()
	{
		try
		{
			while (true)
			{
				int len = is.read(buffer);
				if (len <= 0)
					break;
				os.write(buffer, 0, len);
				os.flush();
			}
		}
		catch (IOException ignore)
		{
		}
		finally
		{
			try
			{
				os.close();
			}
			catch (IOException e1)
			{
			}
			try
			{
				is.close();
			}
			catch (IOException e1)
			{
			}
		}
	}
}