
package ch.ethz.ssh2;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import ch.ethz.ssh2.channel.Channel;
import ch.ethz.ssh2.channel.ChannelManager;

/**
 * A <code>Session</code> is a remote execution of a program. "Program" means
 * in this context either a shell, an application or a system command. The
 * program may or may not have a tty. Only one single program can be started on
 * a session. However, multiple sessions can be active simultaneously.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: Session.java,v 1.3 2005/08/11 12:47:31 cplattne Exp $
 */
public class Session
{
	ChannelManager cm;
	Channel cn;

	boolean flag_pty_requested = false;
	boolean flag_execution_started = false;
	boolean flag_closed = false;

	Session(ChannelManager cm) throws IOException
	{
		this.cm = cm;
		this.cn = cm.createSessionChannel();
	}

	/**
	 * Basically just a wrapper for lazy people - identical to calling
	 * <code>requestPTY("dumb", 0, 0, 0, 0, null)</code>.
	 * 
	 * @throws IOException
	 */
	public synchronized void requestDumbPTY() throws IOException
	{
		requestPTY("dumb", 0, 0, 0, 0, null);
	}

	/**
	 * Basically just another wrapper for lazy people - identical to calling
	 * <code>requestPTY(term, 0, 0, 0, 0, null)</code>.
	 * 
	 * @throws IOException
	 */
	public synchronized void requestPTY(String term) throws IOException
	{
		requestPTY(term, 0, 0, 0, 0, null);
	}

	/**
	 * Allocate a pseudo-terminal for this session.
	 * <p>
	 * This method may only be called before a program or shell is started in
	 * this session.
	 * <p>
	 * Different aspects can be specified:
	 * <p>
	 * <ul>
	 * <li>The TERM environment variable value (e.g., vt100)</li>
	 * <li>The terminal's dimensions.</li>
	 * <li>The encoded terminal modes.</li>
	 * </ul>
	 * Zero dimension parameters are ignored. The character/row dimensions
	 * override the pixel dimensions (when nonzero). Pixel dimensions refer to
	 * the drawable area of the window. The dimension parameters are only
	 * informational. The encoding of terminal modes (parameter
	 * <code>terminal_modes</code>) is described, e.g., in
	 * draft-ietf-secsh-connect-XY.txt.
	 * 
	 * @param term
	 *            The TERM environment variable value (e.g., vt100)
	 * @param term_width_characters
	 *            terminal width, characters (e.g., 80)
	 * @param term_height_characters
	 *            terminal height, rows (e.g., 24)
	 * @param term_width_pixels
	 *            terminal width, pixels (e.g., 640)
	 * @param term_height_pixels
	 *            terminal height, pixels (e.g., 480)
	 * @param terminal_modes
	 *            encoded terminal modes (may be <code>null</code>)
	 * @throws IOException
	 */
	public synchronized void requestPTY(String term, int term_width_characters, int term_height_characters,
			int term_width_pixels, int term_height_pixels, byte[] terminal_modes) throws IOException
	{
		if (flag_closed)
			throw new IOException("This session is closed.");

		if (flag_pty_requested)
			throw new IOException("A PTY was already requested.");

		if (flag_execution_started)
			throw new IOException("Cannot request PTY at this stage anymore, a remote execution has already started.");

		if (term == null)
			throw new IllegalArgumentException("TERM cannot be null.");

		if ((terminal_modes != null) && (terminal_modes.length > 0))
		{
			if (terminal_modes[terminal_modes.length - 1] != 0)
				throw new IOException("Illegal terminal modes description, does not end in zero byte");
		}
		else
			terminal_modes = new byte[] { 0 };

		flag_pty_requested = true;

		cm.requestPTY(cn, term, term_width_characters, term_height_characters, term_width_pixels, term_height_pixels,
				terminal_modes);
	}

	/**
	 * Execute a command on the remote machine.
	 * 
	 * @param cmd
	 *            The command to execute on the remote host.
	 * @throws IOException
	 */
	public synchronized void execCommand(String cmd) throws IOException
	{
		if (flag_closed)
			throw new IOException("This session is closed.");

		if (flag_execution_started)
			throw new IOException("A remote execution has already started.");

		flag_execution_started = true;

		cm.execCommand(cn, cmd);
	}

	/**
	 * Start a shell on the remote machine.
	 * 
	 * @throws IOException
	 */
	public synchronized void startShell() throws IOException
	{
		if (flag_closed)
			throw new IOException("This session is closed.");

		if (flag_execution_started)
			throw new IOException("A remote execution has already started.");

		flag_execution_started = true;

		cm.startShell(cn);
	}

	public synchronized InputStream getStdout() throws IOException
	{
		synchronized (cn)
		{
			if (cn.stdoutStream == null)
				throw new IOException("STDOUT is not available");

			return cn.stdoutStream;
		}
	}

	public synchronized InputStream getStderr() throws IOException
	{
		synchronized (cn)
		{
			if (cn.stderrStream == null)
				throw new IOException("STDERR is not available");

			return cn.stderrStream;
		}
	}

	public synchronized OutputStream getStdin() throws IOException
	{
		synchronized (cn)
		{
			if (cn.stdinStream == null)
				throw new IOException("STDIN is not available");

			return cn.stdinStream;
		}
	}

	/**
	 * This method blocks until there is more data available on either the
	 * stdout or stderr InputStream of this <code>Session</code>. Very useful
	 * if you do not want to use two parallel threads for reading from the two
	 * InputStreams. One can also specify a timeout. NOTE: do NOT call this
	 * method if you use concurrent threads that operate on either of the two
	 * InputStreams of this <code>Session</code> (otherwise this method may
	 * block, even though more data is available).
	 * 
	 * @param timeout
	 *            The timeout in <code>ms</code>. <code>0</code> means no
	 *            timeout, the call may block forever.
	 * @return
	 *            <ul>
	 *            <li><code>0</code> if no more data will arrive (EOF on both
	 *            streams).</li>
	 *            <li><code>1</code> if more data is available.</li>
	 *            <li><code>-1</code> if a timeout occurred.</li>
	 *            </ul>
	 * 
	 * @throws IOException
	 */
	public synchronized int waitUntilDataAvailable(long timeout) throws IOException
	{
		/*
		 * We don't need to synchronize again, these fields (cn.stdoutStream,
		 * cn.stderrStream) never change
		 */

		/* Check the two streams, in case the caller did not */

		if (cn.stdoutStream.available() > 0)
			return 1;

		if (cn.stderrStream.available() > 0)
			return 1;

		return cm.waitUntilDataAvailable(cn, timeout);
	}

	/**
	 * Get the exit code/status from the remote command - if available. Be
	 * careful - not all server implementations return this value. It is
	 * generally a good idea to call this method only when all data from the
	 * remote side has been consumed.
	 * 
	 * @return An <code>Integer</code> holding the exit code, or
	 *         <code>null</code> if no exit code is (yet) available.
	 */
	public synchronized Integer getExitStatus()
	{
		synchronized (cn)
		{
			return cn.exit_status;
		}
	}

	/**
	 * Get the name of the signal by which the process on the remote side was
	 * stopped - if available and applicable. Be careful - not all server
	 * implementations return this value.
	 * 
	 * @return An <code>String</code> holding the name of the signal, or
	 *         <code>null</code> if the process exited normally or is still
	 *         running.
	 */
	public synchronized String getExitSignal()
	{
		synchronized (cn)
		{
			return cn.exit_signal;
		}
	}

	/**
	 * Close this session. NEVER forget to call this method to free up resources -
	 * even if you got an exception from one of the other methods (or when
	 * calling a method on the Input- or OutputStreams). Sometimes these other
	 * methods may throw an exception, saying that the underlying channel is
	 * closed (this can happen, e.g., if the other server sent a close message.)
	 * However, as long as you have not called the <code>close()</code>
	 * method, you may be wasting resources.
	 * 
	 */
	public synchronized void close()
	{
		if (flag_closed == false)
		{
			try
			{
				cm.closeChannel(cn, "Closed due to user request");
			}
			catch (IOException ignored)
			{
			}
			flag_closed = true;
		}
	}
}
